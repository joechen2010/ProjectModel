// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   DataHandler.java

package javax.activation;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.io.OutputStream;

// Referenced classes of package javax.activation:
//			ActivationDataFlavor, DataContentHandler, UnsupportedDataTypeException, DataSource

class ObjectDataContentHandler
	implements DataContentHandler {

	private DataFlavor transferFlavors[];
	private Object obj;
	private String mimeType;
	private DataContentHandler dch;

	public ObjectDataContentHandler(DataContentHandler dch, Object obj, String mimeType) {
		transferFlavors = null;
		this.dch = null;
		this.obj = obj;
		this.mimeType = mimeType;
		this.dch = dch;
	}

	public DataContentHandler getDCH() {
		return dch;
	}

	public DataFlavor[] getTransferDataFlavors() {
		if (transferFlavors == null) {
			if (dch != null) {
				transferFlavors = dch.getTransferDataFlavors();
			} else {
				transferFlavors = new DataFlavor[1];
				transferFlavors[0] = new ActivationDataFlavor(obj.getClass(), mimeType, mimeType);
			}
		}
		return transferFlavors;
	}

	public Object getTransferData(DataFlavor df, DataSource ds) throws UnsupportedFlavorException, IOException {
		if (dch != null) {
			return dch.getTransferData(df, ds);
		}
		if (df.equals(transferFlavors[0])) {
			return obj;
		} else {
			throw new UnsupportedFlavorException(df);
		}
	}

	public Object getContent(DataSource ds) {
		return obj;
	}

	public void writeTo(Object obj, String mimeType, OutputStream os) throws IOException {
		if (dch != null) {
			dch.writeTo(obj, mimeType, os);
		} else {
			throw new UnsupportedDataTypeException("no object DCH for MIME type " + this.mimeType);
		}
	}
}
