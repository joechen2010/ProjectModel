// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   MimetypesFileTypeMap.java

package javax.activation;

import com.sun.activation.registries.LogSupport;
import com.sun.activation.registries.MimeTypeFile;
import java.io.*;
import java.util.Vector;

// Referenced classes of package javax.activation:
//			FileTypeMap, SecuritySupport

public class MimetypesFileTypeMap extends FileTypeMap {

	private static MimeTypeFile defDB = null;
	private MimeTypeFile DB[];
	private static final int PROG = 0;
	private static String defaultType = "application/octet-stream";

	public MimetypesFileTypeMap() {
		Vector dbv = new Vector(5);
		MimeTypeFile mf = null;
		dbv.addElement(null);
		LogSupport.log("MimetypesFileTypeMap: load HOME");
		try {
			String user_home = System.getProperty("user.home");
			if (user_home != null) {
				String path = user_home + File.separator + ".mime.types";
				mf = loadFile(path);
				if (mf != null) {
					dbv.addElement(mf);
				}
			}
		}
		catch (SecurityException ex) { }
		LogSupport.log("MimetypesFileTypeMap: load SYS");
		try {
			String system_mimetypes = System.getProperty("java.home") + File.separator + "lib" + File.separator + "mime.types";
			mf = loadFile(system_mimetypes);
			if (mf != null) {
				dbv.addElement(mf);
			}
		}
		catch (SecurityException ex) { }
		LogSupport.log("MimetypesFileTypeMap: load JAR");
		loadAllResources(dbv, "META-INF/mime.types");
		LogSupport.log("MimetypesFileTypeMap: load DEF");
		synchronized (javax.activation.MimetypesFileTypeMap.class) {
			if (defDB == null) {
				defDB = loadResource("/META-INF/mimetypes.default");
			}
		}
		if (defDB != null) {
			dbv.addElement(defDB);
		}
		DB = new MimeTypeFile[dbv.size()];
		dbv.copyInto(DB);
	}

	private MimeTypeFile loadResource(String name) {
		InputStream clis = null;
		MimeTypeFile mimetypefile;
		clis = SecuritySupport.getResourceAsStream(getClass(), name);
		if (clis == null) {
			break MISSING_BLOCK_LABEL_71;
		}
		MimeTypeFile mf = new MimeTypeFile(clis);
		if (LogSupport.isLoggable()) {
			LogSupport.log("MimetypesFileTypeMap: successfully loaded mime types file: " + name);
		}
		mimetypefile = mf;
		try {
			if (clis != null) {
				clis.close();
			}
		}
		catch (IOException ex) { }
		return mimetypefile;
		if (LogSupport.isLoggable()) {
			LogSupport.log("MimetypesFileTypeMap: not loading mime types file: " + name);
		}
		try {
			if (clis != null) {
				clis.close();
			}
		}
		catch (IOException ex) { }
		break MISSING_BLOCK_LABEL_222;
		IOException e;
		e;
		if (LogSupport.isLoggable()) {
			LogSupport.log("MimetypesFileTypeMap: can't load " + name, e);
		}
		try {
			if (clis != null) {
				clis.close();
			}
		}
		catch (IOException ex) { }
		break MISSING_BLOCK_LABEL_222;
		SecurityException sex;
		sex;
		if (LogSupport.isLoggable()) {
			LogSupport.log("MimetypesFileTypeMap: can't load " + name, sex);
		}
		try {
			if (clis != null) {
				clis.close();
			}
		}
		catch (IOException ex) { }
		break MISSING_BLOCK_LABEL_222;
		Exception exception;
		exception;
		try {
			if (clis != null) {
				clis.close();
			}
		}
		catch (IOException ex) { }
		throw exception;
		return null;
	}

	private void loadAllResources(Vector v, String name) {
		boolean anyLoaded = false;
		java.net.URL urls[];
		ClassLoader cld = null;
		cld = SecuritySupport.getContextClassLoader();
		if (cld == null) {
			cld = getClass().getClassLoader();
		}
		if (cld != null) {
			urls = SecuritySupport.getResources(cld, name);
		} else {
			urls = SecuritySupport.getSystemResources(name);
		}
		if (urls == null) goto _L2; else goto _L1
_L1:
		int i;
		if (LogSupport.isLoggable()) {
			LogSupport.log("MimetypesFileTypeMap: getResources");
		}
		i = 0;
_L4:
		java.net.URL url;
		InputStream clis;
		if (i >= urls.length) {
			break; /* Loop/switch isn't completed */
		}
		url = urls[i];
		clis = null;
		if (LogSupport.isLoggable()) {
			LogSupport.log("MimetypesFileTypeMap: URL " + url);
		}
		clis = SecuritySupport.openStream(url);
		if (clis != null) {
			v.addElement(new MimeTypeFile(clis));
			anyLoaded = true;
			if (LogSupport.isLoggable()) {
				LogSupport.log("MimetypesFileTypeMap: successfully loaded mime types from URL: " + url);
			}
		} else
		if (LogSupport.isLoggable()) {
			LogSupport.log("MimetypesFileTypeMap: not loading mime types from URL: " + url);
		}
		try {
			if (clis != null) {
				clis.close();
			}
		}
		catch (IOException cex) { }
		  goto _L3
		IOException ioex;
		ioex;
		if (LogSupport.isLoggable()) {
			LogSupport.log("MimetypesFileTypeMap: can't load " + url, ioex);
		}
		try {
			if (clis != null) {
				clis.close();
			}
		}
		catch (IOException cex) { }
		  goto _L3
		SecurityException sex;
		sex;
		if (LogSupport.isLoggable()) {
			LogSupport.log("MimetypesFileTypeMap: can't load " + url, sex);
		}
		try {
			if (clis != null) {
				clis.close();
			}
		}
		catch (IOException cex) { }
		  goto _L3
		Exception exception;
		exception;
		try {
			if (clis != null) {
				clis.close();
			}
		}
		catch (IOException cex) { }
		throw exception;
_L3:
		i++;
		if (true) goto _L4; else goto _L2
		Exception ex;
		ex;
		if (LogSupport.isLoggable()) {
			LogSupport.log("MimetypesFileTypeMap: can't load " + name, ex);
		}
_L2:
		if (!anyLoaded) {
			LogSupport.log("MimetypesFileTypeMap: !anyLoaded");
			MimeTypeFile mf = loadResource("/" + name);
			if (mf != null) {
				v.addElement(mf);
			}
		}
		return;
	}

	private MimeTypeFile loadFile(String name) {
		MimeTypeFile mtf = null;
		try {
			mtf = new MimeTypeFile(name);
		}
		catch (IOException e) { }
		return mtf;
	}

	public MimetypesFileTypeMap(String mimeTypeFileName) throws IOException {
		this();
		DB[0] = new MimeTypeFile(mimeTypeFileName);
	}

	public MimetypesFileTypeMap(InputStream is) {
		this();
		try {
			DB[0] = new MimeTypeFile(is);
		}
		catch (IOException ex) { }
	}

	public synchronized void addMimeTypes(String mime_types) {
		if (DB[0] == null) {
			DB[0] = new MimeTypeFile();
		}
		DB[0].appendToRegistry(mime_types);
	}

	public String getContentType(File f) {
		return getContentType(f.getName());
	}

	public synchronized String getContentType(String filename) {
		int dot_pos = filename.lastIndexOf(".");
		if (dot_pos < 0) {
			return defaultType;
		}
		String file_ext = filename.substring(dot_pos + 1);
		if (file_ext.length() == 0) {
			return defaultType;
		}
		for (int i = 0; i < DB.length; i++) {
			if (DB[i] == null) {
				continue;
			}
			String result = DB[i].getMIMETypeString(file_ext);
			if (result != null) {
				return result;
			}
		}

		return defaultType;
	}

}
