// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   SecuritySupport.java

package javax.activation;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.security.*;
import java.util.*;

class SecuritySupport {

	private SecuritySupport() {
	}

	public static ClassLoader getContextClassLoader() {
		return (ClassLoader)AccessController.doPrivileged(new PrivilegedAction() {

			public Object run() {
				ClassLoader cl = null;
				try {
					cl = Thread.currentThread().getContextClassLoader();
				}
				catch (SecurityException ex) { }
				return cl;
			}

		});
	}

	public static InputStream getResourceAsStream(Class c, String name) throws IOException {
		return (InputStream)AccessController.doPrivileged(new PrivilegedExceptionAction(c, name) {

			public Object run() throws IOException {
				return c.getResourceAsStream(name);
			}

			 {
				super();
			}
		});
		PrivilegedActionException e;
		e;
		throw (IOException)e.getException();
	}

	public static URL[] getResources(ClassLoader cl, String name) {
		return (URL[])(URL[])AccessController.doPrivileged(new PrivilegedAction(cl, name) {

			public Object run() {
				URL ret[] = null;
				try {
					List v = new ArrayList();
					Enumeration e = cl.getResources(name);
					do {
						if (e == null || !e.hasMoreElements()) {
							break;
						}
						URL url = (URL)e.nextElement();
						if (url != null) {
							v.add(url);
						}
					} while (true);
					if (v.size() > 0) {
						ret = new URL[v.size()];
						ret = (URL[])(URL[])v.toArray(ret);
					}
				}
				catch (IOException ioex) { }
				catch (SecurityException ex) { }
				return ret;
			}

			 {
				super();
			}
		});
	}

	public static URL[] getSystemResources(String name) {
		return (URL[])(URL[])AccessController.doPrivileged(new PrivilegedAction(name) {

			public Object run() {
				URL ret[] = null;
				try {
					List v = new ArrayList();
					Enumeration e = ClassLoader.getSystemResources(name);
					do {
						if (e == null || !e.hasMoreElements()) {
							break;
						}
						URL url = (URL)e.nextElement();
						if (url != null) {
							v.add(url);
						}
					} while (true);
					if (v.size() > 0) {
						ret = new URL[v.size()];
						ret = (URL[])(URL[])v.toArray(ret);
					}
				}
				catch (IOException ioex) { }
				catch (SecurityException ex) { }
				return ret;
			}

			 {
				super();
			}
		});
	}

	public static InputStream openStream(URL url) throws IOException {
		return (InputStream)AccessController.doPrivileged(new PrivilegedExceptionAction(url) {

			public Object run() throws IOException {
				return url.openStream();
			}

			 throws IOException {
				super();
			}
		});
		PrivilegedActionException e;
		e;
		throw (IOException)e.getException();
	}
}
