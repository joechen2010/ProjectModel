// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   SecuritySupport.java

package javax.activation;

import java.io.IOException;
import java.security.PrivilegedExceptionAction;

static class SecuritySupport$2
	implements PrivilegedExceptionAction {

	public Object run() throws IOException {
		return val$c.getResourceAsStream(val$name);
	}

	SecuritySupport$2(Class class1, String s) {
		super();
	}
}
