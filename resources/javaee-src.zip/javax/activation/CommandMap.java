// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   CommandMap.java

package javax.activation;


// Referenced classes of package javax.activation:
//			MailcapCommandMap, CommandInfo, DataSource, DataContentHandler

public abstract class CommandMap {

	private static CommandMap defaultCommandMap = null;

	public CommandMap() {
	}

	public static CommandMap getDefaultCommandMap() {
		if (defaultCommandMap == null) {
			defaultCommandMap = new MailcapCommandMap();
		}
		return defaultCommandMap;
	}

	public static void setDefaultCommandMap(CommandMap commandMap) {
		SecurityManager security = System.getSecurityManager();
		if (security != null) {
			try {
				security.checkSetFactory();
			}
			catch (SecurityException ex) {
				if ((javax.activation.CommandMap.class).getClassLoader() != commandMap.getClass().getClassLoader()) {
					throw ex;
				}
			}
		}
		defaultCommandMap = commandMap;
	}

	public abstract CommandInfo[] getPreferredCommands(String s);

	public CommandInfo[] getPreferredCommands(String mimeType, DataSource ds) {
		return getPreferredCommands(mimeType);
	}

	public abstract CommandInfo[] getAllCommands(String s);

	public CommandInfo[] getAllCommands(String mimeType, DataSource ds) {
		return getAllCommands(mimeType);
	}

	public abstract CommandInfo getCommand(String s, String s1);

	public CommandInfo getCommand(String mimeType, String cmdName, DataSource ds) {
		return getCommand(mimeType, cmdName);
	}

	public abstract DataContentHandler createDataContentHandler(String s);

	public DataContentHandler createDataContentHandler(String mimeType, DataSource ds) {
		return createDataContentHandler(mimeType);
	}

	public String[] getMimeTypes() {
		return null;
	}

}
