// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   SecuritySupport.java

package javax.activation;

import java.io.IOException;
import java.net.URL;
import java.security.PrivilegedAction;
import java.util.*;

static class SecuritySupport$3
	implements PrivilegedAction {

	public Object run() {
		URL ret[] = null;
		try {
			List v = new ArrayList();
			Enumeration e = val$cl.getResources(val$name);
			do {
				if (e == null || !e.hasMoreElements()) {
					break;
				}
				URL url = (URL)e.nextElement();
				if (url != null) {
					v.add(url);
				}
			} while (true);
			if (v.size() > 0) {
				ret = new URL[v.size()];
				ret = (URL[])(URL[])v.toArray(ret);
			}
		}
		catch (IOException ioex) { }
		catch (SecurityException ex) { }
		return ret;
	}

	SecuritySupport$3(ClassLoader classloader, String s) {
		super();
	}
}
