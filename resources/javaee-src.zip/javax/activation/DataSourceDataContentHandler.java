// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   DataHandler.java

package javax.activation;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.io.OutputStream;

// Referenced classes of package javax.activation:
//			ActivationDataFlavor, DataContentHandler, DataSource, UnsupportedDataTypeException

class DataSourceDataContentHandler
	implements DataContentHandler {

	private DataSource ds;
	private DataFlavor transferFlavors[];
	private DataContentHandler dch;

	public DataSourceDataContentHandler(DataContentHandler dch, DataSource ds) {
		this.ds = null;
		transferFlavors = null;
		this.dch = null;
		this.ds = ds;
		this.dch = dch;
	}

	public DataFlavor[] getTransferDataFlavors() {
		if (transferFlavors == null) {
			if (dch != null) {
				transferFlavors = dch.getTransferDataFlavors();
			} else {
				transferFlavors = new DataFlavor[1];
				transferFlavors[0] = new ActivationDataFlavor(ds.getContentType(), ds.getContentType());
			}
		}
		return transferFlavors;
	}

	public Object getTransferData(DataFlavor df, DataSource ds) throws UnsupportedFlavorException, IOException {
		if (dch != null) {
			return dch.getTransferData(df, ds);
		}
		if (df.equals(getTransferDataFlavors()[0])) {
			return ds.getInputStream();
		} else {
			throw new UnsupportedFlavorException(df);
		}
	}

	public Object getContent(DataSource ds) throws IOException {
		if (dch != null) {
			return dch.getContent(ds);
		} else {
			return ds.getInputStream();
		}
	}

	public void writeTo(Object obj, String mimeType, OutputStream os) throws IOException {
		if (dch != null) {
			dch.writeTo(obj, mimeType, os);
		} else {
			throw new UnsupportedDataTypeException("no DCH for content type " + ds.getContentType());
		}
	}
}
