// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   URLDataSource.java

package javax.activation;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;

// Referenced classes of package javax.activation:
//			DataSource

public class URLDataSource
	implements DataSource {

	private URL url;
	private URLConnection url_conn;

	public URLDataSource(URL url) {
		this.url = null;
		url_conn = null;
		this.url = url;
	}

	public String getContentType() {
		String type = null;
		try {
			if (url_conn == null) {
				url_conn = url.openConnection();
			}
		}
		catch (IOException e) { }
		if (url_conn != null) {
			type = url_conn.getContentType();
		}
		if (type == null) {
			type = "application/octet-stream";
		}
		return type;
	}

	public String getName() {
		return url.getFile();
	}

	public InputStream getInputStream() throws IOException {
		return url.openStream();
	}

	public OutputStream getOutputStream() throws IOException {
		url_conn = url.openConnection();
		if (url_conn != null) {
			url_conn.setDoOutput(true);
			return url_conn.getOutputStream();
		} else {
			return null;
		}
	}

	public URL getURL() {
		return url;
	}
}
