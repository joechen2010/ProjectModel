// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   SecuritySupport.java

package javax.activation;

import java.security.PrivilegedAction;

static class SecuritySupport$1
	implements PrivilegedAction {

	public Object run() {
		ClassLoader cl = null;
		try {
			cl = Thread.currentThread().getContextClassLoader();
		}
		catch (SecurityException ex) { }
		return cl;
	}

	SecuritySupport$1() {
	}
}
