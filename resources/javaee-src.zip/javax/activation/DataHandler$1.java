// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   DataHandler.java

package javax.activation;

import java.io.IOException;
import java.io.PipedOutputStream;

// Referenced classes of package javax.activation:
//			DataContentHandler, DataHandler

class DataHandler$1
	implements Runnable {

	public void run() {
label0:
		{
			try {
				val$fdch.writeTo(DataHandler.access$000(DataHandler.this), DataHandler.access$100(DataHandler.this), val$pos);
			}
			catch (IOException e) {
				try {
					val$pos.close();
				}
				catch (IOException ie) { }
				break label0;
			}
			finally {
				try {
					val$pos.close();
				}
				catch (IOException ie) { }
				throw exception;
			}
			try {
				val$pos.close();
			}
			catch (IOException ie) { }
			break label0;
		}
	}

	DataHandler$1() {
		super();
	}
}
