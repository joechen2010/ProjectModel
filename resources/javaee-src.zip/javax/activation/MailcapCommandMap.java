// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   MailcapCommandMap.java

package javax.activation;

import com.sun.activation.registries.LogSupport;
import com.sun.activation.registries.MailcapFile;
import java.io.*;
import java.util.*;

// Referenced classes of package javax.activation:
//			CommandMap, CommandInfo, DataContentHandler, SecuritySupport

public class MailcapCommandMap extends CommandMap {

	private static MailcapFile defDB = null;
	private MailcapFile DB[];
	private static final int PROG = 0;

	public MailcapCommandMap() {
		List dbv = new ArrayList(5);
		MailcapFile mf = null;
		dbv.add(null);
		LogSupport.log("MailcapCommandMap: load HOME");
		try {
			String user_home = System.getProperty("user.home");
			if (user_home != null) {
				String path = user_home + File.separator + ".mailcap";
				mf = loadFile(path);
				if (mf != null) {
					dbv.add(mf);
				}
			}
		}
		catch (SecurityException ex) { }
		LogSupport.log("MailcapCommandMap: load SYS");
		try {
			String system_mailcap = System.getProperty("java.home") + File.separator + "lib" + File.separator + "mailcap";
			mf = loadFile(system_mailcap);
			if (mf != null) {
				dbv.add(mf);
			}
		}
		catch (SecurityException ex) { }
		LogSupport.log("MailcapCommandMap: load JAR");
		loadAllResources(dbv, "META-INF/mailcap");
		LogSupport.log("MailcapCommandMap: load DEF");
		synchronized (javax.activation.MailcapCommandMap.class) {
			if (defDB == null) {
				defDB = loadResource("/META-INF/mailcap.default");
			}
		}
		if (defDB != null) {
			dbv.add(defDB);
		}
		DB = new MailcapFile[dbv.size()];
		DB = (MailcapFile[])(MailcapFile[])dbv.toArray(DB);
	}

	private MailcapFile loadResource(String name) {
		InputStream clis = null;
		MailcapFile mailcapfile;
		clis = SecuritySupport.getResourceAsStream(getClass(), name);
		if (clis == null) {
			break MISSING_BLOCK_LABEL_71;
		}
		MailcapFile mf = new MailcapFile(clis);
		if (LogSupport.isLoggable()) {
			LogSupport.log("MailcapCommandMap: successfully loaded mailcap file: " + name);
		}
		mailcapfile = mf;
		try {
			if (clis != null) {
				clis.close();
			}
		}
		catch (IOException ex) { }
		return mailcapfile;
		if (LogSupport.isLoggable()) {
			LogSupport.log("MailcapCommandMap: not loading mailcap file: " + name);
		}
		try {
			if (clis != null) {
				clis.close();
			}
		}
		catch (IOException ex) { }
		break MISSING_BLOCK_LABEL_222;
		IOException e;
		e;
		if (LogSupport.isLoggable()) {
			LogSupport.log("MailcapCommandMap: can't load " + name, e);
		}
		try {
			if (clis != null) {
				clis.close();
			}
		}
		catch (IOException ex) { }
		break MISSING_BLOCK_LABEL_222;
		SecurityException sex;
		sex;
		if (LogSupport.isLoggable()) {
			LogSupport.log("MailcapCommandMap: can't load " + name, sex);
		}
		try {
			if (clis != null) {
				clis.close();
			}
		}
		catch (IOException ex) { }
		break MISSING_BLOCK_LABEL_222;
		Exception exception;
		exception;
		try {
			if (clis != null) {
				clis.close();
			}
		}
		catch (IOException ex) { }
		throw exception;
		return null;
	}

	private void loadAllResources(List v, String name) {
		boolean anyLoaded = false;
		java.net.URL urls[];
		ClassLoader cld = null;
		cld = SecuritySupport.getContextClassLoader();
		if (cld == null) {
			cld = getClass().getClassLoader();
		}
		if (cld != null) {
			urls = SecuritySupport.getResources(cld, name);
		} else {
			urls = SecuritySupport.getSystemResources(name);
		}
		if (urls == null) goto _L2; else goto _L1
_L1:
		int i;
		if (LogSupport.isLoggable()) {
			LogSupport.log("MailcapCommandMap: getResources");
		}
		i = 0;
_L4:
		java.net.URL url;
		InputStream clis;
		if (i >= urls.length) {
			break; /* Loop/switch isn't completed */
		}
		url = urls[i];
		clis = null;
		if (LogSupport.isLoggable()) {
			LogSupport.log("MailcapCommandMap: URL " + url);
		}
		clis = SecuritySupport.openStream(url);
		if (clis != null) {
			v.add(new MailcapFile(clis));
			anyLoaded = true;
			if (LogSupport.isLoggable()) {
				LogSupport.log("MailcapCommandMap: successfully loaded mailcap file from URL: " + url);
			}
		} else
		if (LogSupport.isLoggable()) {
			LogSupport.log("MailcapCommandMap: not loading mailcap file from URL: " + url);
		}
		try {
			if (clis != null) {
				clis.close();
			}
		}
		catch (IOException cex) { }
		  goto _L3
		IOException ioex;
		ioex;
		if (LogSupport.isLoggable()) {
			LogSupport.log("MailcapCommandMap: can't load " + url, ioex);
		}
		try {
			if (clis != null) {
				clis.close();
			}
		}
		catch (IOException cex) { }
		  goto _L3
		SecurityException sex;
		sex;
		if (LogSupport.isLoggable()) {
			LogSupport.log("MailcapCommandMap: can't load " + url, sex);
		}
		try {
			if (clis != null) {
				clis.close();
			}
		}
		catch (IOException cex) { }
		  goto _L3
		Exception exception;
		exception;
		try {
			if (clis != null) {
				clis.close();
			}
		}
		catch (IOException cex) { }
		throw exception;
_L3:
		i++;
		if (true) goto _L4; else goto _L2
		Exception ex;
		ex;
		if (LogSupport.isLoggable()) {
			LogSupport.log("MailcapCommandMap: can't load " + name, ex);
		}
_L2:
		if (!anyLoaded) {
			if (LogSupport.isLoggable()) {
				LogSupport.log("MailcapCommandMap: !anyLoaded");
			}
			MailcapFile mf = loadResource("/" + name);
			if (mf != null) {
				v.add(mf);
			}
		}
		return;
	}

	private MailcapFile loadFile(String name) {
		MailcapFile mtf = null;
		try {
			mtf = new MailcapFile(name);
		}
		catch (IOException e) { }
		return mtf;
	}

	public MailcapCommandMap(String fileName) throws IOException {
		this();
		if (LogSupport.isLoggable()) {
			LogSupport.log("MailcapCommandMap: load PROG from " + fileName);
		}
		if (DB[0] == null) {
			DB[0] = new MailcapFile(fileName);
		}
	}

	public MailcapCommandMap(InputStream is) {
		this();
		LogSupport.log("MailcapCommandMap: load PROG");
		if (DB[0] == null) {
			try {
				DB[0] = new MailcapFile(is);
			}
			catch (IOException ex) { }
		}
	}

	public synchronized CommandInfo[] getPreferredCommands(String mimeType) {
		List cmdList = new ArrayList();
		if (mimeType != null) {
			mimeType = mimeType.toLowerCase();
		}
		for (int i = 0; i < DB.length; i++) {
			if (DB[i] == null) {
				continue;
			}
			Map cmdMap = DB[i].getMailcapList(mimeType);
			if (cmdMap != null) {
				appendPrefCmdsToList(cmdMap, cmdList);
			}
		}

		for (int i = 0; i < DB.length; i++) {
			if (DB[i] == null) {
				continue;
			}
			Map cmdMap = DB[i].getMailcapFallbackList(mimeType);
			if (cmdMap != null) {
				appendPrefCmdsToList(cmdMap, cmdList);
			}
		}

		CommandInfo cmdInfos[] = new CommandInfo[cmdList.size()];
		cmdInfos = (CommandInfo[])(CommandInfo[])cmdList.toArray(cmdInfos);
		return cmdInfos;
	}

	private void appendPrefCmdsToList(Map cmdHash, List cmdList) {
		Iterator verb_enum = cmdHash.keySet().iterator();
		do {
			if (!verb_enum.hasNext()) {
				break;
			}
			String verb = (String)verb_enum.next();
			if (!checkForVerb(cmdList, verb)) {
				List cmdList2 = (List)cmdHash.get(verb);
				String className = (String)cmdList2.get(0);
				cmdList.add(new CommandInfo(verb, className));
			}
		} while (true);
	}

	private boolean checkForVerb(List cmdList, String verb) {
		for (Iterator ee = cmdList.iterator(); ee.hasNext();) {
			String enum_verb = ((CommandInfo)ee.next()).getCommandName();
			if (enum_verb.equals(verb)) {
				return true;
			}
		}

		return false;
	}

	public synchronized CommandInfo[] getAllCommands(String mimeType) {
		List cmdList = new ArrayList();
		if (mimeType != null) {
			mimeType = mimeType.toLowerCase();
		}
		for (int i = 0; i < DB.length; i++) {
			if (DB[i] == null) {
				continue;
			}
			Map cmdMap = DB[i].getMailcapList(mimeType);
			if (cmdMap != null) {
				appendCmdsToList(cmdMap, cmdList);
			}
		}

		for (int i = 0; i < DB.length; i++) {
			if (DB[i] == null) {
				continue;
			}
			Map cmdMap = DB[i].getMailcapFallbackList(mimeType);
			if (cmdMap != null) {
				appendCmdsToList(cmdMap, cmdList);
			}
		}

		CommandInfo cmdInfos[] = new CommandInfo[cmdList.size()];
		cmdInfos = (CommandInfo[])(CommandInfo[])cmdList.toArray(cmdInfos);
		return cmdInfos;
	}

	private void appendCmdsToList(Map typeHash, List cmdList) {
		for (Iterator verb_enum = typeHash.keySet().iterator(); verb_enum.hasNext();) {
			String verb = (String)verb_enum.next();
			List cmdList2 = (List)typeHash.get(verb);
			Iterator cmd_enum = cmdList2.iterator();
			while (cmd_enum.hasNext())  {
				String cmd = (String)cmd_enum.next();
				cmdList.add(new CommandInfo(verb, cmd));
			}
		}

	}

	public synchronized CommandInfo getCommand(String mimeType, String cmdName) {
		if (mimeType != null) {
			mimeType = mimeType.toLowerCase();
		}
		for (int i = 0; i < DB.length; i++) {
			if (DB[i] == null) {
				continue;
			}
			Map cmdMap = DB[i].getMailcapList(mimeType);
			if (cmdMap == null) {
				continue;
			}
			List v = (List)cmdMap.get(cmdName);
			if (v == null) {
				continue;
			}
			String cmdClassName = (String)v.get(0);
			if (cmdClassName != null) {
				return new CommandInfo(cmdName, cmdClassName);
			}
		}

		for (int i = 0; i < DB.length; i++) {
			if (DB[i] == null) {
				continue;
			}
			Map cmdMap = DB[i].getMailcapFallbackList(mimeType);
			if (cmdMap == null) {
				continue;
			}
			List v = (List)cmdMap.get(cmdName);
			if (v == null) {
				continue;
			}
			String cmdClassName = (String)v.get(0);
			if (cmdClassName != null) {
				return new CommandInfo(cmdName, cmdClassName);
			}
		}

		return null;
	}

	public synchronized void addMailcap(String mail_cap) {
		LogSupport.log("MailcapCommandMap: add to PROG");
		if (DB[0] == null) {
			DB[0] = new MailcapFile();
		}
		DB[0].appendToMailcap(mail_cap);
	}

	public synchronized DataContentHandler createDataContentHandler(String mimeType) {
		if (LogSupport.isLoggable()) {
			LogSupport.log("MailcapCommandMap: createDataContentHandler for " + mimeType);
		}
		if (mimeType != null) {
			mimeType = mimeType.toLowerCase();
		}
		for (int i = 0; i < DB.length; i++) {
			if (DB[i] == null) {
				continue;
			}
			if (LogSupport.isLoggable()) {
				LogSupport.log("  search DB #" + i);
			}
			Map cmdMap = DB[i].getMailcapList(mimeType);
			if (cmdMap == null) {
				continue;
			}
			List v = (List)cmdMap.get("content-handler");
			if (v == null) {
				continue;
			}
			String name = (String)v.get(0);
			DataContentHandler dch = getDataContentHandler(name);
			if (dch != null) {
				return dch;
			}
		}

		for (int i = 0; i < DB.length; i++) {
			if (DB[i] == null) {
				continue;
			}
			if (LogSupport.isLoggable()) {
				LogSupport.log("  search fallback DB #" + i);
			}
			Map cmdMap = DB[i].getMailcapFallbackList(mimeType);
			if (cmdMap == null) {
				continue;
			}
			List v = (List)cmdMap.get("content-handler");
			if (v == null) {
				continue;
			}
			String name = (String)v.get(0);
			DataContentHandler dch = getDataContentHandler(name);
			if (dch != null) {
				return dch;
			}
		}

		return null;
	}

	private DataContentHandler getDataContentHandler(String name) {
		if (LogSupport.isLoggable()) {
			LogSupport.log("    got content-handler");
		}
		if (LogSupport.isLoggable()) {
			LogSupport.log("      class " + name);
		}
		Class cl;
		ClassLoader cld = null;
		cld = SecuritySupport.getContextClassLoader();
		if (cld == null) {
			cld = getClass().getClassLoader();
		}
		cl = null;
		try {
			cl = cld.loadClass(name);
		}
		catch (Exception ex) {
			cl = Class.forName(name);
		}
		if (cl != null) {
			return (DataContentHandler)cl.newInstance();
		}
		break MISSING_BLOCK_LABEL_186;
		IllegalAccessException e;
		e;
		if (LogSupport.isLoggable()) {
			LogSupport.log("Can't load DCH " + name, e);
		}
		break MISSING_BLOCK_LABEL_186;
		e;
		if (LogSupport.isLoggable()) {
			LogSupport.log("Can't load DCH " + name, e);
		}
		break MISSING_BLOCK_LABEL_186;
		e;
		if (LogSupport.isLoggable()) {
			LogSupport.log("Can't load DCH " + name, e);
		}
		return null;
	}

	public synchronized String[] getMimeTypes() {
		List mtList = new ArrayList();
		for (int i = 0; i < DB.length; i++) {
			if (DB[i] == null) {
				continue;
			}
			String ts[] = DB[i].getMimeTypes();
			if (ts == null) {
				continue;
			}
			for (int j = 0; j < ts.length; j++) {
				if (!mtList.contains(ts[j])) {
					mtList.add(ts[j]);
				}
			}

		}

		String mts[] = new String[mtList.size()];
		mts = (String[])(String[])mtList.toArray(mts);
		return mts;
	}

	public synchronized String[] getNativeCommands(String mimeType) {
		List cmdList = new ArrayList();
		if (mimeType != null) {
			mimeType = mimeType.toLowerCase();
		}
		for (int i = 0; i < DB.length; i++) {
			if (DB[i] == null) {
				continue;
			}
			String cmds[] = DB[i].getNativeCommands(mimeType);
			if (cmds == null) {
				continue;
			}
			for (int j = 0; j < cmds.length; j++) {
				if (!cmdList.contains(cmds[j])) {
					cmdList.add(cmds[j]);
				}
			}

		}

		String cmds[] = new String[cmdList.size()];
		cmds = (String[])(String[])cmdList.toArray(cmds);
		return cmds;
	}

}
