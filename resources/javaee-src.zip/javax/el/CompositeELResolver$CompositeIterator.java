// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   CompositeELResolver.java

package javax.el;

import java.beans.FeatureDescriptor;
import java.util.Iterator;

// Referenced classes of package javax.el:
//			CompositeELResolver, ELResolver, ELContext

private static class CompositeELResolver$CompositeIterator
	implements Iterator {

	Iterator compositeIter;
	Iterator propertyIter;
	ELContext context;
	Object base;

	public boolean hasNext() {
		if (propertyIter == null || !propertyIter.hasNext()) {
			while (compositeIter.hasNext())  {
				ELResolver elResolver = (ELResolver)compositeIter.next();
				propertyIter = elResolver.getFeatureDescriptors(context, base);
				if (propertyIter != null) {
					return propertyIter.hasNext();
				}
			}
			return false;
		} else {
			return propertyIter.hasNext();
		}
	}

	public FeatureDescriptor next() {
		if (propertyIter == null || !propertyIter.hasNext()) {
			while (compositeIter.hasNext())  {
				ELResolver elResolver = (ELResolver)compositeIter.next();
				propertyIter = elResolver.getFeatureDescriptors(context, base);
				if (propertyIter != null) {
					return (FeatureDescriptor)propertyIter.next();
				}
			}
			return null;
		} else {
			return (FeatureDescriptor)propertyIter.next();
		}
	}

	public void remove() {
		throw new UnsupportedOperationException();
	}

	public volatile Object next() {
		return next();
	}

	CompositeELResolver$CompositeIterator(Iterator iter, ELContext context, Object base) {
		compositeIter = iter;
		this.context = context;
		this.base = base;
	}
}
