// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ListELResolver.java

package javax.el;

import java.util.*;

// Referenced classes of package javax.el:
//			ELResolver, ELContext, PropertyNotFoundException, PropertyNotWritableException

public class ListELResolver extends ELResolver {

	private static Class theUnmodifiableListClass = Collections.unmodifiableList(new ArrayList()).getClass();
	private boolean isReadOnly;

	public ListELResolver() {
		isReadOnly = false;
	}

	public ListELResolver(boolean isReadOnly) {
		this.isReadOnly = isReadOnly;
	}

	public Class getType(ELContext context, Object base, Object property) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base != null && (base instanceof List)) {
			context.setPropertyResolved(true);
			List list = (List)base;
			int index = toInteger(property);
			if (index < 0 || index >= list.size()) {
				throw new PropertyNotFoundException();
			} else {
				return java/lang/Object;
			}
		} else {
			return null;
		}
	}

	public Object getValue(ELContext context, Object base, Object property) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base != null && (base instanceof List)) {
			context.setPropertyResolved(true);
			List list = (List)base;
			int index = toInteger(property);
			if (index < 0 || index >= list.size()) {
				return null;
			} else {
				return list.get(index);
			}
		} else {
			return null;
		}
	}

	public void setValue(ELContext context, Object base, Object property, Object val) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base != null && (base instanceof List)) {
			context.setPropertyResolved(true);
			List list = (List)base;
			int index = toInteger(property);
			if (isReadOnly) {
				throw new PropertyNotWritableException();
			}
			try {
				list.set(index, val);
			}
			catch (UnsupportedOperationException ex) {
				throw new PropertyNotWritableException();
			}
			catch (IndexOutOfBoundsException ex) {
				throw new PropertyNotFoundException();
			}
			catch (ClassCastException ex) {
				throw ex;
			}
			catch (NullPointerException ex) {
				throw ex;
			}
			catch (IllegalArgumentException ex) {
				throw ex;
			}
		}
	}

	public boolean isReadOnly(ELContext context, Object base, Object property) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base != null && (base instanceof List)) {
			context.setPropertyResolved(true);
			List list = (List)base;
			int index = toInteger(property);
			if (index < 0 || index >= list.size()) {
				throw new PropertyNotFoundException();
			} else {
				return list.getClass() == theUnmodifiableListClass || isReadOnly;
			}
		} else {
			return false;
		}
	}

	public Iterator getFeatureDescriptors(ELContext context, Object base) {
		return null;
	}

	public Class getCommonPropertyType(ELContext context, Object base) {
		if (base != null && (base instanceof List)) {
			return java/lang/Integer;
		} else {
			return null;
		}
	}

	private int toInteger(Object p) {
		if (p instanceof Integer) {
			return ((Integer)p).intValue();
		}
		if (p instanceof Character) {
			return ((Character)p).charValue();
		}
		if (p instanceof Boolean) {
			return ((Boolean)p).booleanValue() ? 1 : 0;
		}
		if (p instanceof Number) {
			return ((Number)p).intValue();
		}
		if (p instanceof String) {
			return Integer.parseInt((String)p);
		} else {
			throw new IllegalArgumentException();
		}
	}

}
