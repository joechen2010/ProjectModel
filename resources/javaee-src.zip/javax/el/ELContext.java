// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ELContext.java

package javax.el;

import java.util.HashMap;
import java.util.Locale;

// Referenced classes of package javax.el:
//			ELResolver, FunctionMapper, VariableMapper

public abstract class ELContext {

	private Locale locale;
	private boolean resolved;
	private HashMap map;

	public ELContext() {
		map = new HashMap();
	}

	public void setPropertyResolved(boolean resolved) {
		this.resolved = resolved;
	}

	public boolean isPropertyResolved() {
		return resolved;
	}

	public void putContext(Class key, Object contextObject) {
		if (key == null || contextObject == null) {
			throw new NullPointerException();
		} else {
			map.put(key, contextObject);
			return;
		}
	}

	public Object getContext(Class key) {
		if (key == null) {
			throw new NullPointerException();
		} else {
			return map.get(key);
		}
	}

	public abstract ELResolver getELResolver();

	public abstract FunctionMapper getFunctionMapper();

	public Locale getLocale() {
		return locale;
	}

	public void setLocale(Locale locale) {
		this.locale = locale;
	}

	public abstract VariableMapper getVariableMapper();
}
