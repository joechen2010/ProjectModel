// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ArrayELResolver.java

package javax.el;

import java.lang.reflect.Array;
import java.util.Iterator;

// Referenced classes of package javax.el:
//			ELResolver, ELContext, PropertyNotFoundException, PropertyNotWritableException

public class ArrayELResolver extends ELResolver {

	private boolean isReadOnly;

	public ArrayELResolver() {
		isReadOnly = false;
	}

	public ArrayELResolver(boolean isReadOnly) {
		this.isReadOnly = isReadOnly;
	}

	public Class getType(ELContext context, Object base, Object property) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base != null && base.getClass().isArray()) {
			context.setPropertyResolved(true);
			int index = toInteger(property);
			if (index < 0 || index >= Array.getLength(base)) {
				throw new PropertyNotFoundException();
			} else {
				return base.getClass().getComponentType();
			}
		} else {
			return null;
		}
	}

	public Object getValue(ELContext context, Object base, Object property) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base != null && base.getClass().isArray()) {
			context.setPropertyResolved(true);
			int index = toInteger(property);
			if (index >= 0 && index < Array.getLength(base)) {
				return Array.get(base, index);
			}
		}
		return null;
	}

	public void setValue(ELContext context, Object base, Object property, Object val) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base != null && base.getClass().isArray()) {
			context.setPropertyResolved(true);
			if (isReadOnly) {
				throw new PropertyNotWritableException();
			}
			Class type = base.getClass().getComponentType();
			if (val != null && !type.isAssignableFrom(val.getClass())) {
				throw new ClassCastException();
			}
			int index = toInteger(property);
			if (index < 0 || index >= Array.getLength(base)) {
				throw new PropertyNotFoundException();
			}
			Array.set(base, index, val);
		}
	}

	public boolean isReadOnly(ELContext context, Object base, Object property) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base != null && base.getClass().isArray()) {
			context.setPropertyResolved(true);
			int index = toInteger(property);
			if (index < 0 || index >= Array.getLength(base)) {
				throw new PropertyNotFoundException();
			}
		}
		return isReadOnly;
	}

	public Iterator getFeatureDescriptors(ELContext context, Object base) {
		return null;
	}

	public Class getCommonPropertyType(ELContext context, Object base) {
		if (base != null && base.getClass().isArray()) {
			return java/lang/Integer;
		} else {
			return null;
		}
	}

	private int toInteger(Object p) {
		if (p instanceof Integer) {
			return ((Integer)p).intValue();
		}
		if (p instanceof Character) {
			return ((Character)p).charValue();
		}
		if (p instanceof Boolean) {
			return ((Boolean)p).booleanValue() ? 1 : 0;
		}
		if (p instanceof Number) {
			return ((Number)p).intValue();
		}
		if (p instanceof String) {
			return Integer.parseInt((String)p);
		} else {
			throw new IllegalArgumentException();
		}
	}
}
