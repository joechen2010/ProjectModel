// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   MethodExpression.java

package javax.el;


// Referenced classes of package javax.el:
//			Expression, ELContext, MethodInfo

public abstract class MethodExpression extends Expression {

	public MethodExpression() {
	}

	public abstract MethodInfo getMethodInfo(ELContext elcontext);

	public abstract Object invoke(ELContext elcontext, Object aobj[]);
}
