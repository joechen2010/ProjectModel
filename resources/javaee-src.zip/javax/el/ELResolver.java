// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ELResolver.java

package javax.el;

import java.util.Iterator;

// Referenced classes of package javax.el:
//			ELContext

public abstract class ELResolver {

	public static final String TYPE = "type";
	public static final String RESOLVABLE_AT_DESIGN_TIME = "resolvableAtDesignTime";

	public ELResolver() {
	}

	public abstract Object getValue(ELContext elcontext, Object obj, Object obj1);

	public abstract Class getType(ELContext elcontext, Object obj, Object obj1);

	public abstract void setValue(ELContext elcontext, Object obj, Object obj1, Object obj2);

	public abstract boolean isReadOnly(ELContext elcontext, Object obj, Object obj1);

	public abstract Iterator getFeatureDescriptors(ELContext elcontext, Object obj);

	public abstract Class getCommonPropertyType(ELContext elcontext, Object obj);
}
