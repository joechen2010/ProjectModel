// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   MethodInfo.java

package javax.el;


public class MethodInfo {

	private String name;
	private Class returnType;
	private Class paramTypes[];

	public MethodInfo(String name, Class returnType, Class paramTypes[]) {
		this.name = name;
		this.returnType = returnType;
		this.paramTypes = paramTypes;
	}

	public String getName() {
		return name;
	}

	public Class getReturnType() {
		return returnType;
	}

	public Class[] getParamTypes() {
		return paramTypes;
	}
}
