// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ValueExpression.java

package javax.el;


// Referenced classes of package javax.el:
//			Expression, ELContext

public abstract class ValueExpression extends Expression {

	public ValueExpression() {
	}

	public abstract Object getValue(ELContext elcontext);

	public abstract void setValue(ELContext elcontext, Object obj);

	public abstract boolean isReadOnly(ELContext elcontext);

	public abstract Class getType(ELContext elcontext);

	public abstract Class getExpectedType();
}
