// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ELUtil.java

package javax.el;


// Referenced classes of package javax.el:
//			ELUtil

static class ELUtil$1 extends ThreadLocal {

	protected Object initialValue() {
		return null;
	}

	ELUtil$1() {
	}
}
