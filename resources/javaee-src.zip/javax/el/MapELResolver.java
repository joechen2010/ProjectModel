// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   MapELResolver.java

package javax.el;

import java.beans.FeatureDescriptor;
import java.util.*;

// Referenced classes of package javax.el:
//			ELResolver, ELContext, PropertyNotWritableException

public class MapELResolver extends ELResolver {

	private static Class theUnmodifiableMapClass = Collections.unmodifiableMap(new HashMap()).getClass();
	private boolean isReadOnly;

	public MapELResolver() {
		isReadOnly = false;
	}

	public MapELResolver(boolean isReadOnly) {
		this.isReadOnly = isReadOnly;
	}

	public Class getType(ELContext context, Object base, Object property) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base != null && (base instanceof Map)) {
			context.setPropertyResolved(true);
			return java/lang/Object;
		} else {
			return null;
		}
	}

	public Object getValue(ELContext context, Object base, Object property) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base != null && (base instanceof Map)) {
			context.setPropertyResolved(true);
			Map map = (Map)base;
			return map.get(property);
		} else {
			return null;
		}
	}

	public void setValue(ELContext context, Object base, Object property, Object val) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base != null && (base instanceof Map)) {
			context.setPropertyResolved(true);
			Map map = (Map)base;
			if (isReadOnly || map.getClass() == theUnmodifiableMapClass) {
				throw new PropertyNotWritableException();
			}
			map.put(property, val);
		}
	}

	public boolean isReadOnly(ELContext context, Object base, Object property) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base != null && (base instanceof Map)) {
			context.setPropertyResolved(true);
			Map map = (Map)base;
			return isReadOnly || map.getClass() == theUnmodifiableMapClass;
		} else {
			return false;
		}
	}

	public Iterator getFeatureDescriptors(ELContext context, Object base) {
		if (base != null && (base instanceof Map)) {
			Map map = (Map)base;
			Iterator iter = map.keySet().iterator();
			List list = new ArrayList();
			FeatureDescriptor descriptor;
			for (; iter.hasNext(); list.add(descriptor)) {
				Object key = iter.next();
				descriptor = new FeatureDescriptor();
				String name = key != null ? key.toString() : null;
				descriptor.setName(name);
				descriptor.setDisplayName(name);
				descriptor.setShortDescription("");
				descriptor.setExpert(false);
				descriptor.setHidden(false);
				descriptor.setPreferred(true);
				descriptor.setValue("type", key != null ? ((Object) (key.getClass())) : null);
				descriptor.setValue("resolvableAtDesignTime", Boolean.TRUE);
			}

			return list.iterator();
		} else {
			return null;
		}
	}

	public Class getCommonPropertyType(ELContext context, Object base) {
		if (base != null && (base instanceof Map)) {
			return java/lang/Object;
		} else {
			return null;
		}
	}

}
