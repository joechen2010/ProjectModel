// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   BeanELResolver.java

package javax.el;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;

// Referenced classes of package javax.el:
//			BeanELResolver

protected static final class BeanELResolver$BeanProperty {

	private Method readMethod;
	private Method writeMethod;
	private Class baseClass;
	private PropertyDescriptor descriptor;

	public Class getPropertyType() {
		return descriptor.getPropertyType();
	}

	public boolean isReadOnly() {
		return getWriteMethod() == null;
	}

	public Method getReadMethod() {
		if (readMethod == null) {
			readMethod = BeanELResolver.access$000(baseClass, descriptor.getReadMethod());
		}
		return readMethod;
	}

	public Method getWriteMethod() {
		if (writeMethod == null) {
			writeMethod = BeanELResolver.access$000(baseClass, descriptor.getWriteMethod());
		}
		return writeMethod;
	}

	public BeanELResolver$BeanProperty(Class baseClass, PropertyDescriptor descriptor) {
		this.baseClass = baseClass;
		this.descriptor = descriptor;
	}
}
