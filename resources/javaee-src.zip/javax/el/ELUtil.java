// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ELUtil.java

package javax.el;

import java.text.MessageFormat;
import java.util.*;

// Referenced classes of package javax.el:
//			ELContext

class ELUtil {

	private static ThreadLocal instance = new ThreadLocal() {

		protected Object initialValue() {
			return null;
		}

	};

	private ELUtil() {
	}

	private static Map getCurrentInstance() {
		Map result = (Map)instance.get();
		if (null == result) {
			result = new HashMap();
			setCurrentInstance(result);
		}
		return result;
	}

	private static void setCurrentInstance(Map context) {
		instance.set(context);
	}

	public static String getExceptionMessageString(ELContext context, String messageId) {
		return getExceptionMessageString(context, messageId, null);
	}

	public static String getExceptionMessageString(ELContext context, String messageId, Object params[]) {
		String result = "";
		Locale locale = null;
		if (null == context || null == messageId) {
			return result;
		}
		if (null == (locale = context.getLocale())) {
			locale = Locale.getDefault();
		}
		if (null != locale) {
			Map threadMap = getCurrentInstance();
			ResourceBundle rb = null;
			if (null == (rb = (ResourceBundle)threadMap.get(locale.toString()))) {
				rb = ResourceBundle.getBundle("javax.el.PrivateMessages", locale);
				threadMap.put(locale.toString(), rb);
			}
			if (null != rb) {
				try {
					result = rb.getString(messageId);
					if (null != params) {
						result = MessageFormat.format(result, params);
					}
				}
				catch (IllegalArgumentException iae) {
					result = (new StringBuilder()).append("Can't get localized message: parameters to message appear to be incorrect.  Message to format: ").append(messageId).toString();
				}
				catch (MissingResourceException mre) {
					result = (new StringBuilder()).append("Missing Resource in EL implementation: ???").append(messageId).append("???").toString();
				}
				catch (Exception e) {
					result = (new StringBuilder()).append("Exception resolving message in EL implementation: ???").append(messageId).append("???").toString();
				}
			}
		}
		return result;
	}

}
