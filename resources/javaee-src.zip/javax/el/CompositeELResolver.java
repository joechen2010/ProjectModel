// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   CompositeELResolver.java

package javax.el;

import java.beans.FeatureDescriptor;
import java.util.ArrayList;
import java.util.Iterator;

// Referenced classes of package javax.el:
//			ELResolver, ELContext

public class CompositeELResolver extends ELResolver {
	private static class CompositeIterator
		implements Iterator {

		Iterator compositeIter;
		Iterator propertyIter;
		ELContext context;
		Object base;

		public boolean hasNext() {
			if (propertyIter == null || !propertyIter.hasNext()) {
				while (compositeIter.hasNext())  {
					ELResolver elResolver = (ELResolver)compositeIter.next();
					propertyIter = elResolver.getFeatureDescriptors(context, base);
					if (propertyIter != null) {
						return propertyIter.hasNext();
					}
				}
				return false;
			} else {
				return propertyIter.hasNext();
			}
		}

		public FeatureDescriptor next() {
			if (propertyIter == null || !propertyIter.hasNext()) {
				while (compositeIter.hasNext())  {
					ELResolver elResolver = (ELResolver)compositeIter.next();
					propertyIter = elResolver.getFeatureDescriptors(context, base);
					if (propertyIter != null) {
						return (FeatureDescriptor)propertyIter.next();
					}
				}
				return null;
			} else {
				return (FeatureDescriptor)propertyIter.next();
			}
		}

		public void remove() {
			throw new UnsupportedOperationException();
		}

		public volatile Object next() {
			return next();
		}

		CompositeIterator(Iterator iter, ELContext context, Object base) {
			compositeIter = iter;
			this.context = context;
			this.base = base;
		}
	}


	private final ArrayList elResolvers = new ArrayList();

	public CompositeELResolver() {
	}

	public void add(ELResolver elResolver) {
		if (elResolver == null) {
			throw new NullPointerException();
		} else {
			elResolvers.add(elResolver);
			return;
		}
	}

	public Object getValue(ELContext context, Object base, Object property) {
		context.setPropertyResolved(false);
		int i = 0;
		for (int len = elResolvers.size(); i < len; i++) {
			ELResolver elResolver = (ELResolver)elResolvers.get(i);
			Object value = elResolver.getValue(context, base, property);
			if (context.isPropertyResolved()) {
				return value;
			}
		}

		return null;
	}

	public Class getType(ELContext context, Object base, Object property) {
		context.setPropertyResolved(false);
		int i = 0;
		for (int len = elResolvers.size(); i < len; i++) {
			ELResolver elResolver = (ELResolver)elResolvers.get(i);
			Class type = elResolver.getType(context, base, property);
			if (context.isPropertyResolved()) {
				return type;
			}
		}

		return null;
	}

	public void setValue(ELContext context, Object base, Object property, Object val) {
		context.setPropertyResolved(false);
		int i = 0;
		for (int len = elResolvers.size(); i < len; i++) {
			ELResolver elResolver = (ELResolver)elResolvers.get(i);
			elResolver.setValue(context, base, property, val);
			if (context.isPropertyResolved()) {
				return;
			}
		}

	}

	public boolean isReadOnly(ELContext context, Object base, Object property) {
		context.setPropertyResolved(false);
		int i = 0;
		for (int len = elResolvers.size(); i < len; i++) {
			ELResolver elResolver = (ELResolver)elResolvers.get(i);
			boolean readOnly = elResolver.isReadOnly(context, base, property);
			if (context.isPropertyResolved()) {
				return readOnly;
			}
		}

		return false;
	}

	public Iterator getFeatureDescriptors(ELContext context, Object base) {
		return new CompositeIterator(elResolvers.iterator(), context, base);
	}

	public Class getCommonPropertyType(ELContext context, Object base) {
		Class commonPropertyType = null;
		Iterator iter = elResolvers.iterator();
		do {
			if (!iter.hasNext()) {
				break;
			}
			ELResolver elResolver = (ELResolver)iter.next();
			Class type = elResolver.getCommonPropertyType(context, base);
			if (type != null) {
				if (commonPropertyType == null) {
					commonPropertyType = type;
				} else
				if (!commonPropertyType.isAssignableFrom(type)) {
					if (type.isAssignableFrom(commonPropertyType)) {
						commonPropertyType = type;
					} else {
						return null;
					}
				}
			}
		} while (true);
		return commonPropertyType;
	}
}
