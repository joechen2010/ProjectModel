// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   BeanELResolver.java

package javax.el;

import java.beans.*;
import java.util.HashMap;
import java.util.Map;

// Referenced classes of package javax.el:
//			BeanELResolver, ELException

protected static final class BeanELResolver$BeanProperties {

	private final Class baseClass;
	private final Map propertyMap = new HashMap();

	public BeanELResolver$BeanProperty getBeanProperty(String property) {
		return (BeanELResolver$BeanProperty)propertyMap.get(property);
	}

	public BeanELResolver$BeanProperties(Class baseClass) {
		this.baseClass = baseClass;
		PropertyDescriptor descriptors[];
		try {
			BeanInfo info = Introspector.getBeanInfo(baseClass);
			descriptors = info.getPropertyDescriptors();
		}
		catch (IntrospectionException ie) {
			throw new ELException(ie);
		}
		PropertyDescriptor arr$[] = descriptors;
		int len$ = arr$.length;
		for (int i$ = 0; i$ < len$; i$++) {
			PropertyDescriptor pd = arr$[i$];
			propertyMap.put(pd.getName(), new nit>(baseClass, pd));
		}

	}
}
