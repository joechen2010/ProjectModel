// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UIViewRoot.java

package javax.faces.component;

import java.io.IOException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.el.*;
import javax.faces.FacesException;
import javax.faces.FactoryFinder;
import javax.faces.application.Application;
import javax.faces.application.ViewHandler;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.*;
import javax.faces.lifecycle.Lifecycle;
import javax.faces.lifecycle.LifecycleFactory;

// Referenced classes of package javax.faces.component:
//			UIComponentBase, UIComponent

public class UIViewRoot extends UIComponentBase {

	public static final String COMPONENT_TYPE = "javax.faces.ViewRoot";
	public static final String COMPONENT_FAMILY = "javax.faces.ViewRoot";
	public static final String UNIQUE_ID_PREFIX = "j_id";
	private static Lifecycle lifecycle;
	private static final Logger LOGGER = Logger.getLogger("javax.faces", "javax.faces.LogStrings");
	private int lastId;
	private boolean skipPhase;
	private String renderKitId;
	private String viewId;
	private MethodExpression beforePhase;
	private MethodExpression afterPhase;
	private List phaseListeners;
	private transient List events[];
	private Locale locale;
	private Object values[];

	public UIViewRoot() {
		lastId = 0;
		renderKitId = null;
		viewId = null;
		beforePhase = null;
		afterPhase = null;
		phaseListeners = null;
		events = null;
		locale = null;
		setRendererType(null);
	}

	public String getFamily() {
		return "javax.faces.ViewRoot";
	}

	public String getRenderKitId() {
		String result = null;
		if (null != renderKitId) {
			result = renderKitId;
		} else {
			ValueExpression vb = getValueExpression("renderKitId");
			FacesContext context = getFacesContext();
			if (vb != null) {
				try {
					result = (String)vb.getValue(context.getELContext());
				}
				catch (ELException e) {
					result = null;
				}
			} else {
				result = null;
			}
		}
		return result;
	}

	public void setRenderKitId(String renderKitId) {
		this.renderKitId = renderKitId;
	}

	public String getViewId() {
		return viewId;
	}

	public void setViewId(String viewId) {
		this.viewId = viewId;
	}

	public MethodExpression getBeforePhaseListener() {
		return beforePhase;
	}

	public void setBeforePhaseListener(MethodExpression newBeforePhase) {
		beforePhase = newBeforePhase;
	}

	public MethodExpression getAfterPhaseListener() {
		return afterPhase;
	}

	public void setAfterPhaseListener(MethodExpression newAfterPhase) {
		afterPhase = newAfterPhase;
	}

	public void removePhaseListener(PhaseListener toRemove) {
		if (null != phaseListeners) {
			phaseListeners.remove(toRemove);
		}
	}

	public void addPhaseListener(PhaseListener newPhaseListener) {
		if (null == phaseListeners) {
			phaseListeners = new ArrayList();
		}
		phaseListeners.add(newPhaseListener);
	}

	public void queueEvent(FacesEvent event) {
		if (event == null) {
			throw new NullPointerException();
		}
		int i = 0;
		int len = 0;
		if (events == null) {
			events = new List[len = PhaseId.VALUES.size()];
			for (i = 0; i < len; i++) {
				events[i] = new ArrayList(5);
			}

		}
		events[event.getPhaseId().getOrdinal()].add(event);
	}

	private void broadcastEvents(FacesContext context, PhaseId phaseId) {
		List eventsForPhaseId = null;
		if (null == events) {
			return;
		}
		boolean hasMoreAnyPhaseEvents = true;
		boolean hasMoreCurrentPhaseEvents = true;
		eventsForPhaseId = events[PhaseId.ANY_PHASE.getOrdinal()];
		do {
			if (null != eventsForPhaseId) {
				for (int cursor = 0; cursor < eventsForPhaseId.size();) {
					FacesEvent event = (FacesEvent)eventsForPhaseId.get(cursor);
					UIComponent source = event.getComponent();
					try {
						source.broadcast(event);
						continue;
					}
					catch (AbortProcessingException e) {
						if (!LOGGER.isLoggable(Level.SEVERE)) {
							continue;
						}
						UIComponent component = event.getComponent();
						String id = "";
						if (component != null) {
							id = component.getId();
							if (id == null) {
								id = component.getClientId(context);
							}
						}
						LOGGER.log(Level.SEVERE, "error.component.abortprocessing_thrown", new Object[] {
							event.getClass().getName(), phaseId.toString(), id
						});
						LOGGER.log(Level.SEVERE, e.toString(), e);
						eventsForPhaseId.remove(cursor);
					}
				}

			}
			if (null != (eventsForPhaseId = events[phaseId.getOrdinal()])) {
				for (int cursor = 0; cursor < eventsForPhaseId.size(); eventsForPhaseId.remove(cursor)) {
					FacesEvent event = (FacesEvent)eventsForPhaseId.get(cursor);
					UIComponent source = event.getComponent();
					try {
						source.broadcast(event);
					}
					catch (AbortProcessingException e) { }
				}

			}
			hasMoreAnyPhaseEvents = null != (eventsForPhaseId = events[PhaseId.ANY_PHASE.getOrdinal()]) && eventsForPhaseId.size() > 0;
			hasMoreCurrentPhaseEvents = null != events[phaseId.getOrdinal()] && events[phaseId.getOrdinal()].size() > 0;
		} while (hasMoreAnyPhaseEvents || hasMoreCurrentPhaseEvents);
	}

	public void processDecodes(FacesContext context) {
		skipPhase = false;
		if (null != beforePhase || null != phaseListeners) {
			notifyPhaseListeners(context, PhaseId.APPLY_REQUEST_VALUES, true);
		}
		if (!skipPhase) {
			super.processDecodes(context);
			broadcastEvents(context, PhaseId.APPLY_REQUEST_VALUES);
		}
		if ((context.getRenderResponse() || context.getResponseComplete()) && events != null) {
			for (int i = 0; i < PhaseId.VALUES.size(); i++) {
				List eventList = events[i];
				if (eventList != null) {
					eventList.clear();
				}
			}

			events = null;
		}
		if (null != beforePhase || null != phaseListeners) {
			notifyPhaseListeners(context, PhaseId.APPLY_REQUEST_VALUES, false);
		}
	}

	public void encodeBegin(FacesContext context) throws IOException {
		skipPhase = false;
		if (null != beforePhase || null != phaseListeners) {
			notifyPhaseListeners(context, PhaseId.RENDER_RESPONSE, true);
		}
		if (!skipPhase) {
			super.encodeBegin(context);
		}
	}

	public void encodeEnd(FacesContext context) throws IOException {
		super.encodeEnd(context);
		if (null != afterPhase || null != phaseListeners) {
			notifyPhaseListeners(context, PhaseId.RENDER_RESPONSE, false);
		}
	}

	private void notifyPhaseListeners(FacesContext context, PhaseId phaseId, boolean isBefore) {
		PhaseEvent event = createPhaseEvent(context, phaseId);
		boolean hasPhaseMethodExpression = isBefore && null != beforePhase || !isBefore && null != afterPhase;
		MethodExpression expression = isBefore ? beforePhase : afterPhase;
		if (hasPhaseMethodExpression) {
			try {
				expression.invoke(context.getELContext(), new Object[] {
					event
				});
				skipPhase = context.getResponseComplete() || context.getRenderResponse();
			}
			catch (Exception e) { }
		}
		if (null != phaseListeners) {
			Iterator iter = phaseListeners.iterator();
			PhaseListener curListener = null;
			do {
				if (!iter.hasNext()) {
					break;
				}
				curListener = (PhaseListener)iter.next();
				if (phaseId == curListener.getPhaseId() || PhaseId.ANY_PHASE == curListener.getPhaseId()) {
					try {
						if (isBefore) {
							curListener.beforePhase(event);
						} else {
							curListener.afterPhase(event);
						}
						skipPhase = context.getResponseComplete() || context.getRenderResponse();
					}
					catch (Exception e) { }
				}
			} while (true);
		}
	}

	private PhaseEvent createPhaseEvent(FacesContext context, PhaseId phaseId) throws FacesException {
		if (lifecycle == null) {
			LifecycleFactory lifecycleFactory = (LifecycleFactory)FactoryFinder.getFactory("javax.faces.lifecycle.LifecycleFactory");
			String lifecycleId = context.getExternalContext().getInitParameter("javax.faces.LIFECYCLE_ID");
			if (lifecycleId == null) {
				lifecycleId = "DEFAULT";
			}
			lifecycle = lifecycleFactory.getLifecycle(lifecycleId);
		}
		return new PhaseEvent(context, phaseId, lifecycle);
	}

	public void processValidators(FacesContext context) {
		skipPhase = false;
		if (null != beforePhase || null != phaseListeners) {
			notifyPhaseListeners(context, PhaseId.PROCESS_VALIDATIONS, true);
		}
		if (!skipPhase) {
			super.processValidators(context);
			broadcastEvents(context, PhaseId.PROCESS_VALIDATIONS);
		}
		if ((context.getRenderResponse() || context.getResponseComplete()) && events != null) {
			for (int i = 0; i < PhaseId.VALUES.size(); i++) {
				List eventList = events[i];
				if (eventList != null) {
					eventList.clear();
				}
			}

			events = null;
		}
		if (null != beforePhase || null != phaseListeners) {
			notifyPhaseListeners(context, PhaseId.PROCESS_VALIDATIONS, false);
		}
	}

	public void processUpdates(FacesContext context) {
		skipPhase = false;
		if (null != beforePhase || null != phaseListeners) {
			notifyPhaseListeners(context, PhaseId.UPDATE_MODEL_VALUES, true);
		}
		if (!skipPhase) {
			super.processUpdates(context);
			broadcastEvents(context, PhaseId.UPDATE_MODEL_VALUES);
		}
		if ((context.getRenderResponse() || context.getResponseComplete()) && events != null) {
			for (int i = 0; i < PhaseId.VALUES.size(); i++) {
				List eventList = events[i];
				if (eventList != null) {
					eventList.clear();
				}
			}

			events = null;
		}
		if (null != beforePhase || null != phaseListeners) {
			notifyPhaseListeners(context, PhaseId.UPDATE_MODEL_VALUES, false);
		}
	}

	public void processApplication(FacesContext context) {
		skipPhase = false;
		if (null != beforePhase || null != phaseListeners) {
			notifyPhaseListeners(context, PhaseId.INVOKE_APPLICATION, true);
		}
		if (!skipPhase) {
			broadcastEvents(context, PhaseId.INVOKE_APPLICATION);
		}
		if ((context.getRenderResponse() || context.getResponseComplete()) && events != null) {
			for (int i = 0; i < PhaseId.VALUES.size(); i++) {
				List eventList = events[i];
				if (eventList != null) {
					eventList.clear();
				}
			}

			events = null;
		}
		if (null != beforePhase || null != phaseListeners) {
			notifyPhaseListeners(context, PhaseId.INVOKE_APPLICATION, false);
		}
	}

	public String createUniqueId() {
		return (new StringBuilder()).append("j_id").append(lastId++).toString();
	}

	public Locale getLocale() {
		Locale result = null;
		if (null != locale) {
			result = locale;
		} else {
			ValueExpression vb = getValueExpression("locale");
			FacesContext context = getFacesContext();
			if (vb != null) {
				Object resultLocale = null;
				try {
					resultLocale = vb.getValue(context.getELContext());
				}
				catch (ELException e) { }
				if (null == resultLocale) {
					result = context.getApplication().getViewHandler().calculateLocale(context);
				} else
				if (resultLocale instanceof Locale) {
					result = (Locale)resultLocale;
				} else
				if (resultLocale instanceof String) {
					result = getLocaleFromString((String)resultLocale);
				}
			} else {
				result = context.getApplication().getViewHandler().calculateLocale(context);
			}
		}
		return result;
	}

	private Locale getLocaleFromString(String localeExpr) {
		Locale result = Locale.getDefault();
		if (localeExpr.indexOf("_") == -1 || localeExpr.indexOf("-") == -1) {
			if (localeExpr.length() == 2) {
				result = new Locale(localeExpr, "");
			}
		} else
		if (localeExpr.length() == 5) {
			String language = localeExpr.substring(0, 1);
			String country = localeExpr.substring(3, 4);
			result = new Locale(language, country);
		}
		return result;
	}

	public void setLocale(Locale locale) {
		this.locale = locale;
		FacesContext.getCurrentInstance().getELContext().setLocale(locale);
	}

	public Object saveState(FacesContext context) {
		if (values == null) {
			values = new Object[8];
		}
		values[0] = super.saveState(context);
		values[1] = renderKitId;
		values[2] = viewId;
		values[3] = locale;
		values[4] = new Integer(lastId);
		values[5] = saveAttachedState(context, beforePhase);
		values[6] = saveAttachedState(context, afterPhase);
		values[7] = saveAttachedState(context, phaseListeners);
		return ((Object) (values));
	}

	public void restoreState(FacesContext context, Object state) {
		values = (Object[])(Object[])state;
		super.restoreState(context, values[0]);
		renderKitId = (String)values[1];
		viewId = (String)values[2];
		locale = (Locale)values[3];
		lastId = ((Integer)values[4]).intValue();
		beforePhase = (MethodExpression)restoreAttachedState(context, values[5]);
		afterPhase = (MethodExpression)restoreAttachedState(context, values[6]);
		phaseListeners = (List)restoreAttachedState(context, values[7]);
	}

}
