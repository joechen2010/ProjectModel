// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UIComponentBase.java

package javax.faces.component;

import java.beans.PropertyDescriptor;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;
import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.component:
//			UIComponentBase

private class UIComponentBase$AttributesMap
	implements Map, Serializable {

	private Map attributes;
	final UIComponentBase this$0;

	public boolean containsKey(Object keyObj) {
		String key = (String)keyObj;
		PropertyDescriptor pd = UIComponentBase.access$400(UIComponentBase.this, key);
		if (pd == null) {
			if (attributes != null) {
				return attributes.containsKey(key);
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	public Object get(Object keyObj) {
		String key;
		PropertyDescriptor pd;
		key = (String)keyObj;
		if (key == null) {
			throw new NullPointerException();
		}
		pd = UIComponentBase.access$400(UIComponentBase.this, key);
		if (pd == null) {
			break MISSING_BLOCK_LABEL_90;
		}
		Method readMethod = pd.getReadMethod();
		if (readMethod != null) {
			return readMethod.invoke(UIComponentBase.this, UIComponentBase.access$500());
		}
		try {
			throw new IllegalArgumentException(key);
		}
		catch (IllegalAccessException e) {
			throw new FacesException(e);
		}
		catch (InvocationTargetException e) {
			throw new FacesException(e.getTargetException());
		}
		ValueExpression ve;
		Object result;
		if (attributes != null && attributes.containsKey(key)) {
			return attributes.get(key);
		}
		ve = getValueExpression(key);
		if (ve == null) {
			break MISSING_BLOCK_LABEL_171;
		}
		result = null;
		result = ve.getValue(getFacesContext().getELContext());
		return result;
		ELException e;
		e;
		throw new FacesException(e);
		return null;
	}

	public Object put(Object keyValue, Object value) {
		String key;
		PropertyDescriptor pd;
		if (keyValue == null) {
			throw new NullPointerException();
		}
		if (!(keyValue instanceof String)) {
			throw new ClassCastException("Key must be a String");
		}
		key = keyValue.toString();
		pd = UIComponentBase.access$400(UIComponentBase.this, key);
		if (pd == null) {
			break MISSING_BLOCK_LABEL_149;
		}
		Object result;
		result = null;
		Method readMethod = pd.getReadMethod();
		if (readMethod != null) {
			result = readMethod.invoke(UIComponentBase.this, UIComponentBase.access$500());
		}
		Method writeMethod = pd.getWriteMethod();
		if (writeMethod != null) {
			writeMethod.invoke(UIComponentBase.this, new Object[] {
				value
			});
		} else {
			throw new IllegalArgumentException();
		}
		return result;
		IllegalAccessException e;
		e;
		throw new FacesException(e);
		e;
		throw new FacesException(e.getTargetException());
		if (value == null) {
			throw new NullPointerException();
		}
		if (attributes == null) {
			initMap();
		}
		return attributes.put(key, value);
	}

	public void putAll(Map map) {
		if (map == null) {
			throw new NullPointerException();
		}
		if (attributes == null) {
			initMap();
		}
		attributes.putAll(map);
	}

	public Object remove(Object keyObj) {
		String key = (String)keyObj;
		if (key == null) {
			throw new NullPointerException();
		}
		PropertyDescriptor pd = UIComponentBase.access$400(UIComponentBase.this, key);
		if (pd != null) {
			throw new IllegalArgumentException(key);
		}
		if (attributes != null) {
			return attributes.remove(key);
		} else {
			return null;
		}
	}

	public int size() {
		return attributes == null ? 0 : attributes.size();
	}

	public boolean isEmpty() {
		return attributes == null || attributes.isEmpty();
	}

	public boolean containsValue(Object value) {
		return attributes != null && attributes.containsValue(value);
	}

	public void clear() {
		if (attributes != null) {
			attributes.clear();
		}
	}

	public Set keySet() {
		return attributes == null ? Collections.EMPTY_SET : attributes.keySet();
	}

	public Collection values() {
		return ((Collection) (attributes == null ? Collections.EMPTY_LIST : attributes.values()));
	}

	public Set entrySet() {
		return attributes == null ? Collections.EMPTY_SET : attributes.entrySet();
	}

	Map getBackingAttributes() {
		return attributes;
	}

	public boolean equals(Object o) {
		Map t;
		if (o == this) {
			return true;
		}
		if (!(o instanceof Map)) {
			return false;
		}
		t = (Map)o;
		if (t.size() != size()) {
			return false;
		}
		Iterator i$ = entrySet().iterator();
_L2:
		Object key;
		Object value;
		do {
			if (!i$.hasNext()) {
				break MISSING_BLOCK_LABEL_147;
			}
			Object e = i$.next();
			java.util.Map$Entry entry = (java.util.Map$Entry)e;
			key = entry.entrySet();
			value = entry.getValue();
			if (value != null) {
				continue; /* Loop/switch isn't completed */
			}
		} while (t.get(key) == null && t.containsKey(key));
		return false;
		if (value.equals(t.get(key))) goto _L2; else goto _L1
_L1:
		return false;
		ClassCastException unused;
		unused;
		return false;
		unused;
		return false;
		return true;
	}

	public int hashCode() {
		int h = 0;
		for (Iterator i$ = entrySet().iterator(); i$.hasNext();) {
			Object o = i$.next();
			h += o.hashCode();
		}

		return h;
	}

	private void initMap() {
		attributes = new HashMap(8);
	}

	private UIComponentBase$AttributesMap() {
		this$0 = UIComponentBase.this;
		super();
	}

	private UIComponentBase$AttributesMap(Map attributes) {
		this$0 = UIComponentBase.this;
		super();
		this.attributes = attributes;
	}



	// Unreferenced inner class javax/faces/component/UIComponentBase$1

/* anonymous class */
	static class UIComponentBase._cls1
		implements Iterator {

		public void remove() {
			throw new UnsupportedOperationException();
		}

		public Object next() {
			throw new NoSuchElementException("Empty Iterator");
		}

		public boolean hasNext() {
			return false;
		}

	}

}
