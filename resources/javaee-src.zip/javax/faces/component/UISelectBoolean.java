// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UISelectBoolean.java

package javax.faces.component;

import javax.el.ValueExpression;
import javax.faces.el.ValueBinding;

// Referenced classes of package javax.faces.component:
//			UIInput

public class UISelectBoolean extends UIInput {

	public static final String COMPONENT_TYPE = "javax.faces.SelectBoolean";
	public static final String COMPONENT_FAMILY = "javax.faces.SelectBoolean";

	public UISelectBoolean() {
		setRendererType("javax.faces.Checkbox");
	}

	public String getFamily() {
		return "javax.faces.SelectBoolean";
	}

	public boolean isSelected() {
		Boolean value = (Boolean)getValue();
		if (value != null) {
			return value.booleanValue();
		} else {
			return false;
		}
	}

	public void setSelected(boolean selected) {
		if (selected) {
			setValue(Boolean.TRUE);
		} else {
			setValue(Boolean.FALSE);
		}
	}

	/**
	 * @deprecated Method getValueBinding is deprecated
	 */

	public ValueBinding getValueBinding(String name) {
		if ("selected".equals(name)) {
			return super.getValueBinding("value");
		} else {
			return super.getValueBinding(name);
		}
	}

	/**
	 * @deprecated Method setValueBinding is deprecated
	 */

	public void setValueBinding(String name, ValueBinding binding) {
		if ("selected".equals(name)) {
			super.setValueBinding("value", binding);
		} else {
			super.setValueBinding(name, binding);
		}
	}

	public ValueExpression getValueExpression(String name) {
		if ("selected".equals(name)) {
			return super.getValueExpression("value");
		} else {
			return super.getValueExpression(name);
		}
	}

	public void setValueExpression(String name, ValueExpression binding) {
		if ("selected".equals(name)) {
			super.setValueExpression("value", binding);
		} else {
			super.setValueExpression(name, binding);
		}
	}
}
