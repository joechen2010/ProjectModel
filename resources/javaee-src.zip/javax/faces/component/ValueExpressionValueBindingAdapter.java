// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ValueExpressionValueBindingAdapter.java

package javax.faces.component;

import java.io.Serializable;
import javax.el.*;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;

// Referenced classes of package javax.faces.component:
//			StateHolder

class ValueExpressionValueBindingAdapter extends ValueExpression
	implements Serializable, StateHolder {

	private static final long serialVersionUID = 0x21275a47f66a368bL;
	private ValueBinding binding;
	private boolean tranzient;
	static final boolean $assertionsDisabled = !javax/faces/component/ValueExpressionValueBindingAdapter.desiredAssertionStatus();

	public ValueExpressionValueBindingAdapter() {
		binding = null;
		tranzient = false;
	}

	ValueExpressionValueBindingAdapter(ValueBinding binding) {
		this.binding = null;
		tranzient = false;
		if (!$assertionsDisabled && null == binding) {
			throw new AssertionError();
		} else {
			this.binding = binding;
			return;
		}
	}

	public Object getValue(ELContext context) throws ELException {
		if (!$assertionsDisabled && null == binding) {
			throw new AssertionError();
		}
		if (context == null) {
			throw new NullPointerException("ELContext -> null");
		}
		Object result = null;
		FacesContext facesContext = (FacesContext)context.getContext(javax/faces/context/FacesContext);
		if (!$assertionsDisabled && null == facesContext) {
			throw new AssertionError();
		}
		try {
			result = binding.getValue(facesContext);
		}
		catch (Throwable e) {
			throw new ELException(e);
		}
		return result;
	}

	public void setValue(ELContext context, Object value) throws ELException {
		if (!$assertionsDisabled && null == binding) {
			throw new AssertionError();
		}
		if (context == null) {
			throw new NullPointerException("ELContext -> null");
		}
		FacesContext facesContext = (FacesContext)context.getContext(javax/faces/context/FacesContext);
		if (!$assertionsDisabled && null == facesContext) {
			throw new AssertionError();
		}
		try {
			binding.setValue(facesContext, value);
		}
		catch (Throwable e) {
			throw new ELException(e);
		}
	}

	public boolean isReadOnly(ELContext context) throws ELException {
		if (!$assertionsDisabled && null == binding) {
			throw new AssertionError();
		}
		if (context == null) {
			throw new NullPointerException("ELContext -> null");
		}
		boolean result = false;
		FacesContext facesContext = (FacesContext)context.getContext(javax/faces/context/FacesContext);
		if (!$assertionsDisabled && null == facesContext) {
			throw new AssertionError();
		}
		try {
			result = binding.isReadOnly(facesContext);
		}
		catch (Throwable e) {
			throw new ELException(e);
		}
		return result;
	}

	public Class getType(ELContext context) throws ELException {
		if (!$assertionsDisabled && null == binding) {
			throw new AssertionError();
		}
		if (context == null) {
			throw new NullPointerException("ELContext -> null");
		}
		Class result = null;
		FacesContext facesContext = (FacesContext)context.getContext(javax/faces/context/FacesContext);
		if (!$assertionsDisabled && null == facesContext) {
			throw new AssertionError();
		}
		try {
			result = binding.getType(facesContext);
		}
		catch (Throwable e) {
			throw new ELException(e);
		}
		return result;
	}

	public boolean isLiteralText() {
		return false;
	}

	public Class getExpectedType() {
		if (!$assertionsDisabled && null == binding) {
			throw new AssertionError();
		}
		Class result = null;
		FacesContext context = FacesContext.getCurrentInstance();
		try {
			Object value = binding.getValue(context);
			result = value.getClass();
		}
		catch (Throwable e) {
			result = null;
		}
		return result;
	}

	public String getExpressionString() {
		if (!$assertionsDisabled && null == binding) {
			throw new AssertionError();
		} else {
			return binding.getExpressionString();
		}
	}

	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if (other instanceof ValueExpressionValueBindingAdapter) {
			ValueBinding vb = ((ValueExpressionValueBindingAdapter)other).getWrapped();
			return binding.equals(vb);
		}
		if (other instanceof ValueExpression) {
			FacesContext context = FacesContext.getCurrentInstance();
			ValueExpression otherVE = (ValueExpression)other;
			Class type = binding.getType(context);
			if (type != null) {
				return type.equals(otherVE.getType(context.getELContext()));
			}
		}
		return false;
	}

	public int hashCode() {
		if (!$assertionsDisabled && null == binding) {
			throw new AssertionError();
		} else {
			return binding.hashCode();
		}
	}

	public String getDelimiterSyntax() {
		return "";
	}

	public Object saveState(FacesContext context) {
		Object result = null;
		if (!tranzient) {
			if (binding instanceof StateHolder) {
				Object stateStruct[] = new Object[2];
				stateStruct[0] = ((StateHolder)binding).saveState(context);
				stateStruct[1] = binding.getClass().getName();
				result = ((Object) (stateStruct));
			} else {
				result = binding;
			}
		}
		return result;
	}

	public void restoreState(FacesContext context, Object state) {
		if (null == state) {
			return;
		}
		if (!(state instanceof ValueBinding)) {
			Object stateStruct[] = (Object[])(Object[])state;
			Object savedState = stateStruct[0];
			String className = stateStruct[1].toString();
			ValueBinding result = null;
			Class toRestoreClass = null;
			if (null != className) {
				try {
					toRestoreClass = loadClass(className, this);
				}
				catch (ClassNotFoundException e) {
					throw new IllegalStateException(e.getMessage());
				}
				if (null != toRestoreClass) {
					try {
						result = (ValueBinding)toRestoreClass.newInstance();
					}
					catch (InstantiationException e) {
						throw new IllegalStateException(e.getMessage());
					}
					catch (IllegalAccessException a) {
						throw new IllegalStateException(a.getMessage());
					}
				}
				if (null != result && null != savedState) {
					((StateHolder)result).restoreState(context, savedState);
				}
				binding = result;
			}
		} else {
			binding = (ValueBinding)state;
		}
	}

	public boolean isTransient() {
		return tranzient;
	}

	public void setTransient(boolean newTransientValue) {
		tranzient = newTransientValue;
	}

	private static Class loadClass(String name, Object fallbackClass) throws ClassNotFoundException {
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		if (loader == null) {
			loader = fallbackClass.getClass().getClassLoader();
		}
		return Class.forName(name, true, loader);
	}

	public ValueBinding getWrapped() {
		return binding;
	}

}
