// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   EditableValueHolder.java

package javax.faces.component;

import javax.faces.el.MethodBinding;
import javax.faces.event.ValueChangeListener;
import javax.faces.validator.Validator;

// Referenced classes of package javax.faces.component:
//			ValueHolder

public interface EditableValueHolder
	extends ValueHolder {

	public abstract Object getSubmittedValue();

	public abstract void setSubmittedValue(Object obj);

	public abstract boolean isLocalValueSet();

	public abstract void setLocalValueSet(boolean flag);

	public abstract boolean isValid();

	public abstract void setValid(boolean flag);

	public abstract boolean isRequired();

	public abstract void setRequired(boolean flag);

	public abstract boolean isImmediate();

	public abstract void setImmediate(boolean flag);

	/**
	 * @deprecated Method getValidator is deprecated
	 */

	public abstract MethodBinding getValidator();

	/**
	 * @deprecated Method setValidator is deprecated
	 */

	public abstract void setValidator(MethodBinding methodbinding);

	/**
	 * @deprecated Method getValueChangeListener is deprecated
	 */

	public abstract MethodBinding getValueChangeListener();

	/**
	 * @deprecated Method setValueChangeListener is deprecated
	 */

	public abstract void setValueChangeListener(MethodBinding methodbinding);

	public abstract void addValidator(Validator validator);

	public abstract Validator[] getValidators();

	public abstract void removeValidator(Validator validator);

	public abstract void addValueChangeListener(ValueChangeListener valuechangelistener);

	public abstract ValueChangeListener[] getValueChangeListeners();

	public abstract void removeValueChangeListener(ValueChangeListener valuechangelistener);
}
