// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UIComponentBase.java

package javax.faces.component;

import java.util.Iterator;
import java.util.Map;

// Referenced classes of package javax.faces.component:
//			UIComponentBase

private static class UIComponentBase$FacetsMapEntrySetIterator
	implements Iterator {

	private UIComponentBase$FacetsMap map;
	private Iterator iterator;
	private java.util.SetIterator.next last;

	public boolean hasNext() {
		return iterator.hasNext();
	}

	public java.util.Map$Entry next() {
		last = new UIComponentBase$FacetsMapEntrySetEntry(map, (String)iterator.next());
		return last;
	}

	public void remove() {
		if (last == null) {
			throw new IllegalStateException();
		} else {
			map.remove(last.getKey());
			last = null;
			return;
		}
	}

	public volatile Object next() {
		return next();
	}

	public UIComponentBase$FacetsMapEntrySetIterator(UIComponentBase$FacetsMap map) {
		this.map = null;
		iterator = null;
		last = null;
		this.map = map;
		iterator = map.iterator();
	}
}
