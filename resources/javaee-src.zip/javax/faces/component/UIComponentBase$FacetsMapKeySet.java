// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UIComponentBase.java

package javax.faces.component;

import java.util.*;

// Referenced classes of package javax.faces.component:
//			UIComponentBase

private static class UIComponentBase$FacetsMapKeySet extends AbstractSet {

	private UIComponentBase$FacetsMap map;

	public boolean add(String o) {
		throw new UnsupportedOperationException();
	}

	public boolean addAll(Collection c) {
		throw new UnsupportedOperationException();
	}

	public void clear() {
		map.clear();
	}

	public boolean contains(Object o) {
		return map.nsKey(o);
	}

	public boolean containsAll(Collection c) {
		for (Iterator v = c.iterator(); v.hasNext();) {
			if (!map.nsKey(v.next())) {
				return false;
			}
		}

		return true;
	}

	public boolean isEmpty() {
		return map.size() == 0;
	}

	public Iterator iterator() {
		return new terator(map);
	}

	public boolean remove(Object o) {
		if (map.nsKey(o)) {
			map.(o);
			return true;
		} else {
			return false;
		}
	}

	public boolean removeAll(Collection c) {
		boolean result = false;
		Iterator v = c.iterator();
		do {
			if (!v.hasNext()) {
				break;
			}
			Object o = v.next();
			if (map.nsKey(o)) {
				map.(o);
				result = true;
			}
		} while (true);
		return result;
	}

	public boolean retainAll(Collection c) {
		boolean result = false;
		Iterator v = iterator();
		do {
			if (!v.hasNext()) {
				break;
			}
			if (!c.contains(v.next())) {
				v.remove();
				result = true;
			}
		} while (true);
		return result;
	}

	public int size() {
		return map.size();
	}

	public volatile boolean add(Object x0) {
		return add((String)x0);
	}

	public UIComponentBase$FacetsMapKeySet(UIComponentBase$FacetsMap map) {
		this.map = null;
		this.map = map;
	}
}
