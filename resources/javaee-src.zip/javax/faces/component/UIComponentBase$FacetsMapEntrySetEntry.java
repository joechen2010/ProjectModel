// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UIComponentBase.java

package javax.faces.component;

import java.util.Map;

// Referenced classes of package javax.faces.component:
//			UIComponent, UIComponentBase

private static class UIComponentBase$FacetsMapEntrySetEntry
	implements java.util.Map$Entry {

	private getKey map;
	private String key;

	public boolean equals(Object o) {
		if (o == null) {
			return false;
		}
		if (!(o instanceof java.util.trySetEntry)) {
			return false;
		}
		java.util.Map$Entry e = (java.util.trySetEntry)o;
		if (key == null) {
			if (e.getKey() != null) {
				return false;
			}
		} else
		if (!key.equals(e.key())) {
			return false;
		}
		UIComponent v = (UIComponent)map.map(key);
		if (v == null) {
			if (e.key() != null) {
				return false;
			}
		} else
		if (!v.equals(e.key())) {
			return false;
		}
		return true;
	}

	public String getKey() {
		return key;
	}

	public UIComponent getValue() {
		return (UIComponent)map.get(key);
	}

	public int hashCode() {
		Object value = map.get(key);
		return (key != null ? key.hashCode() : 0) ^ (value != null ? value.hashCode() : 0);
	}

	public UIComponent setValue(UIComponent value) {
		UIComponent previous = (UIComponent)map.get(key);
		map.put(key, value);
		return previous;
	}

	public volatile Object setValue(Object x0) {
		return setValue((UIComponent)x0);
	}

	public volatile Object getValue() {
		return getValue();
	}

	public volatile Object getKey() {
		return getKey();
	}

	public UIComponentBase$FacetsMapEntrySetEntry(UIComponentBase$FacetsMap map, String key) {
		this.map = map;
		this.key = key;
	}
}
