// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UIData.java

package javax.faces.component;

import javax.faces.event.*;

// Referenced classes of package javax.faces.component:
//			UIComponent

class WrapperEvent extends FacesEvent {

	private FacesEvent event;
	private int rowIndex;

	public WrapperEvent(UIComponent component, FacesEvent event, int rowIndex) {
		super(component);
		this.event = null;
		this.rowIndex = -1;
		this.event = event;
		this.rowIndex = rowIndex;
	}

	public FacesEvent getFacesEvent() {
		return event;
	}

	public int getRowIndex() {
		return rowIndex;
	}

	public PhaseId getPhaseId() {
		return event.getPhaseId();
	}

	public void setPhaseId(PhaseId phaseId) {
		event.setPhaseId(phaseId);
	}

	public boolean isAppropriateListener(FacesListener listener) {
		return false;
	}

	public void processListener(FacesListener listener) {
		throw new IllegalStateException();
	}
}
