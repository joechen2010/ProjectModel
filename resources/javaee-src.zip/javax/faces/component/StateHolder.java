// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   StateHolder.java

package javax.faces.component;

import javax.faces.context.FacesContext;

public interface StateHolder {

	public abstract Object saveState(FacesContext facescontext);

	public abstract void restoreState(FacesContext facescontext, Object obj);

	public abstract boolean isTransient();

	public abstract void setTransient(boolean flag);
}
