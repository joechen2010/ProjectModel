// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UIComponentBase.java

package javax.faces.component;

import java.util.*;

// Referenced classes of package javax.faces.component:
//			UIComponentBase

private static class UIComponentBase$FacetsMapEntrySet extends AbstractSet {

	private add map;

	public boolean add(java.util.Map$Entry o) {
		throw new UnsupportedOperationException();
	}

	public boolean addAll(Collection c) {
		throw new UnsupportedOperationException();
	}

	public void clear() {
		map.clear();
	}

	public boolean contains(Object o) {
		if (o == null) {
			throw new NullPointerException();
		}
		if (!(o instanceof java.util.Map$Entry)) {
			return false;
		}
		java.util.Map$Entry e = (java.util.Map$Entry)o;
		Object k = e.getKey();
		Object v = e.getValue();
		if (!map.Key(k)) {
			return false;
		}
		if (v == null) {
			return map.get(k) == null;
		} else {
			return v.equals(map.get(k));
		}
	}

	public boolean isEmpty() {
		return map.isEmpty();
	}

	public Iterator iterator() {
		return new terator(map);
	}

	public boolean remove(Object o) {
		if (o == null) {
			throw new NullPointerException();
		}
		if (!(o instanceof java.util.Map$Entry)) {
			return false;
		}
		Object k = ((java.util.Map$Entry)o).getKey();
		if (map.Key(k)) {
			map.remove(k);
			return true;
		} else {
			return false;
		}
	}

	public boolean removeAll(Collection c) {
		boolean result = false;
		Iterator v = c.iterator();
		do {
			if (!v.hasNext()) {
				break;
			}
			if (remove(v.next())) {
				result = true;
			}
		} while (true);
		return result;
	}

	public boolean retainAll(Collection c) {
		boolean result = false;
		Iterator v = iterator();
		do {
			if (!v.hasNext()) {
				break;
			}
			if (!c.contains(v.next())) {
				v.remove();
				result = true;
			}
		} while (true);
		return result;
	}

	public int size() {
		return map.map();
	}

	public volatile boolean add(Object x0) {
		return add((java.util.Map$Entry)x0);
	}

	public UIComponentBase$FacetsMapEntrySet(UIComponentBase$FacetsMap map) {
		this.map = null;
		this.map = map;
	}
}
