// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ValueBindingValueExpressionAdapter.java

package javax.faces.component;

import java.io.Serializable;
import javax.el.ELException;
import javax.el.PropertyNotFoundException;
import javax.el.PropertyNotWritableException;
import javax.el.ValueExpression;
import javax.faces.context.FacesContext;
import javax.faces.el.EvaluationException;
import javax.faces.el.ValueBinding;

// Referenced classes of package javax.faces.component:
//			StateHolder, ValueExpressionValueBindingAdapter

class ValueBindingValueExpressionAdapter extends ValueBinding
	implements StateHolder, Serializable {

	private static final long serialVersionUID = 0x90c340949b68a546L;
	private ValueExpression valueExpression;
	private boolean tranzient;
	static final boolean $assertionsDisabled = !javax/faces/component/ValueBindingValueExpressionAdapter.desiredAssertionStatus();

	public ValueBindingValueExpressionAdapter() {
		valueExpression = null;
	}

	ValueBindingValueExpressionAdapter(ValueExpression valueExpression) {
		this.valueExpression = null;
		this.valueExpression = valueExpression;
	}

	public String getExpressionString() {
		if (!$assertionsDisabled && null == valueExpression) {
			throw new AssertionError();
		} else {
			return valueExpression.getExpressionString();
		}
	}

	public Class getType(FacesContext context) throws EvaluationException, javax.faces.el.PropertyNotFoundException {
		if (context == null) {
			throw new NullPointerException("FacesContext -> null");
		}
		Class result = null;
		try {
			result = valueExpression.getType(context.getELContext());
		}
		catch (PropertyNotFoundException pnfe) {
			throw new javax.faces.el.PropertyNotFoundException(pnfe);
		}
		catch (ELException elex) {
			throw new EvaluationException(elex);
		}
		return result;
	}

	public Object getValue(FacesContext context) throws EvaluationException, javax.faces.el.PropertyNotFoundException {
		if (context == null) {
			throw new NullPointerException("FacesContext -> null");
		}
		Object result = null;
		try {
			result = valueExpression.getValue(context.getELContext());
		}
		catch (PropertyNotFoundException pnfe) {
			throw new javax.faces.el.PropertyNotFoundException(pnfe);
		}
		catch (ELException elex) {
			throw new EvaluationException(elex);
		}
		return result;
	}

	public boolean isReadOnly(FacesContext context) throws EvaluationException, javax.faces.el.PropertyNotFoundException {
		if (context == null) {
			throw new NullPointerException("FacesContext -> null");
		}
		boolean result = false;
		try {
			result = valueExpression.isReadOnly(context.getELContext());
		}
		catch (ELException elex) {
			throw new EvaluationException(elex);
		}
		return result;
	}

	public void setValue(FacesContext context, Object value) throws EvaluationException, javax.faces.el.PropertyNotFoundException {
		if (context == null) {
			throw new NullPointerException("FacesContext -> null");
		}
		try {
			valueExpression.setValue(context.getELContext(), value);
		}
		catch (PropertyNotFoundException pnfe) {
			throw new javax.faces.el.PropertyNotFoundException(pnfe);
		}
		catch (PropertyNotWritableException pnwe) {
			throw new javax.faces.el.PropertyNotFoundException(pnwe);
		}
		catch (ELException elex) {
			throw new EvaluationException(elex);
		}
	}

	public boolean isTransient() {
		return tranzient;
	}

	public void setTransient(boolean tranzient) {
		this.tranzient = tranzient;
	}

	public Object saveState(FacesContext context) {
		Object result = null;
		if (!tranzient) {
			if (valueExpression instanceof StateHolder) {
				Object stateStruct[] = new Object[2];
				stateStruct[0] = ((StateHolder)valueExpression).saveState(context);
				stateStruct[1] = valueExpression.getClass().getName();
				result = ((Object) (stateStruct));
			} else {
				result = valueExpression;
			}
		}
		return result;
	}

	public void restoreState(FacesContext context, Object state) {
		if (null == state) {
			return;
		}
		if (!(state instanceof ValueExpression)) {
			Object stateStruct[] = (Object[])(Object[])state;
			Object savedState = stateStruct[0];
			String className = stateStruct[1].toString();
			ValueExpression result = null;
			Class toRestoreClass = null;
			if (null != className) {
				try {
					toRestoreClass = loadClass(className, this);
				}
				catch (ClassNotFoundException e) {
					throw new IllegalStateException(e.getMessage());
				}
				if (null != toRestoreClass) {
					try {
						result = (ValueExpression)toRestoreClass.newInstance();
					}
					catch (InstantiationException e) {
						throw new IllegalStateException(e.getMessage());
					}
					catch (IllegalAccessException a) {
						throw new IllegalStateException(a.getMessage());
					}
				}
				if (null != result && null != savedState) {
					((StateHolder)result).restoreState(context, savedState);
				}
				valueExpression = result;
			}
		} else {
			valueExpression = (ValueExpression)state;
		}
	}

	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if (other instanceof ValueExpressionValueBindingAdapter) {
			ValueExpression expr = ((ValueBindingValueExpressionAdapter)other).getWrapped();
			return valueExpression.equals(expr);
		}
		if (other instanceof ValueBinding) {
			FacesContext context = FacesContext.getCurrentInstance();
			ValueBinding otherVB = (ValueBinding)other;
			Class type = otherVB.getType(context);
			if (type != null) {
				return type.equals(valueExpression.getType(context.getELContext()));
			}
		}
		return false;
	}

	public int hashCode() {
		if (!$assertionsDisabled && null == valueExpression) {
			throw new AssertionError();
		} else {
			return valueExpression.hashCode();
		}
	}

	public ValueExpression getWrapped() {
		return valueExpression;
	}

	private static Class loadClass(String name, Object fallbackClass) throws ClassNotFoundException {
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		if (loader == null) {
			loader = fallbackClass.getClass().getClassLoader();
		}
		return Class.forName(name, true, loader);
	}

}
