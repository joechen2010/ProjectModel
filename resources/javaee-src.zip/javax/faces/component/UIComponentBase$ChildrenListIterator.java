// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UIComponentBase.java

package javax.faces.component;

import java.util.ListIterator;
import java.util.NoSuchElementException;

// Referenced classes of package javax.faces.component:
//			UIComponent, UIComponentBase

private static class UIComponentBase$ChildrenListIterator
	implements ListIterator {

	private next list;
	private int index;
	private int last;

	public boolean hasNext() {
		return index < list.size();
	}

	public UIComponent next() {
		UIComponent o;
		o = (UIComponent)list.get(index);
		last = index++;
		return o;
		IndexOutOfBoundsException e;
		e;
		throw new NoSuchElementException((new StringBuilder()).append("").append(index).toString());
	}

	public void remove() {
		if (last == -1) {
			throw new IllegalStateException();
		}
		list.remove(last);
		if (last < index) {
			index--;
		}
		last = -1;
	}

	public void add(UIComponent o) {
		last = -1;
		list.add(index++, o);
	}

	public boolean hasPrevious() {
		return index > 1;
	}

	public int nextIndex() {
		return index;
	}

	public UIComponent previous() {
		UIComponent o;
		int current = index - 1;
		o = (UIComponent)list.get(current);
		last = current;
		index = current;
		return o;
		IndexOutOfBoundsException e;
		e;
		throw new NoSuchElementException();
	}

	public int previousIndex() {
		return index - 1;
	}

	public void set(UIComponent o) {
		if (last == -1) {
			throw new IllegalStateException();
		} else {
			list.set(last, o);
			return;
		}
	}

	public volatile void add(Object x0) {
		add((UIComponent)x0);
	}

	public volatile void set(Object x0) {
		set((UIComponent)x0);
	}

	public volatile Object previous() {
		return previous();
	}

	public volatile Object next() {
		return next();
	}

	public UIComponentBase$ChildrenListIterator(UIComponentBase$ChildrenList list) {
		last = -1;
		this.list = list;
		index = 0;
	}

	public UIComponentBase$ChildrenListIterator(UIComponentBase$ChildrenList list, int index) {
		last = -1;
		this.list = list;
		if (index < 0 || index >= list.size()) {
			throw new IndexOutOfBoundsException((new StringBuilder()).append("").append(index).toString());
		} else {
			this.index = index;
			return;
		}
	}
}
