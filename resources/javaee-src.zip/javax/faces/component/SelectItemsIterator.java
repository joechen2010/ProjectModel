// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   SelectItemsIterator.java

package javax.faces.component;

import java.util.*;
import javax.faces.model.SelectItem;

// Referenced classes of package javax.faces.component:
//			UIComponent, UISelectItem, UISelectItems

final class SelectItemsIterator
	implements Iterator {

	private Iterator items;
	private ListIterator kids;

	public SelectItemsIterator(UIComponent parent) {
		items = null;
		kids = null;
		kids = parent.getChildren().listIterator();
	}

	public boolean hasNext() {
		if (items != null) {
			if (items.hasNext()) {
				return true;
			}
			items = null;
		}
		Object next = findNextValidChild();
		if (next != null) {
			kids.previous();
			return true;
		} else {
			return false;
		}
	}

	public SelectItem next() {
		if (!hasNext()) {
			throw new NoSuchElementException();
		}
		if (items != null) {
			return (SelectItem)items.next();
		}
		UIComponent kid = (UIComponent)findNextValidChild();
		if (kid instanceof UISelectItem) {
			UISelectItem ui = (UISelectItem)kid;
			SelectItem item = (SelectItem)ui.getValue();
			if (item == null) {
				item = new SelectItem(ui.getItemValue(), ui.getItemLabel(), ui.getItemDescription(), ui.isItemDisabled(), ui.isItemEscaped());
			}
			return item;
		}
		if (kid instanceof UISelectItems) {
			UISelectItems ui = (UISelectItems)kid;
			Object value = ui.getValue();
			if (value instanceof SelectItem) {
				return (SelectItem)value;
			}
			if (value instanceof SelectItem[]) {
				items = Arrays.asList((SelectItem[])(SelectItem[])value).iterator();
				return next();
			}
			if (value instanceof List) {
				items = ((List)value).iterator();
				return next();
			}
			if (value instanceof Map) {
				List list = new ArrayList();
				Iterator keys = ((Map)value).keySet().iterator();
				do {
					if (!keys.hasNext()) {
						break;
					}
					Object key = keys.next();
					if (key != null) {
						Object val = ((Map)value).get(key);
						if (val != null) {
							list.add(new SelectItem(val, key.toString(), null));
						}
					}
				} while (true);
				items = list.iterator();
				return next();
			} else {
				throw new IllegalArgumentException();
			}
		} else {
			throw new NoSuchElementException();
		}
	}

	public void remove() {
		throw new UnsupportedOperationException();
	}

	private Object findNextValidChild() {
		if (kids.hasNext()) {
			Object next;
			for (next = kids.next(); kids.hasNext() && !(next instanceof UISelectItem) && !(next instanceof UISelectItems); next = kids.next()) { }
			if ((next instanceof UISelectItem) || (next instanceof UISelectItems)) {
				return next;
			}
		}
		return null;
	}

	public volatile Object next() {
		return next();
	}
}
