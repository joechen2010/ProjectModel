// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UIInput.java

package javax.faces.component;

import java.lang.reflect.Array;
import java.util.*;
import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.el.MethodBinding;
import javax.faces.event.ValueChangeEvent;
import javax.faces.event.ValueChangeListener;
import javax.faces.render.Renderer;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

// Referenced classes of package javax.faces.component:
//			UIOutput, EditableValueHolder, MessageFactory, MethodBindingValidator, 
//			MethodBindingValueChangeListener

public class UIInput extends UIOutput
	implements EditableValueHolder {

	public static final String COMPONENT_TYPE = "javax.faces.Input";
	public static final String COMPONENT_FAMILY = "javax.faces.Input";
	public static final String CONVERSION_MESSAGE_ID = "javax.faces.component.UIInput.CONVERSION";
	public static final String REQUIRED_MESSAGE_ID = "javax.faces.component.UIInput.REQUIRED";
	public static final String UPDATE_MESSAGE_ID = "javax.faces.component.UIInput.UPDATE";
	private Object submittedValue;
	private boolean localValueSet;
	private boolean required;
	private boolean requiredSet;
	private String requiredMessage;
	private boolean requiredMessageSet;
	private String converterMessage;
	private boolean converterMessageSet;
	private String validatorMessage;
	private boolean validatorMessageSet;
	private boolean valid;
	private boolean immediate;
	private boolean immediateSet;
	List validators;
	private Object values[];

	public UIInput() {
		submittedValue = null;
		required = false;
		requiredSet = false;
		requiredMessage = null;
		requiredMessageSet = false;
		converterMessage = null;
		converterMessageSet = false;
		validatorMessage = null;
		validatorMessageSet = false;
		valid = true;
		immediate = false;
		immediateSet = false;
		validators = null;
		setRendererType("javax.faces.Text");
	}

	public String getFamily() {
		return "javax.faces.Input";
	}

	public Object getSubmittedValue() {
		return submittedValue;
	}

	public void setSubmittedValue(Object submittedValue) {
		this.submittedValue = submittedValue;
	}

	public void setValue(Object value) {
		super.setValue(value);
		setLocalValueSet(true);
	}

	public void resetValue() {
		setValue(null);
		setSubmittedValue(null);
		setLocalValueSet(false);
		setValid(true);
	}

	public boolean isLocalValueSet() {
		return localValueSet;
	}

	public void setLocalValueSet(boolean localValueSet) {
		this.localValueSet = localValueSet;
	}

	public boolean isRequired() {
		ValueExpression ve;
		if (requiredSet) {
			return required;
		}
		ve = getValueExpression("required");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_51;
		}
		return Boolean.TRUE.equals(ve.getValue(getFacesContext().getELContext()));
		ELException e;
		e;
		throw new FacesException(e);
		return required;
	}

	public String getRequiredMessage() {
		ValueExpression ve;
		if (requiredMessageSet) {
			return requiredMessage;
		}
		ve = getValueExpression("requiredMessage");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_48;
		}
		return (String)ve.getValue(getFacesContext().getELContext());
		ELException e;
		e;
		throw new FacesException(e);
		return requiredMessage;
	}

	public void setRequiredMessage(String message) {
		requiredMessageSet = true;
		requiredMessage = message;
	}

	public String getConverterMessage() {
		ValueExpression ve;
		if (converterMessageSet) {
			return converterMessage;
		}
		ve = getValueExpression("converterMessage");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_48;
		}
		return (String)ve.getValue(getFacesContext().getELContext());
		ELException e;
		e;
		throw new FacesException(e);
		return converterMessage;
	}

	public void setConverterMessage(String message) {
		converterMessageSet = true;
		converterMessage = message;
	}

	public String getValidatorMessage() {
		ValueExpression ve;
		if (validatorMessageSet) {
			return validatorMessage;
		}
		ve = getValueExpression("validatorMessage");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_48;
		}
		return (String)ve.getValue(getFacesContext().getELContext());
		ELException e;
		e;
		throw new FacesException(e);
		return validatorMessage;
	}

	public void setValidatorMessage(String message) {
		validatorMessageSet = true;
		validatorMessage = message;
	}

	public boolean isValid() {
		return valid;
	}

	public void setValid(boolean valid) {
		this.valid = valid;
	}

	public void setRequired(boolean required) {
		this.required = required;
		requiredSet = true;
	}

	public boolean isImmediate() {
		ValueExpression ve;
		if (immediateSet) {
			return immediate;
		}
		ve = getValueExpression("immediate");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_51;
		}
		return Boolean.TRUE.equals(ve.getValue(getFacesContext().getELContext()));
		ELException e;
		e;
		throw new FacesException(e);
		return immediate;
	}

	public void setImmediate(boolean immediate) {
		if (immediate != this.immediate) {
			this.immediate = immediate;
		}
		immediateSet = true;
	}

	/**
	 * @deprecated Method getValidator is deprecated
	 */

	public MethodBinding getValidator() {
		MethodBinding result = null;
		Validator curValidators[] = getValidators();
		if (null != curValidators) {
			int i = 0;
			do {
				if (i >= curValidators.length) {
					break;
				}
				if (javax/faces/component/MethodBindingValidator == curValidators[i].getClass()) {
					result = ((MethodBindingValidator)curValidators[i]).getWrapped();
					break;
				}
				i++;
			} while (true);
		}
		return result;
	}

	/**
	 * @deprecated Method setValidator is deprecated
	 */

	public void setValidator(MethodBinding validatorBinding) {
		Validator curValidators[] = getValidators();
		if (null != curValidators) {
			for (int i = 0; i < curValidators.length; i++) {
				if (null == validatorBinding) {
					if (javax/faces/component/MethodBindingValidator == curValidators[i].getClass()) {
						removeValidator(curValidators[i]);
						return;
					}
					continue;
				}
				if (validatorBinding != curValidators[i]) {
					continue;
				}
				removeValidator(curValidators[i]);
				break;
			}

		}
		addValidator(new MethodBindingValidator(validatorBinding));
	}

	public MethodBinding getValueChangeListener() {
		MethodBinding result = null;
		ValueChangeListener curListeners[] = getValueChangeListeners();
		if (null != curListeners) {
			int i = 0;
			do {
				if (i >= curListeners.length) {
					break;
				}
				if (javax/faces/component/MethodBindingValueChangeListener == curListeners[i].getClass()) {
					result = ((MethodBindingValueChangeListener)curListeners[i]).getWrapped();
					break;
				}
				i++;
			} while (true);
		}
		return result;
	}

	/**
	 * @deprecated Method setValueChangeListener is deprecated
	 */

	public void setValueChangeListener(MethodBinding valueChangeListener) {
		ValueChangeListener curListeners[] = getValueChangeListeners();
		if (null != curListeners) {
			for (int i = 0; i < curListeners.length; i++) {
				if (null == valueChangeListener) {
					if (javax/faces/component/MethodBindingValueChangeListener == curListeners[i].getClass()) {
						removeFacesListener(curListeners[i]);
						return;
					}
					continue;
				}
				if (valueChangeListener != curListeners[i]) {
					continue;
				}
				removeFacesListener(curListeners[i]);
				break;
			}

		}
		addValueChangeListener(new MethodBindingValueChangeListener(valueChangeListener));
	}

	public void processDecodes(FacesContext context) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (!isRendered()) {
			return;
		}
		super.processDecodes(context);
		if (isImmediate()) {
			executeValidate(context);
		}
	}

	public void processValidators(FacesContext context) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (!isRendered()) {
			return;
		}
		super.processValidators(context);
		if (!isImmediate()) {
			executeValidate(context);
		}
	}

	public void processUpdates(FacesContext context) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (!isRendered()) {
			return;
		}
		super.processUpdates(context);
		try {
			updateModel(context);
		}
		catch (RuntimeException e) {
			context.renderResponse();
			throw e;
		}
		if (!isValid()) {
			context.renderResponse();
		}
	}

	public void decode(FacesContext context) {
		if (context == null) {
			throw new NullPointerException();
		} else {
			setValid(true);
			super.decode(context);
			return;
		}
	}

	public void updateModel(FacesContext context) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (!isValid() || !isLocalValueSet()) {
			return;
		}
		ValueExpression ve = getValueExpression("value");
		if (ve != null) {
			try {
				ve.setValue(context.getELContext(), getLocalValue());
				setValue(null);
				setLocalValueSet(false);
				return;
			}
			catch (ELException e) {
				String messageStr = e.getMessage();
				for (Throwable result = e.getCause(); null != result && result.getClass().isAssignableFrom(javax/el/ELException); result = result.getCause()) {
					messageStr = result.getMessage();
				}

				FacesMessage message = null;
				if (null == messageStr) {
					message = MessageFactory.getMessage(context, "javax.faces.component.UIInput.UPDATE", new Object[] {
						MessageFactory.getLabel(context, this)
					});
				} else {
					message = new FacesMessage(messageStr);
				}
				message.setSeverity(FacesMessage.SEVERITY_ERROR);
				context.addMessage(getClientId(context), message);
				setValid(false);
			}
			catch (IllegalArgumentException e) {
				FacesMessage message = MessageFactory.getMessage(context, "javax.faces.component.UIInput.UPDATE", new Object[] {
					MessageFactory.getLabel(context, this)
				});
				message.setSeverity(FacesMessage.SEVERITY_ERROR);
				context.addMessage(getClientId(context), message);
				setValid(false);
			}
			catch (Exception e) {
				FacesMessage message = MessageFactory.getMessage(context, "javax.faces.component.UIInput.UPDATE", new Object[] {
					MessageFactory.getLabel(context, this)
				});
				message.setSeverity(FacesMessage.SEVERITY_ERROR);
				context.addMessage(getClientId(context), message);
				setValid(false);
			}
		}
	}

	public void validate(FacesContext context) {
		if (context == null) {
			throw new NullPointerException();
		}
		Object submittedValue = getSubmittedValue();
		if (submittedValue == null) {
			return;
		}
		Object newValue = null;
		try {
			newValue = getConvertedValue(context, submittedValue);
		}
		catch (ConverterException ce) {
			addConversionErrorMessage(context, ce, submittedValue);
			setValid(false);
		}
		validateValue(context, newValue);
		if (isValid()) {
			Object previous = getValue();
			setValue(newValue);
			setSubmittedValue(null);
			if (compareValues(previous, newValue)) {
				queueEvent(new ValueChangeEvent(this, previous, newValue));
			}
		}
	}

	protected Object getConvertedValue(FacesContext context, Object newSubmittedValue) throws ConverterException {
		Renderer renderer = getRenderer(context);
		Object newValue = null;
		if (renderer != null) {
			newValue = renderer.getConvertedValue(context, this, newSubmittedValue);
		} else
		if (newSubmittedValue instanceof String) {
			Converter converter = getConverterWithType(context);
			if (converter != null) {
				newValue = converter.getAsObject(context, this, (String)newSubmittedValue);
			} else {
				newValue = newSubmittedValue;
			}
		} else {
			newValue = newSubmittedValue;
		}
		return newValue;
	}

	protected void validateValue(FacesContext context, Object newValue) {
		if (isValid() && isRequired() && isEmpty(newValue)) {
			String requiredMessageStr = getRequiredMessage();
			FacesMessage message = null;
			if (null != requiredMessageStr) {
				message = new FacesMessage(requiredMessageStr, requiredMessageStr);
			} else {
				message = MessageFactory.getMessage(context, "javax.faces.component.UIInput.REQUIRED", new Object[] {
					MessageFactory.getLabel(context, this)
				});
			}
			message.setSeverity(FacesMessage.SEVERITY_ERROR);
			context.addMessage(getClientId(context), message);
			setValid(false);
		}
		if (isValid() && !isEmpty(newValue) && this.validators != null) {
			Iterator validators = this.validators.iterator();
			do {
				if (!validators.hasNext()) {
					break;
				}
				Validator validator = (Validator)validators.next();
				try {
					validator.validate(context, this, newValue);
				}
				catch (ValidatorException ve) {
					setValid(false);
					FacesMessage message = null;
					String validatorMessageString = getValidatorMessage();
					if (null != validatorMessageString) {
						message = new FacesMessage(validatorMessageString, validatorMessageString);
					} else {
						message = ve.getFacesMessage();
					}
					if (message != null) {
						message.setSeverity(FacesMessage.SEVERITY_ERROR);
						context.addMessage(getClientId(context), message);
					}
				}
			} while (true);
		}
	}

	protected boolean compareValues(Object previous, Object value) {
		if (previous == null) {
			return value != null;
		}
		if (value == null) {
			return true;
		} else {
			return !previous.equals(value);
		}
	}

	private void executeValidate(FacesContext context) {
		try {
			validate(context);
		}
		catch (RuntimeException e) {
			context.renderResponse();
			throw e;
		}
		if (!isValid()) {
			context.renderResponse();
		}
	}

	private boolean isEmpty(Object value) {
		if (value == null) {
			return true;
		}
		if ((value instanceof String) && ((String)value).length() < 1) {
			return true;
		}
		if (value.getClass().isArray()) {
			if (0 == Array.getLength(value)) {
				return true;
			}
		} else
		if ((value instanceof List) && 0 == ((List)value).size()) {
			return true;
		}
		return false;
	}

	public void addValidator(Validator validator) {
		if (validator == null) {
			throw new NullPointerException();
		}
		if (validators == null) {
			validators = new ArrayList();
		}
		validators.add(validator);
	}

	public Validator[] getValidators() {
		if (validators == null) {
			return new Validator[0];
		} else {
			return (Validator[])(Validator[])validators.toArray(new Validator[validators.size()]);
		}
	}

	public void removeValidator(Validator validator) {
		if (validators != null) {
			validators.remove(validator);
		}
	}

	public void addValueChangeListener(ValueChangeListener listener) {
		addFacesListener(listener);
	}

	public ValueChangeListener[] getValueChangeListeners() {
		return (ValueChangeListener[])(ValueChangeListener[])getFacesListeners(javax/faces/event/ValueChangeListener);
	}

	public void removeValueChangeListener(ValueChangeListener listener) {
		removeFacesListener(listener);
	}

	public Object saveState(FacesContext context) {
		if (values == null) {
			values = new Object[14];
		}
		values[0] = super.saveState(context);
		values[1] = localValueSet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[2] = required ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[3] = requiredSet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[4] = requiredMessage;
		values[5] = requiredMessageSet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[6] = converterMessage;
		values[7] = converterMessageSet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[8] = validatorMessage;
		values[9] = validatorMessageSet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[10] = valid ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[11] = immediate ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[12] = immediateSet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[13] = saveAttachedState(context, validators);
		return ((Object) (values));
	}

	public void restoreState(FacesContext context, Object state) {
		values = (Object[])(Object[])state;
		super.restoreState(context, values[0]);
		localValueSet = ((Boolean)values[1]).booleanValue();
		required = ((Boolean)values[2]).booleanValue();
		requiredSet = ((Boolean)values[3]).booleanValue();
		requiredMessage = (String)values[4];
		requiredMessageSet = ((Boolean)values[5]).booleanValue();
		converterMessage = (String)values[6];
		converterMessageSet = ((Boolean)values[7]).booleanValue();
		validatorMessage = (String)values[8];
		validatorMessageSet = ((Boolean)values[9]).booleanValue();
		valid = ((Boolean)values[10]).booleanValue();
		immediate = ((Boolean)values[11]).booleanValue();
		immediateSet = ((Boolean)values[12]).booleanValue();
		List restoredValidators = null;
		Iterator iter = null;
		if (null != (restoredValidators = (List)restoreAttachedState(context, values[13]))) {
			if (null != validators) {
				for (iter = restoredValidators.iterator(); iter.hasNext(); validators.add(iter.next())) { }
			} else {
				validators = restoredValidators;
			}
		}
	}

	private Converter getConverterWithType(FacesContext context) {
		Class converterType;
		Exception e;
		Converter converter = getConverter();
		if (converter != null) {
			return converter;
		}
		ValueExpression valueExpression = getValueExpression("value");
		if (valueExpression == null) {
			return null;
		}
		converterType = null;
		try {
			converterType = valueExpression.getType(context.getELContext());
		}
		// Misplaced declaration of an exception variable
		catch (Exception e) {
			throw new FacesException(e);
		}
		if (converterType == null || converterType == java/lang/String || converterType == java/lang/Object) {
			return null;
		}
		Application application = context.getApplication();
		return application.createConverter(converterType);
		application;
		return null;
	}

	private void addConversionErrorMessage(FacesContext context, ConverterException ce, Object value) {
		FacesMessage message = null;
		String converterMessageString = getConverterMessage();
		if (null != converterMessageString) {
			message = new FacesMessage(converterMessageString, converterMessageString);
		} else {
			message = ce.getFacesMessage();
			if (message == null) {
				message = MessageFactory.getMessage(context, "javax.faces.component.UIInput.CONVERSION", new Object[0]);
				if (message.getDetail() == null) {
					message.setDetail(ce.getMessage());
				}
			}
		}
		message.setSeverity(FacesMessage.SEVERITY_ERROR);
		context.addMessage(getClientId(context), message);
	}
}
