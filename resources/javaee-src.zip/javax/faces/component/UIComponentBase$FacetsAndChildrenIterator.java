// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UIComponentBase.java

package javax.faces.component;

import java.util.*;

// Referenced classes of package javax.faces.component:
//			UIComponent, UIComponentBase

private static final class UIComponentBase$FacetsAndChildrenIterator
	implements Iterator {

	private Iterator iterator;
	private boolean childMode;
	private UIComponent c;

	private void update() {
		if (iterator == null) {
			if (c.getFacetCount() != 0) {
				iterator = c.getFacets().values().iterator();
				childMode = false;
			} else
			if (c.getChildCount() != 0) {
				iterator = c.getChildren().iterator();
				childMode = true;
			} else {
				iterator = UIComponentBase.access$700();
				childMode = true;
			}
		} else
		if (!childMode && !iterator.hasNext() && c.getChildCount() != 0) {
			iterator = c.getChildren().iterator();
			childMode = true;
		}
	}

	public boolean hasNext() {
		update();
		return iterator.hasNext();
	}

	public UIComponent next() {
		update();
		return (UIComponent)iterator.next();
	}

	public void remove() {
		throw new UnsupportedOperationException();
	}

	public volatile Object next() {
		return next();
	}

	public UIComponentBase$FacetsAndChildrenIterator(UIComponent c) {
		this.c = c;
		childMode = false;
	}
}
