// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   HtmlInputHidden.java

package javax.faces.component.html;

import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;

public class HtmlInputHidden extends UIInput {

	public static final String COMPONENT_TYPE = "javax.faces.HtmlInputHidden";
	private Object _values[];

	public HtmlInputHidden() {
		setRendererType("javax.faces.Hidden");
	}

	public Object saveState(FacesContext _context) {
		if (_values == null) {
			_values = new Object[1];
		}
		_values[0] = super.saveState(_context);
		return ((Object) (_values));
	}

	public void restoreState(FacesContext _context, Object _state) {
		_values = (Object[])(Object[])_state;
		super.restoreState(_context, _values[0]);
	}
}
