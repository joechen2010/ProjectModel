// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   HtmlSelectOneRadio.java

package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UISelectOne;
import javax.faces.context.FacesContext;

public class HtmlSelectOneRadio extends UISelectOne {

	public static final String COMPONENT_TYPE = "javax.faces.HtmlSelectOneRadio";
	private String accesskey;
	private int border;
	private boolean border_set;
	private String dir;
	private boolean disabled;
	private boolean disabled_set;
	private String disabledClass;
	private String enabledClass;
	private String label;
	private String lang;
	private String layout;
	private String onblur;
	private String onchange;
	private String onclick;
	private String ondblclick;
	private String onfocus;
	private String onkeydown;
	private String onkeypress;
	private String onkeyup;
	private String onmousedown;
	private String onmousemove;
	private String onmouseout;
	private String onmouseover;
	private String onmouseup;
	private String onselect;
	private boolean readonly;
	private boolean readonly_set;
	private String style;
	private String styleClass;
	private String tabindex;
	private String title;
	private Object _values[];

	public HtmlSelectOneRadio() {
		border = 0x80000000;
		border_set = false;
		disabled = false;
		disabled_set = false;
		readonly = false;
		readonly_set = false;
		setRendererType("javax.faces.Radio");
	}

	public String getAccesskey() {
		if (null != accesskey) {
			return accesskey;
		}
		ValueExpression _ve = getValueExpression("accesskey");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setAccesskey(String accesskey) {
		this.accesskey = accesskey;
	}

	public int getBorder() {
		if (border_set) {
			return border;
		}
		ValueExpression _ve = getValueExpression("border");
		if (_ve != null) {
			Object _result = _ve.getValue(getFacesContext().getELContext());
			if (_result == null) {
				return 0x80000000;
			} else {
				return ((Integer)_result).intValue();
			}
		} else {
			return border;
		}
	}

	public void setBorder(int border) {
		this.border = border;
		border_set = true;
	}

	public String getDir() {
		if (null != dir) {
			return dir;
		}
		ValueExpression _ve = getValueExpression("dir");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setDir(String dir) {
		this.dir = dir;
	}

	public boolean isDisabled() {
		if (disabled_set) {
			return disabled;
		}
		ValueExpression _ve = getValueExpression("disabled");
		if (_ve != null) {
			Object _result = _ve.getValue(getFacesContext().getELContext());
			if (_result == null) {
				return false;
			} else {
				return ((Boolean)_result).booleanValue();
			}
		} else {
			return disabled;
		}
	}

	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
		disabled_set = true;
	}

	public String getDisabledClass() {
		if (null != disabledClass) {
			return disabledClass;
		}
		ValueExpression _ve = getValueExpression("disabledClass");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setDisabledClass(String disabledClass) {
		this.disabledClass = disabledClass;
	}

	public String getEnabledClass() {
		if (null != enabledClass) {
			return enabledClass;
		}
		ValueExpression _ve = getValueExpression("enabledClass");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setEnabledClass(String enabledClass) {
		this.enabledClass = enabledClass;
	}

	public String getLabel() {
		if (null != label) {
			return label;
		}
		ValueExpression _ve = getValueExpression("label");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getLang() {
		if (null != lang) {
			return lang;
		}
		ValueExpression _ve = getValueExpression("lang");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

	public String getLayout() {
		if (null != layout) {
			return layout;
		}
		ValueExpression _ve = getValueExpression("layout");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setLayout(String layout) {
		this.layout = layout;
	}

	public String getOnblur() {
		if (null != onblur) {
			return onblur;
		}
		ValueExpression _ve = getValueExpression("onblur");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setOnblur(String onblur) {
		this.onblur = onblur;
	}

	public String getOnchange() {
		if (null != onchange) {
			return onchange;
		}
		ValueExpression _ve = getValueExpression("onchange");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setOnchange(String onchange) {
		this.onchange = onchange;
	}

	public String getOnclick() {
		if (null != onclick) {
			return onclick;
		}
		ValueExpression _ve = getValueExpression("onclick");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setOnclick(String onclick) {
		this.onclick = onclick;
	}

	public String getOndblclick() {
		if (null != ondblclick) {
			return ondblclick;
		}
		ValueExpression _ve = getValueExpression("ondblclick");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setOndblclick(String ondblclick) {
		this.ondblclick = ondblclick;
	}

	public String getOnfocus() {
		if (null != onfocus) {
			return onfocus;
		}
		ValueExpression _ve = getValueExpression("onfocus");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setOnfocus(String onfocus) {
		this.onfocus = onfocus;
	}

	public String getOnkeydown() {
		if (null != onkeydown) {
			return onkeydown;
		}
		ValueExpression _ve = getValueExpression("onkeydown");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setOnkeydown(String onkeydown) {
		this.onkeydown = onkeydown;
	}

	public String getOnkeypress() {
		if (null != onkeypress) {
			return onkeypress;
		}
		ValueExpression _ve = getValueExpression("onkeypress");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setOnkeypress(String onkeypress) {
		this.onkeypress = onkeypress;
	}

	public String getOnkeyup() {
		if (null != onkeyup) {
			return onkeyup;
		}
		ValueExpression _ve = getValueExpression("onkeyup");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setOnkeyup(String onkeyup) {
		this.onkeyup = onkeyup;
	}

	public String getOnmousedown() {
		if (null != onmousedown) {
			return onmousedown;
		}
		ValueExpression _ve = getValueExpression("onmousedown");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setOnmousedown(String onmousedown) {
		this.onmousedown = onmousedown;
	}

	public String getOnmousemove() {
		if (null != onmousemove) {
			return onmousemove;
		}
		ValueExpression _ve = getValueExpression("onmousemove");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setOnmousemove(String onmousemove) {
		this.onmousemove = onmousemove;
	}

	public String getOnmouseout() {
		if (null != onmouseout) {
			return onmouseout;
		}
		ValueExpression _ve = getValueExpression("onmouseout");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setOnmouseout(String onmouseout) {
		this.onmouseout = onmouseout;
	}

	public String getOnmouseover() {
		if (null != onmouseover) {
			return onmouseover;
		}
		ValueExpression _ve = getValueExpression("onmouseover");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setOnmouseover(String onmouseover) {
		this.onmouseover = onmouseover;
	}

	public String getOnmouseup() {
		if (null != onmouseup) {
			return onmouseup;
		}
		ValueExpression _ve = getValueExpression("onmouseup");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setOnmouseup(String onmouseup) {
		this.onmouseup = onmouseup;
	}

	public String getOnselect() {
		if (null != onselect) {
			return onselect;
		}
		ValueExpression _ve = getValueExpression("onselect");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setOnselect(String onselect) {
		this.onselect = onselect;
	}

	public boolean isReadonly() {
		if (readonly_set) {
			return readonly;
		}
		ValueExpression _ve = getValueExpression("readonly");
		if (_ve != null) {
			Object _result = _ve.getValue(getFacesContext().getELContext());
			if (_result == null) {
				return false;
			} else {
				return ((Boolean)_result).booleanValue();
			}
		} else {
			return readonly;
		}
	}

	public void setReadonly(boolean readonly) {
		this.readonly = readonly;
		readonly_set = true;
	}

	public String getStyle() {
		if (null != style) {
			return style;
		}
		ValueExpression _ve = getValueExpression("style");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setStyle(String style) {
		this.style = style;
	}

	public String getStyleClass() {
		if (null != styleClass) {
			return styleClass;
		}
		ValueExpression _ve = getValueExpression("styleClass");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setStyleClass(String styleClass) {
		this.styleClass = styleClass;
	}

	public String getTabindex() {
		if (null != tabindex) {
			return tabindex;
		}
		ValueExpression _ve = getValueExpression("tabindex");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setTabindex(String tabindex) {
		this.tabindex = tabindex;
	}

	public String getTitle() {
		if (null != title) {
			return title;
		}
		ValueExpression _ve = getValueExpression("title");
		if (_ve != null) {
			return (String)_ve.getValue(getFacesContext().getELContext());
		} else {
			return null;
		}
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Object saveState(FacesContext _context) {
		if (_values == null) {
			_values = new Object[32];
		}
		_values[0] = super.saveState(_context);
		_values[1] = accesskey;
		_values[2] = new Integer(border);
		_values[3] = border_set ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		_values[4] = dir;
		_values[5] = disabled ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		_values[6] = disabled_set ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		_values[7] = disabledClass;
		_values[8] = enabledClass;
		_values[9] = label;
		_values[10] = lang;
		_values[11] = layout;
		_values[12] = onblur;
		_values[13] = onchange;
		_values[14] = onclick;
		_values[15] = ondblclick;
		_values[16] = onfocus;
		_values[17] = onkeydown;
		_values[18] = onkeypress;
		_values[19] = onkeyup;
		_values[20] = onmousedown;
		_values[21] = onmousemove;
		_values[22] = onmouseout;
		_values[23] = onmouseover;
		_values[24] = onmouseup;
		_values[25] = onselect;
		_values[26] = readonly ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		_values[27] = readonly_set ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		_values[28] = style;
		_values[29] = styleClass;
		_values[30] = tabindex;
		_values[31] = title;
		return ((Object) (_values));
	}

	public void restoreState(FacesContext _context, Object _state) {
		_values = (Object[])(Object[])_state;
		super.restoreState(_context, _values[0]);
		accesskey = (String)_values[1];
		border = ((Integer)_values[2]).intValue();
		border_set = ((Boolean)_values[3]).booleanValue();
		dir = (String)_values[4];
		disabled = ((Boolean)_values[5]).booleanValue();
		disabled_set = ((Boolean)_values[6]).booleanValue();
		disabledClass = (String)_values[7];
		enabledClass = (String)_values[8];
		label = (String)_values[9];
		lang = (String)_values[10];
		layout = (String)_values[11];
		onblur = (String)_values[12];
		onchange = (String)_values[13];
		onclick = (String)_values[14];
		ondblclick = (String)_values[15];
		onfocus = (String)_values[16];
		onkeydown = (String)_values[17];
		onkeypress = (String)_values[18];
		onkeyup = (String)_values[19];
		onmousedown = (String)_values[20];
		onmousemove = (String)_values[21];
		onmouseout = (String)_values[22];
		onmouseover = (String)_values[23];
		onmouseup = (String)_values[24];
		onselect = (String)_values[25];
		readonly = ((Boolean)_values[26]).booleanValue();
		readonly_set = ((Boolean)_values[27]).booleanValue();
		style = (String)_values[28];
		styleClass = (String)_values[29];
		tabindex = (String)_values[30];
		title = (String)_values[31];
	}
}
