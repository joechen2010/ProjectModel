// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UIMessage.java

package javax.faces.component;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.component:
//			UIComponentBase

public class UIMessage extends UIComponentBase {

	public static final String COMPONENT_TYPE = "javax.faces.Message";
	public static final String COMPONENT_FAMILY = "javax.faces.Message";
	private String forVal;
	private boolean showDetail;
	private boolean showDetailSet;
	private boolean showSummary;
	private boolean showSummarySet;
	private Object values[];

	public UIMessage() {
		forVal = null;
		showDetail = true;
		showDetailSet = false;
		showSummary = false;
		showSummarySet = false;
		setRendererType("javax.faces.Message");
	}

	public String getFamily() {
		return "javax.faces.Message";
	}

	public String getFor() {
		ValueExpression ve;
		if (forVal != null) {
			return forVal;
		}
		ve = getValueExpression("for");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_48;
		}
		return (String)ve.getValue(getFacesContext().getELContext());
		ELException e;
		e;
		throw new FacesException(e);
		return null;
	}

	public void setFor(String newFor) {
		forVal = newFor;
	}

	public boolean isShowDetail() {
		ValueExpression ve;
		if (showDetailSet) {
			return showDetail;
		}
		ve = getValueExpression("showDetail");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_51;
		}
		return Boolean.TRUE.equals(ve.getValue(getFacesContext().getELContext()));
		ELException e;
		e;
		throw new FacesException(e);
		return showDetail;
	}

	public void setShowDetail(boolean showDetail) {
		this.showDetail = showDetail;
		showDetailSet = true;
	}

	public boolean isShowSummary() {
		ValueExpression ve;
		if (showSummarySet) {
			return showSummary;
		}
		ve = getValueExpression("showSummary");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_59;
		}
		return !Boolean.FALSE.equals(ve.getValue(getFacesContext().getELContext()));
		ELException e;
		e;
		throw new FacesException(e);
		return showSummary;
	}

	public void setShowSummary(boolean showSummary) {
		this.showSummary = showSummary;
		showSummarySet = true;
	}

	public Object saveState(FacesContext context) {
		if (values == null) {
			values = new Object[6];
		}
		values[0] = super.saveState(context);
		values[1] = forVal;
		values[2] = showDetail ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[3] = showDetailSet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[4] = showSummary ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[5] = showSummarySet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		return ((Object) (values));
	}

	public void restoreState(FacesContext context, Object state) {
		values = (Object[])(Object[])state;
		super.restoreState(context, values[0]);
		forVal = (String)values[1];
		showDetail = ((Boolean)values[2]).booleanValue();
		showDetailSet = ((Boolean)values[3]).booleanValue();
		showSummary = ((Boolean)values[4]).booleanValue();
		showSummarySet = ((Boolean)values[5]).booleanValue();
	}
}
