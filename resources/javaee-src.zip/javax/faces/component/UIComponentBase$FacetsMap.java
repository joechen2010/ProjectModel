// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UIComponentBase.java

package javax.faces.component;

import java.util.*;

// Referenced classes of package javax.faces.component:
//			UIComponent, UIComponentBase

private class UIComponentBase$FacetsMap extends HashMap {

	final UIComponentBase this$0;

	public void clear() {
		for (Iterator keys = keySet().iterator(); keys.hasNext(); keys.remove()) {
			String key = (String)keys.next();
		}

		super.clear();
	}

	public Set entrySet() {
		return new ntrySet(this);
	}

	public Set keySet() {
		return new eySet(this);
	}

	public UIComponent put(String key, UIComponent value) {
		if (key == null || value == null) {
			throw new NullPointerException();
		}
		if (!(key instanceof String) || !(value instanceof UIComponent)) {
			throw new ClassCastException();
		}
		UIComponent previous = (UIComponent)super.get(key);
		if (previous != null) {
			previous.setParent(null);
		}
		UIComponentBase.access$600(UIComponentBase.this, value);
		value.setParent(UIComponentBase.this);
		return (UIComponent)super.put(key, value);
	}

	public void putAll(Map map) {
		if (map == null) {
			throw new NullPointerException();
		}
		java.util.Map$Entry entry;
		for (Iterator i$ = map.entrySet().iterator(); i$.hasNext(); put((String)entry.getKey(), (UIComponent)entry.getValue())) {
			entry = (java.util.Map$Entry)i$.next();
		}

	}

	public UIComponent remove(Object key) {
		UIComponent previous = (UIComponent)get(key);
		if (previous != null) {
			previous.setParent(null);
		}
		super.remove(key);
		return previous;
	}

	public Collection values() {
		return new alues(this);
	}

	Iterator keySetIterator() {
		return (new ArrayList(super.keySet())).iterator();
	}

	public volatile Object remove(Object x0) {
		return remove(x0);
	}

	public volatile Object put(Object x0, Object x1) {
		return put((String)x0, (UIComponent)x1);
	}

	private UIComponentBase$FacetsMap() {
		this$0 = UIComponentBase.this;
		super();
	}


	// Unreferenced inner class javax/faces/component/UIComponentBase$1

/* anonymous class */
	static class UIComponentBase._cls1
		implements Iterator {

		public void remove() {
			throw new UnsupportedOperationException();
		}

		public Object next() {
			throw new NoSuchElementException("Empty Iterator");
		}

		public boolean hasNext() {
			return false;
		}

	}

}
