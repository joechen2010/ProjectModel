// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UICommand.java

package javax.faces.component;

import javax.el.*;
import javax.faces.FacesException;
import javax.faces.application.Application;
import javax.faces.context.FacesContext;
import javax.faces.el.MethodBinding;
import javax.faces.event.*;

// Referenced classes of package javax.faces.component:
//			UIComponentBase, ActionSource2, MethodBindingMethodExpressionAdapter, MethodExpressionMethodBindingAdapter

public class UICommand extends UIComponentBase
	implements ActionSource2 {

	public static final String COMPONENT_TYPE = "javax.faces.Command";
	public static final String COMPONENT_FAMILY = "javax.faces.Command";
	private Object value;
	private boolean immediate;
	private boolean immediateSet;
	private MethodBinding methodBindingActionListener;
	private MethodExpression actionExpression;
	private Object values[];

	public UICommand() {
		value = null;
		immediate = false;
		immediateSet = false;
		methodBindingActionListener = null;
		actionExpression = null;
		setRendererType("javax.faces.Button");
	}

	public String getFamily() {
		return "javax.faces.Command";
	}

	/**
	 * @deprecated Method getAction is deprecated
	 */

	public MethodBinding getAction() {
		MethodBinding result = null;
		MethodExpression me = null;
		if (null != (me = getActionExpression())) {
			if (me.getClass() == javax/faces/component/MethodExpressionMethodBindingAdapter) {
				result = ((MethodExpressionMethodBindingAdapter)me).getWrapped();
			} else {
				result = new MethodBindingMethodExpressionAdapter(me);
			}
		}
		return result;
	}

	/**
	 * @deprecated Method setAction is deprecated
	 */

	public void setAction(MethodBinding action) {
		MethodExpressionMethodBindingAdapter adapter = null;
		if (null != action) {
			adapter = new MethodExpressionMethodBindingAdapter(action);
			setActionExpression(adapter);
		} else {
			setActionExpression(null);
		}
	}

	/**
	 * @deprecated Method getActionListener is deprecated
	 */

	public MethodBinding getActionListener() {
		return methodBindingActionListener;
	}

	/**
	 * @deprecated Method setActionListener is deprecated
	 */

	public void setActionListener(MethodBinding actionListener) {
		methodBindingActionListener = actionListener;
	}

	public boolean isImmediate() {
		ValueExpression ve;
		if (immediateSet) {
			return immediate;
		}
		ve = getValueExpression("immediate");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_51;
		}
		return Boolean.TRUE.equals(ve.getValue(getFacesContext().getELContext()));
		ELException e;
		e;
		throw new FacesException(e);
		return immediate;
	}

	public void setImmediate(boolean immediate) {
		if (immediate != this.immediate) {
			this.immediate = immediate;
		}
		immediateSet = true;
	}

	public Object getValue() {
		ValueExpression ve;
		if (value != null) {
			return value;
		}
		ve = getValueExpression("value");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_45;
		}
		return ve.getValue(getFacesContext().getELContext());
		ELException e;
		e;
		throw new FacesException(e);
		return null;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	public MethodExpression getActionExpression() {
		return actionExpression;
	}

	public void setActionExpression(MethodExpression actionExpression) {
		this.actionExpression = actionExpression;
	}

	public void addActionListener(ActionListener listener) {
		addFacesListener(listener);
	}

	public ActionListener[] getActionListeners() {
		ActionListener al[] = (ActionListener[])(ActionListener[])getFacesListeners(javax/faces/event/ActionListener);
		return al;
	}

	public void removeActionListener(ActionListener listener) {
		removeFacesListener(listener);
	}

	public Object saveState(FacesContext context) {
		if (values == null) {
			values = new Object[6];
		}
		values[0] = super.saveState(context);
		values[1] = saveAttachedState(context, methodBindingActionListener);
		values[2] = saveAttachedState(context, actionExpression);
		values[3] = immediate ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[4] = immediateSet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[5] = value;
		return ((Object) (values));
	}

	public void restoreState(FacesContext context, Object state) {
		values = (Object[])(Object[])state;
		super.restoreState(context, values[0]);
		methodBindingActionListener = (MethodBinding)restoreAttachedState(context, values[1]);
		actionExpression = (MethodExpression)restoreAttachedState(context, values[2]);
		immediate = ((Boolean)values[3]).booleanValue();
		immediateSet = ((Boolean)values[4]).booleanValue();
		value = values[5];
	}

	public void broadcast(FacesEvent event) throws AbortProcessingException {
		super.broadcast(event);
		if (event instanceof ActionEvent) {
			FacesContext context = getFacesContext();
			MethodBinding mb = getActionListener();
			if (mb != null) {
				mb.invoke(context, new Object[] {
					event
				});
			}
			ActionListener listener = context.getApplication().getActionListener();
			if (listener != null) {
				listener.processAction((ActionEvent)event);
			}
		}
	}

	public void queueEvent(FacesEvent e) {
		if (e instanceof ActionEvent) {
			if (isImmediate()) {
				e.setPhaseId(PhaseId.APPLY_REQUEST_VALUES);
			} else {
				e.setPhaseId(PhaseId.INVOKE_APPLICATION);
			}
		}
		super.queueEvent(e);
	}
}
