// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UIComponent.java

package javax.faces.component;

import java.io.IOException;
import java.util.*;
import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.event.*;
import javax.faces.render.Renderer;

// Referenced classes of package javax.faces.component:
//			ContextCallback, StateHolder, UIComponentBase, ValueExpressionValueBindingAdapter

public abstract class UIComponent
	implements StateHolder {

	protected Map bindings;
	private boolean isUIComponentBase;
	private boolean isUIComponentBaseIsSet;

	public UIComponent() {
		bindings = null;
		isUIComponentBaseIsSet = false;
	}

	public abstract Map getAttributes();

	/**
	 * @deprecated Method getValueBinding is deprecated
	 */

	public abstract ValueBinding getValueBinding(String s);

	/**
	 * @deprecated Method setValueBinding is deprecated
	 */

	public abstract void setValueBinding(String s, ValueBinding valuebinding);

	public ValueExpression getValueExpression(String name) {
		ValueExpression result = null;
		if (name == null) {
			throw new NullPointerException();
		}
		if (bindings == null) {
			if (!isUIComponentBase()) {
				ValueBinding binding = getValueBinding(name);
				if (null != binding) {
					result = new ValueExpressionValueBindingAdapter(binding);
					bindings = new HashMap();
					bindings.put(name, result);
				}
			}
			return result;
		} else {
			return (ValueExpression)bindings.get(name);
		}
	}

	public void setValueExpression(String name, ValueExpression binding) {
		if (name == null) {
			throw new NullPointerException();
		}
		if ("id".equals(name) || "parent".equals(name)) {
			throw new IllegalArgumentException();
		}
		if (binding != null) {
			if (!binding.isLiteralText()) {
				if (bindings == null) {
					bindings = new HashMap();
				}
				bindings.put(name, binding);
			} else {
				javax.el.ELContext context = FacesContext.getCurrentInstance().getELContext();
				try {
					getAttributes().put(name, binding.getValue(context));
				}
				catch (ELException ele) {
					throw new FacesException(ele);
				}
			}
		} else
		if (bindings != null) {
			bindings.remove(name);
			if (bindings.size() == 0) {
				bindings = null;
			}
		}
	}

	public abstract String getClientId(FacesContext facescontext);

	public String getContainerClientId(FacesContext context) {
		if (context == null) {
			throw new NullPointerException();
		} else {
			return getClientId(context);
		}
	}

	public abstract String getFamily();

	public abstract String getId();

	public abstract void setId(String s);

	public abstract UIComponent getParent();

	public abstract void setParent(UIComponent uicomponent);

	public abstract boolean isRendered();

	public abstract void setRendered(boolean flag);

	public abstract String getRendererType();

	public abstract void setRendererType(String s);

	public abstract boolean getRendersChildren();

	private boolean isUIComponentBase() {
		if (!isUIComponentBaseIsSet) {
			isUIComponentBase = this instanceof UIComponentBase;
		}
		return isUIComponentBase;
	}

	public abstract List getChildren();

	public abstract int getChildCount();

	public abstract UIComponent findComponent(String s);

	public boolean invokeOnComponent(FacesContext context, String clientId, ContextCallback callback) throws FacesException {
		boolean found;
		if (null == context || null == clientId || null == callback) {
			throw new NullPointerException();
		}
		found = false;
		if (!clientId.equals(getClientId(context))) {
			break MISSING_BLOCK_LABEL_60;
		}
		callback.invokeContextCallback(context, this);
		return true;
		Exception e;
		e;
		throw new FacesException(e);
		for (Iterator itr = getFacetsAndChildren(); itr.hasNext() && !found; found = ((UIComponent)itr.next()).invokeOnComponent(context, clientId, callback)) { }
		return found;
	}

	public abstract Map getFacets();

	public int getFacetCount() {
		return getFacets().size();
	}

	public abstract UIComponent getFacet(String s);

	public abstract Iterator getFacetsAndChildren();

	public abstract void broadcast(FacesEvent facesevent) throws AbortProcessingException;

	public abstract void decode(FacesContext facescontext);

	public abstract void encodeBegin(FacesContext facescontext) throws IOException;

	public abstract void encodeChildren(FacesContext facescontext) throws IOException;

	public abstract void encodeEnd(FacesContext facescontext) throws IOException;

	public void encodeAll(FacesContext context) throws IOException {
		if (!isRendered()) {
			return;
		}
		encodeBegin(context);
		if (getRendersChildren()) {
			encodeChildren(context);
		} else
		if (getChildCount() > 0) {
			UIComponent kid;
			for (Iterator kids = getChildren().iterator(); kids.hasNext(); kid.encodeAll(context)) {
				kid = (UIComponent)kids.next();
			}

		}
		encodeEnd(context);
	}

	protected abstract void addFacesListener(FacesListener faceslistener);

	protected abstract FacesListener[] getFacesListeners(Class class1);

	protected abstract void removeFacesListener(FacesListener faceslistener);

	public abstract void queueEvent(FacesEvent facesevent);

	public abstract void processRestoreState(FacesContext facescontext, Object obj);

	public abstract void processDecodes(FacesContext facescontext);

	public abstract void processValidators(FacesContext facescontext);

	public abstract void processUpdates(FacesContext facescontext);

	public abstract Object processSaveState(FacesContext facescontext);

	protected abstract FacesContext getFacesContext();

	protected abstract Renderer getRenderer(FacesContext facescontext);
}
