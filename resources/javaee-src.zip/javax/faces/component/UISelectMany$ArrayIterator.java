// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UISelectMany.java

package javax.faces.component;

import java.util.Iterator;
import java.util.NoSuchElementException;

// Referenced classes of package javax.faces.component:
//			UISelectMany

static class UISelectMany$ArrayIterator
	implements Iterator {

	private Object items[];
	private int index;

	public boolean hasNext() {
		return index < items.length;
	}

	public Object next() {
		return items[index++];
		IndexOutOfBoundsException e;
		e;
		throw new NoSuchElementException();
	}

	public void remove() {
		throw new UnsupportedOperationException();
	}

	public UISelectMany$ArrayIterator(Object items[]) {
		index = 0;
		this.items = items;
	}
}
