// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UIComponentBase.java

package javax.faces.component;

import java.util.Iterator;

// Referenced classes of package javax.faces.component:
//			UIComponent, UIComponentBase

private static class UIComponentBase$FacetsMapValuesIterator
	implements Iterator {

	private UIComponentBase$FacetsMap map;
	private Iterator iterator;
	private Object last;

	public boolean hasNext() {
		return iterator.hasNext();
	}

	public UIComponent next() {
		last = iterator.next();
		return (UIComponent)map.get(last);
	}

	public void remove() {
		if (last == null) {
			throw new IllegalStateException();
		} else {
			map.remove(last);
			last = null;
			return;
		}
	}

	public volatile Object next() {
		return next();
	}

	public UIComponentBase$FacetsMapValuesIterator(UIComponentBase$FacetsMap map) {
		this.map = null;
		iterator = null;
		last = null;
		this.map = map;
		iterator = map.();
	}
}
