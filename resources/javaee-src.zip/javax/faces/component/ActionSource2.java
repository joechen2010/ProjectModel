// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ActionSource2.java

package javax.faces.component;

import javax.el.MethodExpression;

// Referenced classes of package javax.faces.component:
//			ActionSource

public interface ActionSource2
	extends ActionSource {

	public abstract MethodExpression getActionExpression();

	public abstract void setActionExpression(MethodExpression methodexpression);
}
