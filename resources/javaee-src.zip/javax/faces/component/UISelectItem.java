// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UISelectItem.java

package javax.faces.component;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.component:
//			UIComponentBase

public class UISelectItem extends UIComponentBase {

	public static final String COMPONENT_TYPE = "javax.faces.SelectItem";
	public static final String COMPONENT_FAMILY = "javax.faces.SelectItem";
	private String itemDescription;
	private boolean itemDisabled;
	private boolean itemDisabledSet;
	private boolean itemEscaped;
	private boolean itemEscapedSet;
	private String itemLabel;
	private Object itemValue;
	private Object value;
	private Object values[];

	public UISelectItem() {
		itemDescription = null;
		itemDisabled = false;
		itemDisabledSet = false;
		itemEscaped = true;
		itemEscapedSet = false;
		itemLabel = null;
		itemValue = null;
		value = null;
		setRendererType(null);
	}

	public String getFamily() {
		return "javax.faces.SelectItem";
	}

	public String getItemDescription() {
		ValueExpression ve;
		if (itemDescription != null) {
			return itemDescription;
		}
		ve = getValueExpression("itemDescription");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_48;
		}
		return (String)ve.getValue(getFacesContext().getELContext());
		ELException e;
		e;
		throw new FacesException(e);
		return null;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public boolean isItemDisabled() {
		ValueExpression ve;
		if (itemDisabledSet) {
			return itemDisabled;
		}
		ve = getValueExpression("itemDisabled");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_51;
		}
		return Boolean.TRUE.equals(ve.getValue(getFacesContext().getELContext()));
		ELException e;
		e;
		throw new FacesException(e);
		return itemDisabled;
	}

	public void setItemDisabled(boolean itemDisabled) {
		this.itemDisabled = itemDisabled;
		itemDisabledSet = true;
	}

	public boolean isItemEscaped() {
		ValueExpression ve;
		if (itemEscapedSet) {
			return itemEscaped;
		}
		ve = getValueExpression("itemEscaped");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_51;
		}
		return Boolean.TRUE.equals(ve.getValue(getFacesContext().getELContext()));
		ELException e;
		e;
		throw new FacesException(e);
		return itemEscaped;
	}

	public void setItemEscaped(boolean itemEscaped) {
		this.itemEscaped = itemEscaped;
		itemEscapedSet = true;
	}

	public String getItemLabel() {
		ValueExpression ve;
		if (itemLabel != null) {
			return itemLabel;
		}
		ve = getValueExpression("itemLabel");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_48;
		}
		return (String)ve.getValue(getFacesContext().getELContext());
		ELException e;
		e;
		throw new FacesException(e);
		return null;
	}

	public void setItemLabel(String itemLabel) {
		this.itemLabel = itemLabel;
	}

	public Object getItemValue() {
		ValueExpression ve;
		if (itemValue != null) {
			return itemValue;
		}
		ve = getValueExpression("itemValue");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_45;
		}
		return ve.getValue(getFacesContext().getELContext());
		ELException e;
		e;
		throw new FacesException(e);
		return null;
	}

	public void setItemValue(Object itemValue) {
		this.itemValue = itemValue;
	}

	public Object getValue() {
		ValueExpression ve;
		if (value != null) {
			return value;
		}
		ve = getValueExpression("value");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_45;
		}
		return ve.getValue(getFacesContext().getELContext());
		ELException e;
		e;
		throw new FacesException(e);
		return null;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	public Object saveState(FacesContext context) {
		if (values == null) {
			values = new Object[9];
		}
		values[0] = super.saveState(context);
		values[1] = itemDescription;
		values[2] = itemDisabled ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[3] = itemDisabledSet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[4] = itemEscaped ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[5] = itemEscapedSet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[6] = itemLabel;
		values[7] = itemValue;
		values[8] = value;
		return ((Object) (values));
	}

	public void restoreState(FacesContext context, Object state) {
		values = (Object[])(Object[])state;
		super.restoreState(context, values[0]);
		itemDescription = (String)values[1];
		itemDisabled = ((Boolean)values[2]).booleanValue();
		itemDisabledSet = ((Boolean)values[3]).booleanValue();
		itemEscaped = ((Boolean)values[4]).booleanValue();
		itemEscapedSet = ((Boolean)values[5]).booleanValue();
		itemLabel = (String)values[6];
		itemValue = values[7];
		value = values[8];
	}
}
