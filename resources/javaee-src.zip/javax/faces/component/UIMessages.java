// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UIMessages.java

package javax.faces.component;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.component:
//			UIComponentBase

public class UIMessages extends UIComponentBase {

	public static final String COMPONENT_TYPE = "javax.faces.Messages";
	public static final String COMPONENT_FAMILY = "javax.faces.Messages";
	private boolean globalOnly;
	private boolean globalOnlySet;
	private boolean showDetail;
	private boolean showDetailSet;
	private boolean showSummary;
	private boolean showSummarySet;
	private Object values[];

	public UIMessages() {
		globalOnly = false;
		globalOnlySet = false;
		showDetail = false;
		showDetailSet = false;
		showSummary = true;
		showSummarySet = false;
		setRendererType("javax.faces.Messages");
	}

	public String getFamily() {
		return "javax.faces.Messages";
	}

	public boolean isGlobalOnly() {
		ValueExpression ve;
		if (globalOnlySet) {
			return globalOnly;
		}
		ve = getValueExpression("globalOnly");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_51;
		}
		return Boolean.TRUE.equals(ve.getValue(getFacesContext().getELContext()));
		ELException e;
		e;
		throw new FacesException(e);
		return globalOnly;
	}

	public void setGlobalOnly(boolean globalOnly) {
		this.globalOnly = globalOnly;
		globalOnlySet = true;
	}

	public boolean isShowDetail() {
		ValueExpression ve;
		if (showDetailSet) {
			return showDetail;
		}
		ve = getValueExpression("showDetail");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_51;
		}
		return Boolean.TRUE.equals(ve.getValue(getFacesContext().getELContext()));
		ELException e;
		e;
		throw new FacesException(e);
		return showDetail;
	}

	public void setShowDetail(boolean showDetail) {
		this.showDetail = showDetail;
		showDetailSet = true;
	}

	public boolean isShowSummary() {
		ValueExpression ve;
		if (showSummarySet) {
			return showSummary;
		}
		ve = getValueExpression("showSummary");
		if (ve == null) {
			break MISSING_BLOCK_LABEL_59;
		}
		return !Boolean.FALSE.equals(ve.getValue(getFacesContext().getELContext()));
		ELException e;
		e;
		throw new FacesException(e);
		return showSummary;
	}

	public void setShowSummary(boolean showSummary) {
		this.showSummary = showSummary;
		showSummarySet = true;
	}

	public Object saveState(FacesContext context) {
		if (values == null) {
			values = new Object[7];
		}
		values[0] = super.saveState(context);
		values[1] = globalOnly ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[2] = globalOnlySet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[3] = showDetail ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[4] = showDetailSet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[5] = showSummary ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[6] = showSummarySet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		return ((Object) (values));
	}

	public void restoreState(FacesContext context, Object state) {
		values = (Object[])(Object[])state;
		super.restoreState(context, values[0]);
		globalOnly = ((Boolean)values[1]).booleanValue();
		globalOnlySet = ((Boolean)values[2]).booleanValue();
		showDetail = ((Boolean)values[3]).booleanValue();
		showDetailSet = ((Boolean)values[4]).booleanValue();
		showSummary = ((Boolean)values[5]).booleanValue();
		showSummarySet = ((Boolean)values[6]).booleanValue();
	}
}
