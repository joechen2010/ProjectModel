// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   UIComponentBase.java

package javax.faces.component;

import java.util.*;

// Referenced classes of package javax.faces.component:
//			UIComponent, UIComponentBase

private class UIComponentBase$ChildrenList extends ArrayList {

	final UIComponentBase this$0;

	public void add(int index, UIComponent element) {
		if (element == null) {
			throw new NullPointerException();
		}
		if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException();
		} else {
			UIComponentBase.access$600(UIComponentBase.this, element);
			element.setParent(UIComponentBase.this);
			super.add(index, element);
			return;
		}
	}

	public boolean add(UIComponent element) {
		if (element == null) {
			throw new NullPointerException();
		} else {
			UIComponentBase.access$600(UIComponentBase.this, element);
			element.setParent(UIComponentBase.this);
			return super.add(element);
		}
	}

	public boolean addAll(Collection collection) {
		Iterator elements = (new ArrayList(collection)).iterator();
		boolean changed;
		for (changed = false; elements.hasNext(); changed = true) {
			UIComponent element = (UIComponent)elements.next();
			if (element == null) {
				throw new NullPointerException();
			}
			add(element);
		}

		return changed;
	}

	public boolean addAll(int index, Collection collection) {
		Iterator elements = (new ArrayList(collection)).iterator();
		boolean changed;
		for (changed = false; elements.hasNext(); changed = true) {
			UIComponent element = (UIComponent)elements.next();
			if (element == null) {
				throw new NullPointerException();
			}
			add(index++, element);
		}

		return changed;
	}

	public void clear() {
		int n = size();
		if (n < 1) {
			return;
		}
		for (int i = 0; i < n; i++) {
			UIComponent child = (UIComponent)get(i);
			child.setParent(null);
		}

		super.clear();
	}

	public Iterator iterator() {
		return new terator(this);
	}

	public ListIterator listIterator() {
		return new terator(this);
	}

	public ListIterator listIterator(int index) {
		return new terator(this, index);
	}

	public UIComponent remove(int index) {
		UIComponent child = (UIComponent)get(index);
		super.remove(index);
		child.setParent(null);
		return child;
	}

	public boolean remove(Object elementObj) {
		UIComponent element = (UIComponent)elementObj;
		if (element == null) {
			throw new NullPointerException();
		}
		if (super.remove(element)) {
			element.setParent(null);
			return true;
		} else {
			return false;
		}
	}

	public boolean removeAll(Collection collection) {
		boolean result = false;
		Iterator elements = collection.iterator();
		do {
			if (!elements.hasNext()) {
				break;
			}
			if (remove(elements.next())) {
				result = true;
			}
		} while (true);
		return result;
	}

	public boolean retainAll(Collection collection) {
		boolean modified = false;
		Iterator items = iterator();
		do {
			if (!items.hasNext()) {
				break;
			}
			if (!collection.contains(items.next())) {
				items.remove();
				modified = true;
			}
		} while (true);
		return modified;
	}

	public UIComponent set(int index, UIComponent element) {
		if (element == null) {
			throw new NullPointerException();
		}
		if (index < 0 || index >= size()) {
			throw new IndexOutOfBoundsException();
		} else {
			UIComponentBase.access$600(UIComponentBase.this, element);
			UIComponent previous = (UIComponent)get(index);
			previous.setParent(null);
			element.setParent(UIComponentBase.this);
			super.set(index, element);
			return previous;
		}
	}

	public volatile Object remove(int x0) {
		return remove(x0);
	}

	public volatile void add(int x0, Object x1) {
		add(x0, (UIComponent)x1);
	}

	public volatile boolean add(Object x0) {
		return add((UIComponent)x0);
	}

	public volatile Object set(int x0, Object x1) {
		return set(x0, (UIComponent)x1);
	}

	private UIComponentBase$ChildrenList() {
		this$0 = UIComponentBase.this;
		super();
	}


	// Unreferenced inner class javax/faces/component/UIComponentBase$1

/* anonymous class */
	static class UIComponentBase._cls1
		implements Iterator {

		public void remove() {
			throw new UnsupportedOperationException();
		}

		public Object next() {
			throw new NoSuchElementException("Empty Iterator");
		}

		public boolean hasNext() {
			return false;
		}

	}

}
