// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   IntegerConverter.java

package javax.faces.convert;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.convert:
//			Converter, ConverterException, MessageFactory

public class IntegerConverter
	implements Converter {

	public static final String CONVERTER_ID = "javax.faces.Integer";
	public static final String INTEGER_ID = "javax.faces.converter.IntegerConverter.INTEGER";
	public static final String STRING_ID = "javax.faces.converter.STRING";

	public IntegerConverter() {
	}

	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		if (context == null || component == null) {
			throw new NullPointerException();
		}
		if (value == null) {
			return null;
		}
		value = value.trim();
		if (value.length() < 1) {
			return null;
		}
		return Integer.valueOf(value);
		NumberFormatException nfe;
		nfe;
		throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.IntegerConverter.INTEGER", new Object[] {
			value, "9346", MessageFactory.getLabel(context, component)
		}));
		Exception e;
		e;
		throw new ConverterException(e);
	}

	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (context == null || component == null) {
			throw new NullPointerException();
		}
		if (value == null) {
			return "";
		}
		if (value instanceof String) {
			return (String)value;
		}
		return Integer.toString(((Integer)value).intValue());
		Exception e;
		e;
		throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.STRING", new Object[] {
			value, MessageFactory.getLabel(context, component)
		}), e);
	}
}
