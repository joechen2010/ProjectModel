// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   MessageFactory.java

package javax.faces.convert;

import java.text.MessageFormat;
import java.util.Locale;
import javax.el.ValueExpression;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;

// Referenced classes of package javax.faces.convert:
//			MessageFactory

static class MessageFactory$BindingFacesMessage extends FacesMessage {

	private Locale locale;
	private Object parameters[];
	private Object resolvedParameters[];

	public String getSummary() {
		String pattern = super.getSummary();
		resolveBindings();
		return getFormattedString(pattern, resolvedParameters);
	}

	public String getDetail() {
		String pattern = super.getDetail();
		resolveBindings();
		return getFormattedString(pattern, resolvedParameters);
	}

	private void resolveBindings() {
		FacesContext context = null;
		if (parameters != null) {
			for (int i = 0; i < parameters.length; i++) {
				Object o = parameters[i];
				if (o instanceof ValueBinding) {
					if (context == null) {
						context = FacesContext.getCurrentInstance();
					}
					o = ((ValueBinding)o).getValue(context);
				}
				if (o instanceof ValueExpression) {
					if (context == null) {
						context = FacesContext.getCurrentInstance();
					}
					o = ((ValueExpression)o).getValue(context.getELContext());
				}
				if (o == null) {
					o = "";
				}
				resolvedParameters[i] = o;
			}

		}
	}

	private String getFormattedString(String msgtext, Object params[]) {
		String localizedStr = null;
		if (params == null || msgtext == null) {
			return msgtext;
		}
		StringBuffer b = new StringBuffer(100);
		MessageFormat mf = new MessageFormat(msgtext);
		if (locale != null) {
			mf.setLocale(locale);
			b.append(mf.format(((Object) (params))));
			localizedStr = b.toString();
		}
		return localizedStr;
	}

	MessageFactory$BindingFacesMessage(Locale locale, String messageFormat, String detailMessageFormat, Object parameters[]) {
		super(messageFormat, detailMessageFormat);
		this.locale = locale;
		this.parameters = parameters;
		if (parameters != null) {
			resolvedParameters = new Object[parameters.length];
		}
	}
}
