// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   BooleanConverter.java

package javax.faces.convert;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.convert:
//			Converter, ConverterException, MessageFactory

public class BooleanConverter
	implements Converter {

	public static final String CONVERTER_ID = "javax.faces.Boolean";
	public static final String BOOLEAN_ID = "javax.faces.converter.BooleanConverter.BOOLEAN";
	public static final String STRING_ID = "javax.faces.converter.STRING";

	public BooleanConverter() {
	}

	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		if (context == null || component == null) {
			throw new NullPointerException();
		}
		if (value == null) {
			return null;
		}
		value = value.trim();
		if (value.length() < 1) {
			return null;
		}
		return Boolean.valueOf(value);
		Exception e;
		e;
		throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.BooleanConverter.BOOLEAN", new Object[] {
			value, MessageFactory.getLabel(context, component)
		}), e);
	}

	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (context == null || component == null) {
			throw new NullPointerException();
		}
		if (value == null) {
			return "";
		}
		return value.toString();
		Exception e;
		e;
		throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.STRING", new Object[] {
			value, MessageFactory.getLabel(context, component)
		}), e);
	}
}
