// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   NumberConverter.java

package javax.faces.convert;

import java.lang.reflect.Method;
import java.text.*;
import java.util.Locale;
import javax.faces.component.*;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.convert:
//			Converter, ConverterException, MessageFactory

public class NumberConverter
	implements Converter, StateHolder {

	public static final String CONVERTER_ID = "javax.faces.Number";
	public static final String CURRENCY_ID = "javax.faces.converter.NumberConverter.CURRENCY";
	public static final String NUMBER_ID = "javax.faces.converter.NumberConverter.NUMBER";
	public static final String PATTERN_ID = "javax.faces.converter.NumberConverter.PATTERN";
	public static final String PERCENT_ID = "javax.faces.converter.NumberConverter.PERCENT";
	public static final String STRING_ID = "javax.faces.converter.STRING";
	private String currencyCode;
	private String currencySymbol;
	private boolean groupingUsed;
	private boolean integerOnly;
	private int maxFractionDigits;
	private boolean maxFractionDigitsSpecified;
	private int maxIntegerDigits;
	private boolean maxIntegerDigitsSpecified;
	private int minFractionDigits;
	private boolean minFractionDigitsSpecified;
	private int minIntegerDigits;
	private boolean minIntegerDigitsSpecified;
	private Locale locale;
	private String pattern;
	private String type;
	private static Class currencyClass;
	private static final Class GET_INSTANCE_PARAM_TYPES[] = {
		java/lang/String
	};
	private boolean transientFlag;

	public NumberConverter() {
		currencyCode = null;
		currencySymbol = null;
		groupingUsed = true;
		integerOnly = false;
		maxFractionDigits = 0;
		maxFractionDigitsSpecified = false;
		maxIntegerDigits = 0;
		maxIntegerDigitsSpecified = false;
		minFractionDigits = 0;
		minFractionDigitsSpecified = false;
		minIntegerDigits = 0;
		minIntegerDigitsSpecified = false;
		locale = null;
		pattern = null;
		type = "number";
		transientFlag = false;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getCurrencySymbol() {
		return currencySymbol;
	}

	public void setCurrencySymbol(String currencySymbol) {
		this.currencySymbol = currencySymbol;
	}

	public boolean isGroupingUsed() {
		return groupingUsed;
	}

	public void setGroupingUsed(boolean groupingUsed) {
		this.groupingUsed = groupingUsed;
	}

	public boolean isIntegerOnly() {
		return integerOnly;
	}

	public void setIntegerOnly(boolean integerOnly) {
		this.integerOnly = integerOnly;
	}

	public int getMaxFractionDigits() {
		return maxFractionDigits;
	}

	public void setMaxFractionDigits(int maxFractionDigits) {
		this.maxFractionDigits = maxFractionDigits;
		maxFractionDigitsSpecified = true;
	}

	public int getMaxIntegerDigits() {
		return maxIntegerDigits;
	}

	public void setMaxIntegerDigits(int maxIntegerDigits) {
		this.maxIntegerDigits = maxIntegerDigits;
		maxIntegerDigitsSpecified = true;
	}

	public int getMinFractionDigits() {
		return minFractionDigits;
	}

	public void setMinFractionDigits(int minFractionDigits) {
		this.minFractionDigits = minFractionDigits;
		minFractionDigitsSpecified = true;
	}

	public int getMinIntegerDigits() {
		return minIntegerDigits;
	}

	public void setMinIntegerDigits(int minIntegerDigits) {
		this.minIntegerDigits = minIntegerDigits;
		minIntegerDigitsSpecified = true;
	}

	public Locale getLocale() {
		if (locale == null) {
			locale = getLocale(FacesContext.getCurrentInstance());
		}
		return locale;
	}

	public void setLocale(Locale locale) {
		this.locale = locale;
	}

	public String getPattern() {
		return pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		Object returnValue;
		NumberFormat parser;
		if (context == null || component == null) {
			throw new NullPointerException();
		}
		returnValue = null;
		parser = null;
		if (value == null) {
			return null;
		}
		value = value.trim();
		if (value.length() < 1) {
			return null;
		}
		try {
			Locale locale = getLocale(context);
			parser = getNumberFormat(locale);
			if (pattern != null && !pattern.equals("") || "currency".equals(type)) {
				configureCurrency(parser);
			}
			parser.setParseIntegerOnly(isIntegerOnly());
			returnValue = parser.parse(value);
		}
		catch (ParseException e) {
			if (pattern != null) {
				throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.NumberConverter.PATTERN", new Object[] {
					value, "#,##0.0#", MessageFactory.getLabel(context, component)
				}));
			}
			if (type.equals("currency")) {
				throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.NumberConverter.CURRENCY", new Object[] {
					value, parser.format(99.989999999999995D), MessageFactory.getLabel(context, component)
				}));
			}
			if (type.equals("number")) {
				throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.NumberConverter.NUMBER", new Object[] {
					value, parser.format(99L), MessageFactory.getLabel(context, component)
				}));
			}
			if (type.equals("percent")) {
				throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.NumberConverter.PERCENT", new Object[] {
					value, parser.format(0.75D), MessageFactory.getLabel(context, component)
				}));
			}
		}
		catch (ConverterException ce) {
			throw ce;
		}
		catch (Exception e) {
			throw new ConverterException(e.getCause());
		}
		return returnValue;
	}

	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (context == null || component == null) {
			throw new NullPointerException();
		}
		if (value == null) {
			return "";
		}
		if (value instanceof String) {
			return (String)value;
		}
		NumberFormat formatter;
		Locale locale = getLocale(context);
		formatter = getNumberFormat(locale);
		if (pattern != null && !pattern.equals("") || "currency".equals(type)) {
			configureCurrency(formatter);
		}
		configureFormatter(formatter);
		return formatter.format(value);
		ConverterException e;
		e;
		throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.STRING", new Object[] {
			value, MessageFactory.getLabel(context, component)
		}), e);
		e;
		throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.STRING", new Object[] {
			value, MessageFactory.getLabel(context, component)
		}), e);
	}

	private void configureCurrency(NumberFormat formatter) throws Exception {
		String code = null;
		String symbol = null;
		if (currencyCode == null && currencySymbol == null) {
			return;
		}
		if (currencyCode != null && currencySymbol != null) {
			if (currencyClass != null) {
				code = currencyCode;
			} else {
				symbol = currencySymbol;
			}
		} else
		if (currencyCode == null) {
			symbol = currencySymbol;
		} else
		if (currencyClass != null) {
			code = currencyCode;
		} else {
			symbol = currencyCode;
		}
		if (code != null) {
			Object methodArgs[] = new Object[1];
			Method m = currencyClass.getMethod("getInstance", GET_INSTANCE_PARAM_TYPES);
			methodArgs[0] = code;
			Object currency = m.invoke(null, methodArgs);
			Class paramTypes[] = new Class[1];
			paramTypes[0] = currencyClass;
			Class numberFormatClass = Class.forName("java.text.NumberFormat");
			m = numberFormatClass.getMethod("setCurrency", paramTypes);
			methodArgs[0] = currency;
			m.invoke(formatter, methodArgs);
		} else {
			DecimalFormat df = (DecimalFormat)formatter;
			DecimalFormatSymbols dfs = df.getDecimalFormatSymbols();
			dfs.setCurrencySymbol(symbol);
			df.setDecimalFormatSymbols(dfs);
		}
	}

	private void configureFormatter(NumberFormat formatter) {
		formatter.setGroupingUsed(groupingUsed);
		if (maxIntegerDigitsSpecified) {
			formatter.setMaximumIntegerDigits(maxIntegerDigits);
		}
		if (minIntegerDigitsSpecified) {
			formatter.setMinimumIntegerDigits(minIntegerDigits);
		}
		if (maxFractionDigitsSpecified) {
			formatter.setMaximumFractionDigits(maxFractionDigits);
		}
		if (minFractionDigitsSpecified) {
			formatter.setMinimumFractionDigits(minFractionDigits);
		}
	}

	private Locale getLocale(FacesContext context) {
		Locale locale = this.locale;
		if (locale == null) {
			locale = context.getViewRoot().getLocale();
		}
		return locale;
	}

	private NumberFormat getNumberFormat(Locale locale) {
		if (pattern == null && type == null) {
			throw new IllegalArgumentException("Either pattern or type must be specified.");
		}
		if (pattern != null) {
			DecimalFormatSymbols symbols = new DecimalFormatSymbols(locale);
			return new DecimalFormat(pattern, symbols);
		}
		if (type.equals("currency")) {
			return NumberFormat.getCurrencyInstance(locale);
		}
		if (type.equals("number")) {
			return NumberFormat.getNumberInstance(locale);
		}
		if (type.equals("percent")) {
			return NumberFormat.getPercentInstance(locale);
		} else {
			throw new ConverterException(new IllegalArgumentException(type));
		}
	}

	public Object saveState(FacesContext context) {
		Object values[] = new Object[15];
		values[0] = currencyCode;
		values[1] = currencySymbol;
		values[2] = isGroupingUsed() ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[3] = isIntegerOnly() ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[4] = new Integer(maxFractionDigits);
		values[5] = maxFractionDigitsSpecified ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[6] = new Integer(maxIntegerDigits);
		values[7] = maxIntegerDigitsSpecified ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[8] = new Integer(minFractionDigits);
		values[9] = minFractionDigitsSpecified ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[10] = new Integer(minIntegerDigits);
		values[11] = minIntegerDigitsSpecified ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[12] = locale;
		values[13] = pattern;
		values[14] = type;
		return ((Object) (values));
	}

	public void restoreState(FacesContext context, Object state) {
		Object values[] = (Object[])(Object[])state;
		currencyCode = (String)values[0];
		currencySymbol = (String)values[1];
		groupingUsed = ((Boolean)values[2]).booleanValue();
		integerOnly = ((Boolean)values[3]).booleanValue();
		maxFractionDigits = ((Integer)values[4]).intValue();
		maxFractionDigitsSpecified = ((Boolean)values[5]).booleanValue();
		maxIntegerDigits = ((Integer)values[6]).intValue();
		maxIntegerDigitsSpecified = ((Boolean)values[7]).booleanValue();
		minFractionDigits = ((Integer)values[8]).intValue();
		minFractionDigitsSpecified = ((Boolean)values[9]).booleanValue();
		minIntegerDigits = ((Integer)values[10]).intValue();
		minIntegerDigitsSpecified = ((Boolean)values[11]).booleanValue();
		locale = (Locale)values[12];
		pattern = (String)values[13];
		type = (String)values[14];
	}

	public boolean isTransient() {
		return transientFlag;
	}

	public void setTransient(boolean transientFlag) {
		this.transientFlag = transientFlag;
	}

	static  {
		try {
			currencyClass = Class.forName("java.util.Currency");
		}
		catch (Exception cnfe) { }
	}
}
