// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   DateTimeConverter.java

package javax.faces.convert;

import java.text.*;
import java.util.*;
import javax.faces.component.*;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.convert:
//			Converter, ConverterException, MessageFactory

public class DateTimeConverter
	implements Converter, StateHolder {

	public static final String CONVERTER_ID = "javax.faces.DateTime";
	public static final String DATE_ID = "javax.faces.converter.DateTimeConverter.DATE";
	public static final String TIME_ID = "javax.faces.converter.DateTimeConverter.TIME";
	public static final String DATETIME_ID = "javax.faces.converter.DateTimeConverter.DATETIME";
	public static final String STRING_ID = "javax.faces.converter.STRING";
	private static final TimeZone DEFAULT_TIME_ZONE = TimeZone.getTimeZone("GMT");
	private String dateStyle;
	private Locale locale;
	private String pattern;
	private String timeStyle;
	private TimeZone timeZone;
	private String type;
	private boolean transientFlag;

	public DateTimeConverter() {
		dateStyle = "default";
		locale = null;
		pattern = null;
		timeStyle = "default";
		timeZone = DEFAULT_TIME_ZONE;
		type = "date";
		transientFlag = false;
	}

	public String getDateStyle() {
		return dateStyle;
	}

	public void setDateStyle(String dateStyle) {
		this.dateStyle = dateStyle;
	}

	public Locale getLocale() {
		if (locale == null) {
			locale = getLocale(FacesContext.getCurrentInstance());
		}
		return locale;
	}

	public void setLocale(Locale locale) {
		this.locale = locale;
	}

	public String getPattern() {
		return pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	public String getTimeStyle() {
		return timeStyle;
	}

	public void setTimeStyle(String timeStyle) {
		this.timeStyle = timeStyle;
	}

	public TimeZone getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(TimeZone timeZone) {
		this.timeZone = timeZone;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		Object returnValue;
		DateFormat parser;
		if (context == null || component == null) {
			throw new NullPointerException();
		}
		returnValue = null;
		parser = null;
		if (value == null) {
			return null;
		}
		value = value.trim();
		if (value.length() < 1) {
			return null;
		}
		try {
			Locale locale = getLocale(context);
			parser = getDateFormat(context, locale);
			if (null != timeZone) {
				parser.setTimeZone(timeZone);
			}
			returnValue = parser.parse(value);
		}
		catch (ParseException e) {
			if (type.equals("date")) {
				throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.DateTimeConverter.DATE", new Object[] {
					value, parser.format(new Date(System.currentTimeMillis())), MessageFactory.getLabel(context, component)
				}));
			}
			if (type.equals("time")) {
				throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.DateTimeConverter.TIME", new Object[] {
					value, parser.format(new Date(System.currentTimeMillis())), MessageFactory.getLabel(context, component)
				}));
			}
			if (type.equals("both")) {
				throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.DateTimeConverter.DATETIME", new Object[] {
					value, parser.format(new Date(System.currentTimeMillis())), MessageFactory.getLabel(context, component)
				}));
			}
		}
		catch (ConverterException e) {
			throw e;
		}
		catch (Exception e) {
			throw new ConverterException(e);
		}
		return returnValue;
	}

	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (context == null || component == null) {
			throw new NullPointerException();
		}
		if (value == null) {
			return "";
		}
		if (value instanceof String) {
			return (String)value;
		}
		DateFormat formatter;
		Locale locale = getLocale(context);
		formatter = getDateFormat(context, locale);
		if (null != timeZone) {
			formatter.setTimeZone(timeZone);
		}
		return formatter.format(value);
		ConverterException e;
		e;
		throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.STRING", new Object[] {
			value, MessageFactory.getLabel(context, component)
		}), e);
		e;
		throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.STRING", new Object[] {
			value, MessageFactory.getLabel(context, component)
		}), e);
	}

	private DateFormat getDateFormat(FacesContext context, Locale locale) {
		if (pattern == null && type == null) {
			throw new IllegalArgumentException("Either pattern or type must be specified.");
		}
		DateFormat df = null;
		if (pattern != null) {
			df = new SimpleDateFormat(pattern, locale);
		} else
		if (type.equals("both")) {
			df = DateFormat.getDateTimeInstance(getStyle(dateStyle), getStyle(timeStyle), locale);
		} else
		if (type.equals("date")) {
			df = DateFormat.getDateInstance(getStyle(dateStyle), locale);
		} else
		if (type.equals("time")) {
			df = DateFormat.getTimeInstance(getStyle(timeStyle), locale);
		} else {
			throw new IllegalArgumentException((new StringBuilder()).append("Invalid type: ").append(type).toString());
		}
		df.setLenient(false);
		return df;
	}

	private Locale getLocale(FacesContext context) {
		Locale locale = this.locale;
		if (locale == null) {
			locale = context.getViewRoot().getLocale();
		}
		return locale;
	}

	private int getStyle(String name) {
		if (name.equals("default")) {
			return 2;
		}
		if (name.equals("short")) {
			return 3;
		}
		if (name.equals("medium")) {
			return 2;
		}
		if (name.equals("long")) {
			return 1;
		}
		if (name.equals("full")) {
			return 0;
		} else {
			throw new ConverterException((new StringBuilder()).append("Invalid style '").append(name).append("'").toString());
		}
	}

	public Object saveState(FacesContext context) {
		Object values[] = new Object[6];
		values[0] = dateStyle;
		values[1] = locale;
		values[2] = pattern;
		values[3] = timeStyle;
		values[4] = timeZone;
		values[5] = type;
		return ((Object) (values));
	}

	public void restoreState(FacesContext context, Object state) {
		Object values[] = (Object[])(Object[])state;
		dateStyle = (String)values[0];
		locale = (Locale)values[1];
		pattern = (String)values[2];
		timeStyle = (String)values[3];
		timeZone = (TimeZone)values[4];
		type = (String)values[5];
	}

	public boolean isTransient() {
		return transientFlag;
	}

	public void setTransient(boolean transientFlag) {
		this.transientFlag = transientFlag;
	}

}
