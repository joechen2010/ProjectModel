// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   RenderKitFactory.java

package javax.faces.render;

import java.util.Iterator;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.render:
//			RenderKit

public abstract class RenderKitFactory {

	public static final String HTML_BASIC_RENDER_KIT = "HTML_BASIC";

	public RenderKitFactory() {
	}

	public abstract void addRenderKit(String s, RenderKit renderkit);

	public abstract RenderKit getRenderKit(FacesContext facescontext, String s);

	public abstract Iterator getRenderKitIds();
}
