// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ResponseStateManager.java

package javax.faces.render;

import java.io.IOException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.Application;
import javax.faces.application.StateManager;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

public abstract class ResponseStateManager {

	private static Logger log = Logger.getLogger("javax.faces.render");
	public static final String RENDER_KIT_ID_PARAM = "javax.faces.RenderKitId";
	public static final String VIEW_STATE_PARAM = "javax.faces.ViewState";

	public ResponseStateManager() {
	}

	public void writeState(FacesContext context, Object state) throws IOException {
		javax.faces.application.StateManager.SerializedView view = null;
		if (state instanceof javax.faces.application.StateManager.SerializedView) {
			view = (javax.faces.application.StateManager.SerializedView)state;
		} else
		if (state instanceof Object[]) {
			Object stateArray[] = (Object[])(Object[])state;
			if (2 == stateArray.length) {
				StateManager stateManager = context.getApplication().getStateManager();
				view = new javax.faces.application.StateManager.SerializedView(stateManager, stateArray[0], stateArray[1]);
			} else {
				if (log.isLoggable(Level.SEVERE)) {
					log.log(Level.SEVERE, "State is not an expected array of length 2.");
				}
				throw new IOException("State is not an expected array of length 2.");
			}
		} else {
			if (log.isLoggable(Level.SEVERE)) {
				log.log(Level.SEVERE, "State is not an expected array of length 2.");
			}
			throw new IOException("State is not an expected array of length 2.");
		}
		writeState(context, view);
	}

	/**
	 * @deprecated Method writeState is deprecated
	 */

	public void writeState(FacesContext facescontext, javax.faces.application.StateManager.SerializedView serializedview) throws IOException {
	}

	public Object getState(FacesContext context, String viewId) {
		Object stateArray[] = {
			getTreeStructureToRestore(context, viewId), getComponentStateToRestore(context)
		};
		return ((Object) (stateArray));
	}

	/**
	 * @deprecated Method getTreeStructureToRestore is deprecated
	 */

	public Object getTreeStructureToRestore(FacesContext context, String viewId) {
		return null;
	}

	/**
	 * @deprecated Method getComponentStateToRestore is deprecated
	 */

	public Object getComponentStateToRestore(FacesContext context) {
		return null;
	}

	public boolean isPostback(FacesContext context) {
		return 0 < context.getExternalContext().getRequestParameterMap().size();
	}

}
