// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   RenderKit.java

package javax.faces.render;

import java.io.OutputStream;
import java.io.Writer;
import javax.faces.context.ResponseStream;
import javax.faces.context.ResponseWriter;

// Referenced classes of package javax.faces.render:
//			Renderer, ResponseStateManager

public abstract class RenderKit {

	public RenderKit() {
	}

	public abstract void addRenderer(String s, String s1, Renderer renderer);

	public abstract Renderer getRenderer(String s, String s1);

	public abstract ResponseStateManager getResponseStateManager();

	public abstract ResponseWriter createResponseWriter(Writer writer, String s, String s1);

	public abstract ResponseStream createResponseStream(OutputStream outputstream);
}
