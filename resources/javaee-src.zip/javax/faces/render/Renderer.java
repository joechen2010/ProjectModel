// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   Renderer.java

package javax.faces.render;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.ConverterException;

public abstract class Renderer {

	public Renderer() {
	}

	public void decode(FacesContext context, UIComponent component) {
		if (null == context || null == component) {
			throw new NullPointerException();
		} else {
			return;
		}
	}

	public void encodeBegin(FacesContext context, UIComponent component) throws IOException {
		if (null == context || null == component) {
			throw new NullPointerException();
		} else {
			return;
		}
	}

	public void encodeChildren(FacesContext context, UIComponent component) throws IOException {
		if (context == null || component == null) {
			throw new NullPointerException();
		}
		if (component.getChildCount() > 0) {
			UIComponent kid;
			for (Iterator kids = component.getChildren().iterator(); kids.hasNext(); kid.encodeAll(context)) {
				kid = (UIComponent)kids.next();
			}

		}
	}

	public void encodeEnd(FacesContext context, UIComponent component) throws IOException {
		if (null == context || null == component) {
			throw new NullPointerException();
		} else {
			return;
		}
	}

	public String convertClientId(FacesContext context, String clientId) {
		if (context == null || clientId == null) {
			throw new NullPointerException();
		} else {
			return clientId;
		}
	}

	public boolean getRendersChildren() {
		return false;
	}

	public Object getConvertedValue(FacesContext context, UIComponent component, Object submittedValue) throws ConverterException {
		if (context == null || component == null) {
			throw new NullPointerException();
		} else {
			return submittedValue;
		}
	}
}
