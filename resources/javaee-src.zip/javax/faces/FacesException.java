// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   FacesException.java

package javax.faces;


public class FacesException extends RuntimeException {

	private Throwable cause;

	public FacesException() {
		cause = null;
	}

	public FacesException(String message) {
		super(message);
		cause = null;
	}

	public FacesException(Throwable cause) {
		super(cause != null ? cause.toString() : (String)null);
		this.cause = null;
		this.cause = cause;
	}

	public FacesException(String message, Throwable cause) {
		super(message);
		this.cause = null;
		this.cause = cause;
	}

	public Throwable getCause() {
		return cause;
	}
}
