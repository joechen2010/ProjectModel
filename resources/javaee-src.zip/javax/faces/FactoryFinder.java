// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   FactoryFinder.java

package javax.faces;

import java.io.*;
import java.lang.reflect.Constructor;
import java.text.MessageFormat;
import java.util.*;
import java.util.logging.Logger;
import javax.faces.application.ApplicationFactory;
import javax.faces.context.FacesContextFactory;
import javax.faces.lifecycle.LifecycleFactory;
import javax.faces.render.RenderKitFactory;

// Referenced classes of package javax.faces:
//			FacesException

public final class FactoryFinder {

	public static final String APPLICATION_FACTORY = "javax.faces.application.ApplicationFactory";
	public static final String FACES_CONTEXT_FACTORY = "javax.faces.context.FacesContextFactory";
	public static final String LIFECYCLE_FACTORY = "javax.faces.lifecycle.LifecycleFactory";
	public static final String RENDER_KIT_FACTORY = "javax.faces.render.RenderKitFactory";
	private static HashMap applicationMaps = new HashMap();
	private static String factoryNames[] = {
		"javax.faces.application.ApplicationFactory", "javax.faces.context.FacesContextFactory", "javax.faces.lifecycle.LifecycleFactory", "javax.faces.render.RenderKitFactory"
	};
	private static Map factoryClasses = null;
	private static final Logger LOGGER = Logger.getLogger("javax.faces", "javax.faces.LogStrings");

	FactoryFinder() {
	}

	public static Object getFactory(String factoryName) throws FacesException {
		validateFactoryName(factoryName);
		ClassLoader classLoader = getClassLoader();
		HashMap hashmap = applicationMaps;
		JVM INSTR monitorenter ;
		Map appMap;
		Object factory;
		Object factoryOrList;
		appMap = getApplicationMap();
		factory = null;
		factoryOrList = appMap.get(factoryName);
		if (factoryOrList != null && !(factoryOrList instanceof List)) {
			return factoryOrList;
		}
		factory = getImplementationInstance(classLoader, factoryName, (List)factoryOrList);
		if (null == factory) {
			ResourceBundle rb = LOGGER.getResourceBundle();
			String message = rb.getString("severe.no_factory");
			message = MessageFormat.format(message, new Object[] {
				factoryName
			});
			throw new IllegalStateException(message);
		}
		appMap.put(factoryName, factory);
		factory;
		hashmap;
		JVM INSTR monitorexit ;
		return;
		Exception exception;
		exception;
		throw exception;
	}

	public static void setFactory(String factoryName, String implName) {
		Object previouslySetFactories;
		Map appMap;
label0:
		{
			validateFactoryName(factoryName);
			previouslySetFactories = null;
			appMap = null;
			synchronized (applicationMaps) {
				appMap = getApplicationMap();
				if (null == (previouslySetFactories = appMap.get(factoryName))) {
					break label0;
				}
				if (previouslySetFactories instanceof List) {
					break MISSING_BLOCK_LABEL_60;
				}
			}
			return;
		}
		previouslySetFactories = new ArrayList();
		appMap.put(factoryName, previouslySetFactories);
		((List)previouslySetFactories).add(0, implName);
		hashmap;
		JVM INSTR monitorexit ;
		  goto _L1
		exception;
		throw exception;
_L1:
	}

	public static void releaseFactories() throws FacesException {
		ClassLoader cl = getClassLoader();
		synchronized (applicationMaps) {
			HashMap map = (HashMap)applicationMaps.get(cl);
			if (map != null) {
				map.clear();
				applicationMaps.remove(cl);
			}
		}
	}

	private static ClassLoader getClassLoader() throws FacesException {
		ClassLoader cl = Thread.currentThread().getContextClassLoader();
		if (cl == null) {
			throw new FacesException("getContextClassLoader");
		} else {
			return cl;
		}
	}

	private static Object getImplementationInstance(ClassLoader classLoader, String factoryName, List implementations) throws FacesException {
		Object result = null;
		String curImplClass = null;
		int len = 0;
		int i = 0;
		if (null != implementations && (1 < (len = implementations.size()) || 1 == len)) {
			curImplClass = (String)implementations.remove(len - 1);
			result = getImplGivenPreviousImpl(classLoader, factoryName, curImplClass, null);
		}
		if (null != (curImplClass = getImplNameFromServices(classLoader, factoryName))) {
			result = getImplGivenPreviousImpl(classLoader, factoryName, curImplClass, result);
		}
		if (null != implementations) {
			for (len = implementations.size() - 1; 0 <= len; len--) {
				curImplClass = (String)implementations.remove(len);
				result = getImplGivenPreviousImpl(classLoader, factoryName, curImplClass, result);
			}

		}
		return result;
	}

	private static String getImplNameFromServices(ClassLoader classLoader, String factoryName) {
		String result;
label0:
		{
			result = null;
			BufferedReader reader = null;
			String resourceName = (new StringBuilder()).append("META-INF/services/").append(factoryName).toString();
			java.util.Properties props = null;
			InputStream stream = null;
			try {
				stream = classLoader.getResourceAsStream(resourceName);
				if (stream != null) {
					try {
						reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
					}
					catch (UnsupportedEncodingException e) {
						reader = new BufferedReader(new InputStreamReader(stream));
					}
					result = reader.readLine();
					reader.close();
					reader = null;
					stream = null;
				}
			}
			catch (IOException e) {
				if (reader != null) {
					try {
						reader.close();
					}
					catch (Throwable t) { }
					reader = null;
					stream = null;
				}
				if (stream != null) {
					try {
						stream.close();
					}
					catch (Throwable t) { }
					stream = null;
				}
				break label0;
			}
			catch (SecurityException e) {
				if (reader != null) {
					try {
						reader.close();
					}
					catch (Throwable t) { }
					reader = null;
					stream = null;
				}
				if (stream != null) {
					try {
						stream.close();
					}
					catch (Throwable t) { }
					stream = null;
				}
				break label0;
			}
			finally {
				if (reader != null) {
					try {
						reader.close();
					}
					catch (Throwable t) { }
					reader = null;
					stream = null;
				}
				if (stream != null) {
					try {
						stream.close();
					}
					catch (Throwable t) { }
					stream = null;
				}
				throw exception;
			}
			if (reader != null) {
				try {
					reader.close();
				}
				catch (Throwable t) { }
				reader = null;
				stream = null;
			}
			if (stream != null) {
				try {
					stream.close();
				}
				catch (Throwable t) { }
				stream = null;
			}
			break label0;
		}
		return result;
	}

	private static Object getImplGivenPreviousImpl(ClassLoader classLoader, String factoryName, String implName, Object previousImpl) {
		Class clazz = null;
		Class factoryClass = null;
		Class getCtorArg[] = null;
		Object newInstanceArgs[] = new Object[1];
		Constructor ctor = null;
		Object result = null;
		if (null != previousImpl && null != (factoryClass = getFactoryClass(classLoader, factoryName))) {
			try {
				clazz = Class.forName(implName, false, classLoader);
				getCtorArg = new Class[1];
				getCtorArg[0] = factoryClass;
				ctor = clazz.getConstructor(getCtorArg);
				newInstanceArgs[0] = previousImpl;
				result = ctor.newInstance(newInstanceArgs);
			}
			catch (NoSuchMethodException nsme) {
				factoryClass = null;
			}
			catch (Exception e) {
				throw new FacesException(implName, e);
			}
		}
		if (null == previousImpl || null == factoryClass) {
			try {
				clazz = Class.forName(implName, false, classLoader);
				result = clazz.newInstance();
			}
			catch (Exception e) {
				throw new FacesException(implName, e);
			}
		}
		return result;
	}

	private static Class getFactoryClass(ClassLoader classLoader, String factoryClassName) {
		if (null == factoryClasses) {
			factoryClasses = new HashMap(factoryNames.length);
			factoryClasses.put("javax.faces.application.ApplicationFactory", javax/faces/application/ApplicationFactory);
			factoryClasses.put("javax.faces.context.FacesContextFactory", javax/faces/context/FacesContextFactory);
			factoryClasses.put("javax.faces.lifecycle.LifecycleFactory", javax/faces/lifecycle/LifecycleFactory);
			factoryClasses.put("javax.faces.render.RenderKitFactory", javax/faces/render/RenderKitFactory);
		}
		return (Class)factoryClasses.get(factoryClassName);
	}

	private static Map getApplicationMap() {
		ClassLoader classLoader = getClassLoader();
		Map result = null;
		result = (HashMap)applicationMaps.get(classLoader);
		if (result == null) {
			result = new HashMap();
			applicationMaps.put(classLoader, result);
		}
		return result;
	}

	private static void validateFactoryName(String factoryName) {
		if (factoryName == null) {
			throw new NullPointerException();
		}
		boolean found = false;
		int i = 0;
		do {
			if (i >= factoryNames.length) {
				break;
			}
			if (factoryName.equals(factoryNames[i])) {
				found = true;
				break;
			}
			i++;
		} while (true);
		if (!found) {
			throw new IllegalArgumentException(factoryName);
		} else {
			return;
		}
	}

}
