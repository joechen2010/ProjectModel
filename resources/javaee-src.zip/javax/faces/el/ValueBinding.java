// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ValueBinding.java

package javax.faces.el;

import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.el:
//			EvaluationException, PropertyNotFoundException

/**
 * @deprecated Class ValueBinding is deprecated
 */

public abstract class ValueBinding {

	public ValueBinding() {
	}

	public abstract Object getValue(FacesContext facescontext) throws EvaluationException, PropertyNotFoundException;

	public abstract void setValue(FacesContext facescontext, Object obj) throws EvaluationException, PropertyNotFoundException;

	public abstract boolean isReadOnly(FacesContext facescontext) throws EvaluationException, PropertyNotFoundException;

	public abstract Class getType(FacesContext facescontext) throws EvaluationException, PropertyNotFoundException;

	public String getExpressionString() {
		return null;
	}
}
