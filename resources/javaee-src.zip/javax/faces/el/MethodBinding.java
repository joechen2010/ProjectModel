// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   MethodBinding.java

package javax.faces.el;

import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.el:
//			EvaluationException, MethodNotFoundException

/**
 * @deprecated Class MethodBinding is deprecated
 */

public abstract class MethodBinding {

	public MethodBinding() {
	}

	public abstract Object invoke(FacesContext facescontext, Object aobj[]) throws EvaluationException, MethodNotFoundException;

	public abstract Class getType(FacesContext facescontext) throws MethodNotFoundException;

	public String getExpressionString() {
		return null;
	}
}
