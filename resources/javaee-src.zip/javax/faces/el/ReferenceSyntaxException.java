// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ReferenceSyntaxException.java

package javax.faces.el;


// Referenced classes of package javax.faces.el:
//			EvaluationException

/**
 * @deprecated Class ReferenceSyntaxException is deprecated
 */

public class ReferenceSyntaxException extends EvaluationException {

	public ReferenceSyntaxException() {
	}

	public ReferenceSyntaxException(String message) {
		super(message);
	}

	public ReferenceSyntaxException(Throwable cause) {
		super(cause);
	}

	public ReferenceSyntaxException(String message, Throwable cause) {
		super(message, cause);
	}
}
