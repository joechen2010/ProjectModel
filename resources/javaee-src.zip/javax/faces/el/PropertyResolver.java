// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   PropertyResolver.java

package javax.faces.el;


// Referenced classes of package javax.faces.el:
//			EvaluationException, PropertyNotFoundException

/**
 * @deprecated Class PropertyResolver is deprecated
 */

public abstract class PropertyResolver {

	public PropertyResolver() {
	}

	public abstract Object getValue(Object obj, Object obj1) throws EvaluationException, PropertyNotFoundException;

	public abstract Object getValue(Object obj, int i) throws EvaluationException, PropertyNotFoundException;

	public abstract void setValue(Object obj, Object obj1, Object obj2) throws EvaluationException, PropertyNotFoundException;

	public abstract void setValue(Object obj, int i, Object obj1) throws EvaluationException, PropertyNotFoundException;

	public abstract boolean isReadOnly(Object obj, Object obj1) throws EvaluationException, PropertyNotFoundException;

	public abstract boolean isReadOnly(Object obj, int i) throws EvaluationException, PropertyNotFoundException;

	public abstract Class getType(Object obj, Object obj1) throws EvaluationException, PropertyNotFoundException;

	public abstract Class getType(Object obj, int i) throws EvaluationException, PropertyNotFoundException;
}
