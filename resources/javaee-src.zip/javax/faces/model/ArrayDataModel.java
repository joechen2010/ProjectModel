// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ArrayDataModel.java

package javax.faces.model;


// Referenced classes of package javax.faces.model:
//			DataModel, DataModelEvent, DataModelListener

public class ArrayDataModel extends DataModel {

	private Object array[];
	private int index;

	public ArrayDataModel() {
		this(null);
	}

	public ArrayDataModel(Object array[]) {
		index = -1;
		setWrappedData(((Object) (array)));
	}

	public boolean isRowAvailable() {
		if (array == null) {
			return false;
		}
		return index >= 0 && index < array.length;
	}

	public int getRowCount() {
		if (array == null) {
			return -1;
		} else {
			return array.length;
		}
	}

	public Object getRowData() {
		if (array == null) {
			return null;
		}
		if (!isRowAvailable()) {
			throw new IllegalArgumentException();
		} else {
			return array[index];
		}
	}

	public int getRowIndex() {
		return index;
	}

	public void setRowIndex(int rowIndex) {
		if (rowIndex < -1) {
			throw new IllegalArgumentException();
		}
		int old = index;
		index = rowIndex;
		if (array == null) {
			return;
		}
		DataModelListener listeners[] = getDataModelListeners();
		if (old != index && listeners != null) {
			Object rowData = null;
			if (isRowAvailable()) {
				rowData = getRowData();
			}
			DataModelEvent event = new DataModelEvent(this, index, rowData);
			int n = listeners.length;
			for (int i = 0; i < n; i++) {
				if (null != listeners[i]) {
					listeners[i].rowSelected(event);
				}
			}

		}
	}

	public Object getWrappedData() {
		return ((Object) (array));
	}

	public void setWrappedData(Object data) {
		if (data == null) {
			array = null;
			setRowIndex(-1);
		} else {
			array = (Object[])(Object[])data;
			index = -1;
			setRowIndex(0);
		}
	}
}
