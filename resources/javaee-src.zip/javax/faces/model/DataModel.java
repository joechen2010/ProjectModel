// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   DataModel.java

package javax.faces.model;

import java.util.ArrayList;
import java.util.List;

// Referenced classes of package javax.faces.model:
//			DataModelListener

public abstract class DataModel {

	private List listeners;

	public DataModel() {
		listeners = null;
	}

	public abstract boolean isRowAvailable();

	public abstract int getRowCount();

	public abstract Object getRowData();

	public abstract int getRowIndex();

	public abstract void setRowIndex(int i);

	public abstract Object getWrappedData();

	public abstract void setWrappedData(Object obj);

	public void addDataModelListener(DataModelListener listener) {
		if (listener == null) {
			throw new NullPointerException();
		}
		if (listeners == null) {
			listeners = new ArrayList();
		}
		listeners.add(listener);
	}

	public DataModelListener[] getDataModelListeners() {
		if (listeners == null) {
			return new DataModelListener[0];
		} else {
			return (DataModelListener[])(DataModelListener[])listeners.toArray(new DataModelListener[listeners.size()]);
		}
	}

	public void removeDataModelListener(DataModelListener listener) {
		if (listener == null) {
			throw new NullPointerException();
		}
		if (listeners != null) {
			listeners.remove(listener);
			if (listeners.size() == 0) {
				listeners = null;
			}
		}
	}
}
