// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ResultSetDataModel.java

package javax.faces.model;

import java.util.Iterator;

// Referenced classes of package javax.faces.model:
//			ResultSetDataModel

private static class ResultSetDataModel$ResultSetKeysIterator
	implements Iterator {

	private Iterator keys;

	public boolean hasNext() {
		return keys.hasNext();
	}

	public Object next() {
		return keys.next();
	}

	public void remove() {
		throw new UnsupportedOperationException();
	}

	public ResultSetDataModel$ResultSetKeysIterator(ResultSetDataModel$ResultSetMap map) {
		keys = null;
		keys = map.realKeys();
	}
}
