// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   SelectItem.java

package javax.faces.model;

import java.io.Serializable;

public class SelectItem
	implements Serializable {

	private static final long serialVersionUID = 0xc2af4dde9376817L;
	private String description;
	private boolean disabled;
	private String label;
	private Object value;
	private boolean escape;

	public SelectItem() {
		description = null;
		disabled = false;
		label = null;
		value = null;
	}

	public SelectItem(Object value) {
		this(value, value.toString(), null, false, true);
	}

	public SelectItem(Object value, String label) {
		this(value, label, null, false, true);
	}

	public SelectItem(Object value, String label, String description) {
		this(value, label, description, false, true);
	}

	public SelectItem(Object value, String label, String description, boolean disabled) {
		this(value, label, description, disabled, true);
	}

	public SelectItem(Object value, String label, String description, boolean disabled, boolean escape) {
		this.description = null;
		this.disabled = false;
		this.label = null;
		this.value = null;
		setValue(value);
		setLabel(label);
		setDescription(description);
		setDisabled(disabled);
		setEscape(escape);
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isDisabled() {
		return disabled;
	}

	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	public boolean isEscape() {
		return escape;
	}

	public void setEscape(boolean escape) {
		this.escape = escape;
	}
}
