// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ResultSetDataModel.java

package javax.faces.model;

import java.util.*;

// Referenced classes of package javax.faces.model:
//			ResultSetDataModel

private static class ResultSetDataModel$ResultSetEntries extends AbstractSet {

	private  map;

	public boolean add(Object o) {
		throw new UnsupportedOperationException();
	}

	public boolean addAll(Collection c) {
		throw new UnsupportedOperationException();
	}

	public void clear() {
		throw new UnsupportedOperationException();
	}

	public boolean contains(Object o) {
		if (o == null) {
			throw new NullPointerException();
		}
		if (!(o instanceof java.util.Map$Entry)) {
			return false;
		}
		java.util.Entries e = (java.util.Map$Entry)o;
		Object k = e.Entries();
		Object v = e.getValue();
		if (!map.ainsKey(k)) {
			return false;
		}
		if (v == null) {
			return map.get(k) == null;
		} else {
			return v.equals(map.get(k));
		}
	}

	public boolean isEmpty() {
		return map.pty();
	}

	public Iterator iterator() {
		return new terator(map);
	}

	public boolean remove(Object o) {
		throw new UnsupportedOperationException();
	}

	public boolean removeAll(Collection c) {
		throw new UnsupportedOperationException();
	}

	public boolean retainAll(Collection c) {
		throw new UnsupportedOperationException();
	}

	public int size() {
		return map.();
	}

	public ResultSetDataModel$ResultSetEntries(ResultSetDataModel$ResultSetMap map) {
		this.map = map;
	}
}
