// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ResultSetDataModel.java

package javax.faces.model;

import java.util.Iterator;
import java.util.Set;

// Referenced classes of package javax.faces.model:
//			ResultSetDataModel

private static class ResultSetDataModel$ResultSetEntriesIterator
	implements Iterator {

	private ResultSetDataModel$ResultSetMap map;
	private Iterator keys;

	public boolean hasNext() {
		return keys.hasNext();
	}

	public Object next() {
		Object key = keys.next();
		return new keys(map, key);
	}

	public void remove() {
		throw new UnsupportedOperationException();
	}

	public ResultSetDataModel$ResultSetEntriesIterator(ResultSetDataModel$ResultSetMap map) {
		this.map = null;
		keys = null;
		this.map = map;
		keys = map.keySet().iterator();
	}
}
