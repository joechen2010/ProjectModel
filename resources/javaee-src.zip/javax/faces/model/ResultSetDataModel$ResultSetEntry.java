// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ResultSetDataModel.java

package javax.faces.model;

import java.util.Map;

// Referenced classes of package javax.faces.model:
//			ResultSetDataModel

private static class ResultSetDataModel$ResultSetEntry
	implements java.util.Map$Entry {

	private ResultSetDataModel$ResultSetMap map;
	private Object key;

	public boolean equals(Object o) {
		if (o == null) {
			return false;
		}
		if (!(o instanceof java.util.Map$Entry)) {
			return false;
		}
		java.util.Map$Entry e = (java.util.Map$Entry)o;
		if (key == null) {
			if (e.getKey() != null) {
				return false;
			}
		} else
		if (!key.equals(e.getKey())) {
			return false;
		}
		Object v = map.t(key);
		if (v == null) {
			if (e.getValue() != null) {
				return false;
			}
		} else
		if (!v.equals(e.getValue())) {
			return false;
		}
		return true;
	}

	public Object getKey() {
		return key;
	}

	public Object getValue() {
		return map.t(key);
	}

	public int hashCode() {
		Object value = map.t(key);
		return (key != null ? key.hashCode() : 0) ^ (value != null ? value.hashCode() : 0);
	}

	public Object setValue(Object value) {
		Object previous = map.t(key);
		map.t(key, value);
		return previous;
	}

	public ResultSetDataModel$ResultSetEntry(ResultSetDataModel$ResultSetMap map, Object key) {
		this.map = map;
		this.key = key;
	}
}
