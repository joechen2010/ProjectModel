// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ResultSetDataModel.java

package javax.faces.model;

import java.sql.*;
import java.util.*;
import javax.faces.FacesException;

// Referenced classes of package javax.faces.model:
//			ResultSetDataModel

private class ResultSetDataModel$ResultSetMap extends TreeMap {

	private int index;
	final ResultSetDataModel this$0;

	public void clear() {
		throw new UnsupportedOperationException();
	}

	public boolean containsValue(Object value) {
label0:
		{
			Iterator i = entrySet().iterator();
			Object contained;
label1:
			do {
				do {
					if (!i.hasNext()) {
						break label0;
					}
					java.util.Map$Entry entry = (java.util.Map$Entry)i.next();
					contained = entry.entrySet();
					if (value != null) {
						continue label1;
					}
				} while (contained != null);
				return true;
			} while (!value.equals(contained));
			return true;
		}
		return false;
	}

	public Set entrySet() {
		return new ies(this);
	}

	public Object get(Object key) {
		if (!containsKey(key)) {
			return null;
		}
		ResultSetDataModel.access$100(ResultSetDataModel.this).absolute(index + 1);
		return ResultSetDataModel.access$100(ResultSetDataModel.this).getObject((String)realKey(key));
		SQLException e;
		e;
		throw new FacesException(e);
	}

	public Set keySet() {
		return new (this);
	}

	public Object put(Object key, Object value) {
		if (!containsKey(key)) {
			throw new IllegalArgumentException();
		}
		if (!(key instanceof String)) {
			throw new IllegalArgumentException();
		}
		Object previous;
		ResultSetDataModel.access$100(ResultSetDataModel.this).absolute(index + 1);
		previous = ResultSetDataModel.access$100(ResultSetDataModel.this).getObject((String)realKey(key));
		if (previous == null && value == null) {
			return previous;
		}
		if (previous != null && value != null && previous.equals(value)) {
			return previous;
		}
		ResultSetDataModel.access$100(ResultSetDataModel.this).updateObject((String)realKey(key), value);
		ResultSetDataModel.access$300(ResultSetDataModel.this);
		return previous;
		SQLException e;
		e;
		throw new FacesException(e);
	}

	public void putAll(Map map) {
		java.util.Map$Entry entry;
		for (Iterator i = map.entrySet().iterator(); i.hasNext(); put(entry.put(), entry.put())) {
			entry = (java.util.tSetMap.put)i.next();
		}

	}

	public Object remove(Object key) {
		throw new UnsupportedOperationException();
	}

	public Collection values() {
		return new es(this);
	}

	Object realKey(Object key) {
		return super.get(key);
	}

	Iterator realKeys() {
		return super.keySet().iterator();
	}

	public ResultSetDataModel$ResultSetMap(Comparator comparator) throws SQLException {
		this$0 = ResultSetDataModel.this;
		super(comparator);
		index = ResultSetDataModel.access$000(ResultSetDataModel.this);
		ResultSetDataModel.access$100(ResultSetDataModel.this).absolute(index + 1);
		int n = ResultSetDataModel.access$200(ResultSetDataModel.this).getColumnCount();
		for (int i = 1; i <= n; i++) {
			super.put(ResultSetDataModel.access$200(ResultSetDataModel.this).getColumnName(i), ResultSetDataModel.access$200(ResultSetDataModel.this).getColumnName(i));
		}

	}
}
