// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ResultSetDataModel.java

package javax.faces.model;

import java.sql.*;
import java.util.*;
import javax.faces.FacesException;

// Referenced classes of package javax.faces.model:
//			DataModel, DataModelEvent, DataModelListener

public class ResultSetDataModel extends DataModel {
	private static class ResultSetEntries extends AbstractSet {

		private ResultSetMap map;

		public boolean add(Object o) {
			throw new UnsupportedOperationException();
		}

		public boolean addAll(Collection c) {
			throw new UnsupportedOperationException();
		}

		public void clear() {
			throw new UnsupportedOperationException();
		}

		public boolean contains(Object o) {
			if (o == null) {
				throw new NullPointerException();
			}
			if (!(o instanceof java.util.Map.Entry)) {
				return false;
			}
			java.util.Map.Entry e = (java.util.Map.Entry)o;
			Object k = e.getKey();
			Object v = e.getValue();
			if (!map.containsKey(k)) {
				return false;
			}
			if (v == null) {
				return map.get(k) == null;
			} else {
				return v.equals(map.get(k));
			}
		}

		public boolean isEmpty() {
			return map.isEmpty();
		}

		public Iterator iterator() {
			return new ResultSetEntriesIterator(map);
		}

		public boolean remove(Object o) {
			throw new UnsupportedOperationException();
		}

		public boolean removeAll(Collection c) {
			throw new UnsupportedOperationException();
		}

		public boolean retainAll(Collection c) {
			throw new UnsupportedOperationException();
		}

		public int size() {
			return map.size();
		}

		public ResultSetEntries(ResultSetMap map) {
			this.map = map;
		}
	}

	private static class ResultSetEntriesIterator
		implements Iterator {

		private ResultSetMap map;
		private Iterator keys;

		public boolean hasNext() {
			return keys.hasNext();
		}

		public Object next() {
			Object key = keys.next();
			return new ResultSetEntry(map, key);
		}

		public void remove() {
			throw new UnsupportedOperationException();
		}

		public ResultSetEntriesIterator(ResultSetMap map) {
			this.map = null;
			keys = null;
			this.map = map;
			keys = map.keySet().iterator();
		}
	}

	private static class ResultSetEntry
		implements java.util.Map.Entry {

		private ResultSetMap map;
		private Object key;

		public boolean equals(Object o) {
			if (o == null) {
				return false;
			}
			if (!(o instanceof java.util.Map.Entry)) {
				return false;
			}
			java.util.Map.Entry e = (java.util.Map.Entry)o;
			if (key == null) {
				if (e.getKey() != null) {
					return false;
				}
			} else
			if (!key.equals(e.getKey())) {
				return false;
			}
			Object v = map.get(key);
			if (v == null) {
				if (e.getValue() != null) {
					return false;
				}
			} else
			if (!v.equals(e.getValue())) {
				return false;
			}
			return true;
		}

		public Object getKey() {
			return key;
		}

		public Object getValue() {
			return map.get(key);
		}

		public int hashCode() {
			Object value = map.get(key);
			return (key != null ? key.hashCode() : 0) ^ (value != null ? value.hashCode() : 0);
		}

		public Object setValue(Object value) {
			Object previous = map.get(key);
			map.put(key, value);
			return previous;
		}

		public ResultSetEntry(ResultSetMap map, Object key) {
			this.map = map;
			this.key = key;
		}
	}

	private static class ResultSetKeys extends AbstractSet {

		private ResultSetMap map;

		public boolean add(Object o) {
			throw new UnsupportedOperationException();
		}

		public boolean addAll(Collection c) {
			throw new UnsupportedOperationException();
		}

		public void clear() {
			throw new UnsupportedOperationException();
		}

		public boolean contains(Object o) {
			return map.containsKey(o);
		}

		public boolean isEmpty() {
			return map.isEmpty();
		}

		public Iterator iterator() {
			return new ResultSetKeysIterator(map);
		}

		public boolean remove(Object o) {
			throw new UnsupportedOperationException();
		}

		public boolean removeAll(Collection c) {
			throw new UnsupportedOperationException();
		}

		public boolean retainAll(Collection c) {
			throw new UnsupportedOperationException();
		}

		public int size() {
			return map.size();
		}

		public ResultSetKeys(ResultSetMap map) {
			this.map = map;
		}
	}

	private static class ResultSetKeysIterator
		implements Iterator {

		private Iterator keys;

		public boolean hasNext() {
			return keys.hasNext();
		}

		public Object next() {
			return keys.next();
		}

		public void remove() {
			throw new UnsupportedOperationException();
		}

		public ResultSetKeysIterator(ResultSetMap map) {
			keys = null;
			keys = map.realKeys();
		}
	}

	private class ResultSetMap extends TreeMap {

		private int index;
		final ResultSetDataModel this$0;

		public void clear() {
			throw new UnsupportedOperationException();
		}

		public boolean containsValue(Object value) {
label0:
			{
				Iterator i = entrySet().iterator();
				Object contained;
label1:
				do {
					do {
						if (!i.hasNext()) {
							break label0;
						}
						java.util.Map.Entry entry = (java.util.Map.Entry)i.next();
						contained = entry.getValue();
						if (value != null) {
							continue label1;
						}
					} while (contained != null);
					return true;
				} while (!value.equals(contained));
				return true;
			}
			return false;
		}

		public Set entrySet() {
			return new ResultSetEntries(this);
		}

		public Object get(Object key) {
			if (!containsKey(key)) {
				return null;
			}
			resultSet.absolute(index + 1);
			return resultSet.getObject((String)realKey(key));
			SQLException e;
			e;
			throw new FacesException(e);
		}

		public Set keySet() {
			return new ResultSetKeys(this);
		}

		public Object put(Object key, Object value) {
			if (!containsKey(key)) {
				throw new IllegalArgumentException();
			}
			if (!(key instanceof String)) {
				throw new IllegalArgumentException();
			}
			Object previous;
			resultSet.absolute(index + 1);
			previous = resultSet.getObject((String)realKey(key));
			if (previous == null && value == null) {
				return previous;
			}
			if (previous != null && value != null && previous.equals(value)) {
				return previous;
			}
			resultSet.updateObject((String)realKey(key), value);
			updated();
			return previous;
			SQLException e;
			e;
			throw new FacesException(e);
		}

		public void putAll(Map map) {
			java.util.Map.Entry entry;
			for (Iterator i = map.entrySet().iterator(); i.hasNext(); put(entry.getKey(), entry.getValue())) {
				entry = (java.util.Map.Entry)i.next();
			}

		}

		public Object remove(Object key) {
			throw new UnsupportedOperationException();
		}

		public Collection values() {
			return new ResultSetValues(this);
		}

		Object realKey(Object key) {
			return super.get(key);
		}

		Iterator realKeys() {
			return super.keySet().iterator();
		}

		public ResultSetMap(Comparator comparator) throws SQLException {
			this$0 = ResultSetDataModel.this;
			super(comparator);
			index = ResultSetDataModel.this.index;
			resultSet.absolute(index + 1);
			int n = metadata.getColumnCount();
			for (int i = 1; i <= n; i++) {
				super.put(metadata.getColumnName(i), metadata.getColumnName(i));
			}

		}
	}

	private static class ResultSetValues extends AbstractCollection {

		private ResultSetMap map;

		public boolean add(Object o) {
			throw new UnsupportedOperationException();
		}

		public boolean addAll(Collection c) {
			throw new UnsupportedOperationException();
		}

		public void clear() {
			throw new UnsupportedOperationException();
		}

		public boolean contains(Object value) {
			return map.containsValue(value);
		}

		public Iterator iterator() {
			return new ResultSetValuesIterator(map);
		}

		public boolean remove(Object o) {
			throw new UnsupportedOperationException();
		}

		public boolean removeAll(Collection c) {
			throw new UnsupportedOperationException();
		}

		public boolean retainAll(Collection c) {
			throw new UnsupportedOperationException();
		}

		public int size() {
			return map.size();
		}

		public ResultSetValues(ResultSetMap map) {
			this.map = map;
		}
	}

	private static class ResultSetValuesIterator
		implements Iterator {

		private ResultSetMap map;
		private Iterator keys;

		public boolean hasNext() {
			return keys.hasNext();
		}

		public Object next() {
			return map.get(keys.next());
		}

		public void remove() {
			throw new UnsupportedOperationException();
		}

		public ResultSetValuesIterator(ResultSetMap map) {
			this.map = map;
			keys = map.keySet().iterator();
		}
	}


	private int index;
	private ResultSetMetaData metadata;
	private ResultSet resultSet;
	private boolean updated;

	public ResultSetDataModel() {
		this(null);
	}

	public ResultSetDataModel(ResultSet resultSet) {
		index = -1;
		metadata = null;
		this.resultSet = null;
		updated = false;
		setWrappedData(resultSet);
	}

	public boolean isRowAvailable() {
		if (resultSet == null) {
			return false;
		}
		if (index < 0) {
			return false;
		}
		if (resultSet.absolute(index + 1)) {
			return true;
		}
		return false;
		SQLException e;
		e;
		throw new FacesException(e);
	}

	public int getRowCount() {
		return -1;
	}

	public Object getRowData() {
		if (resultSet == null) {
			return null;
		}
		if (!isRowAvailable()) {
			throw new IllegalArgumentException();
		}
		getMetaData();
		return new ResultSetMap(String.CASE_INSENSITIVE_ORDER);
		SQLException e;
		e;
		throw new FacesException(e);
	}

	public int getRowIndex() {
		return index;
	}

	public void setRowIndex(int rowIndex) {
		if (rowIndex < -1) {
			throw new IllegalArgumentException();
		}
		if (updated && resultSet != null) {
			try {
				if (!resultSet.rowDeleted()) {
					resultSet.updateRow();
				}
				updated = false;
			}
			catch (SQLException e) {
				throw new FacesException(e);
			}
		}
		int old = index;
		index = rowIndex;
		if (resultSet == null) {
			return;
		}
		DataModelListener listeners[] = getDataModelListeners();
		if (old != index && listeners != null) {
			Object rowData = null;
			if (isRowAvailable()) {
				rowData = getRowData();
			}
			DataModelEvent event = new DataModelEvent(this, index, rowData);
			int n = listeners.length;
			for (int i = 0; i < n; i++) {
				if (null != listeners[i]) {
					listeners[i].rowSelected(event);
				}
			}

		}
	}

	public Object getWrappedData() {
		return resultSet;
	}

	public void setWrappedData(Object data) {
		if (data == null) {
			metadata = null;
			resultSet = null;
			setRowIndex(-1);
		} else {
			metadata = null;
			resultSet = (ResultSet)data;
			index = -1;
			setRowIndex(0);
		}
	}

	private ResultSetMetaData getMetaData() {
		if (metadata == null) {
			try {
				metadata = resultSet.getMetaData();
			}
			catch (SQLException e) {
				throw new FacesException(e);
			}
		}
		return metadata;
	}

	private void updated() {
		updated = true;
	}




}
