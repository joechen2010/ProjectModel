// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   DataModelEvent.java

package javax.faces.model;

import java.util.EventObject;

// Referenced classes of package javax.faces.model:
//			DataModel

public class DataModelEvent extends EventObject {

	private Object data;
	private int index;

	public DataModelEvent(DataModel model, int index, Object data) {
		super(model);
		this.data = null;
		this.index = 0;
		this.index = index;
		this.data = data;
	}

	public DataModel getDataModel() {
		return (DataModel)getSource();
	}

	public Object getRowData() {
		return data;
	}

	public int getRowIndex() {
		return index;
	}
}
