// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   SelectItemGroup.java

package javax.faces.model;


// Referenced classes of package javax.faces.model:
//			SelectItem

public class SelectItemGroup extends SelectItem {

	private SelectItem selectItems[];

	public SelectItemGroup() {
		selectItems = null;
	}

	public SelectItemGroup(String label) {
		super("", label);
		selectItems = null;
	}

	public SelectItemGroup(String label, String description, boolean disabled, SelectItem selectItems[]) {
		super("", label, description, disabled);
		this.selectItems = null;
		setSelectItems(selectItems);
	}

	public SelectItem[] getSelectItems() {
		return selectItems;
	}

	public void setSelectItems(SelectItem selectItems[]) {
		if (selectItems == null) {
			throw new NullPointerException();
		} else {
			this.selectItems = selectItems;
			return;
		}
	}
}
