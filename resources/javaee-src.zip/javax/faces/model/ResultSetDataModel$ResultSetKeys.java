// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ResultSetDataModel.java

package javax.faces.model;

import java.util.*;

// Referenced classes of package javax.faces.model:
//			ResultSetDataModel

private static class ResultSetDataModel$ResultSetKeys extends AbstractSet {

	private ResultSetDataModel$ResultSetMap map;

	public boolean add(Object o) {
		throw new UnsupportedOperationException();
	}

	public boolean addAll(Collection c) {
		throw new UnsupportedOperationException();
	}

	public void clear() {
		throw new UnsupportedOperationException();
	}

	public boolean contains(Object o) {
		return map.ontainsKey(o);
	}

	public boolean isEmpty() {
		return map.sEmpty();
	}

	public Iterator iterator() {
		return new terator(map);
	}

	public boolean remove(Object o) {
		throw new UnsupportedOperationException();
	}

	public boolean removeAll(Collection c) {
		throw new UnsupportedOperationException();
	}

	public boolean retainAll(Collection c) {
		throw new UnsupportedOperationException();
	}

	public int size() {
		return map.ize();
	}

	public ResultSetDataModel$ResultSetKeys(ResultSetDataModel$ResultSetMap map) {
		this.map = map;
	}
}
