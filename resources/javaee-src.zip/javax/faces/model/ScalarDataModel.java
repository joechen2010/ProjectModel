// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ScalarDataModel.java

package javax.faces.model;


// Referenced classes of package javax.faces.model:
//			DataModel, DataModelEvent, DataModelListener

public class ScalarDataModel extends DataModel {

	private int index;
	private Object scalar;

	public ScalarDataModel() {
		this(null);
	}

	public ScalarDataModel(Object scalar) {
		setWrappedData(scalar);
	}

	public boolean isRowAvailable() {
		if (scalar == null) {
			return false;
		}
		return index == 0;
	}

	public int getRowCount() {
		return scalar != null ? 1 : -1;
	}

	public Object getRowData() {
		if (scalar == null) {
			return null;
		}
		if (!isRowAvailable()) {
			throw new IllegalArgumentException();
		} else {
			return scalar;
		}
	}

	public int getRowIndex() {
		return index;
	}

	public void setRowIndex(int rowIndex) {
		if (rowIndex < -1) {
			throw new IllegalArgumentException();
		}
		int old = index;
		index = rowIndex;
		if (scalar == null) {
			return;
		}
		DataModelListener listeners[] = getDataModelListeners();
		if (old != index && listeners != null) {
			Object rowData = null;
			if (isRowAvailable()) {
				rowData = getRowData();
			}
			DataModelEvent event = new DataModelEvent(this, index, rowData);
			int n = listeners.length;
			for (int i = 0; i < n; i++) {
				if (null != listeners[i]) {
					listeners[i].rowSelected(event);
				}
			}

		}
	}

	public Object getWrappedData() {
		return scalar;
	}

	public void setWrappedData(Object data) {
		if (data == null) {
			scalar = null;
			setRowIndex(-1);
		} else {
			scalar = data;
			index = -1;
			setRowIndex(0);
		}
	}
}
