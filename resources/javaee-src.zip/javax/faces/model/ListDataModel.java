// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ListDataModel.java

package javax.faces.model;

import java.util.List;

// Referenced classes of package javax.faces.model:
//			DataModel, DataModelEvent, DataModelListener

public class ListDataModel extends DataModel {

	private int index;
	private List list;

	public ListDataModel() {
		this(null);
	}

	public ListDataModel(List list) {
		index = -1;
		setWrappedData(list);
	}

	public boolean isRowAvailable() {
		if (list == null) {
			return false;
		}
		return index >= 0 && index < list.size();
	}

	public int getRowCount() {
		if (list == null) {
			return -1;
		} else {
			return list.size();
		}
	}

	public Object getRowData() {
		if (list == null) {
			return null;
		}
		if (!isRowAvailable()) {
			throw new IllegalArgumentException();
		} else {
			return list.get(index);
		}
	}

	public int getRowIndex() {
		return index;
	}

	public void setRowIndex(int rowIndex) {
		if (rowIndex < -1) {
			throw new IllegalArgumentException();
		}
		int old = index;
		index = rowIndex;
		if (list == null) {
			return;
		}
		DataModelListener listeners[] = getDataModelListeners();
		if (old != index && listeners != null) {
			Object rowData = null;
			if (isRowAvailable()) {
				rowData = getRowData();
			}
			DataModelEvent event = new DataModelEvent(this, index, rowData);
			int n = listeners.length;
			for (int i = 0; i < n; i++) {
				if (null != listeners[i]) {
					listeners[i].rowSelected(event);
				}
			}

		}
	}

	public Object getWrappedData() {
		return list;
	}

	public void setWrappedData(Object data) {
		if (data == null) {
			list = null;
			setRowIndex(-1);
		} else {
			list = (List)data;
			index = -1;
			setRowIndex(0);
		}
	}
}
