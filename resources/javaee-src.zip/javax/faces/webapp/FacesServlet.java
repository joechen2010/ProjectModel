// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   FacesServlet.java

package javax.faces.webapp;

import java.io.IOException;
import javax.faces.FacesException;
import javax.faces.FactoryFinder;
import javax.faces.context.FacesContext;
import javax.faces.context.FacesContextFactory;
import javax.faces.lifecycle.Lifecycle;
import javax.faces.lifecycle.LifecycleFactory;
import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public final class FacesServlet
	implements Servlet {

	public static final String CONFIG_FILES_ATTR = "javax.faces.CONFIG_FILES";
	public static final String LIFECYCLE_ID_ATTR = "javax.faces.LIFECYCLE_ID";
	private FacesContextFactory facesContextFactory;
	private Lifecycle lifecycle;
	private ServletConfig servletConfig;

	public FacesServlet() {
		facesContextFactory = null;
		lifecycle = null;
		servletConfig = null;
	}

	public void destroy() {
		facesContextFactory = null;
		lifecycle = null;
		servletConfig = null;
	}

	public ServletConfig getServletConfig() {
		return servletConfig;
	}

	public String getServletInfo() {
		return getClass().getName();
	}

	public void init(ServletConfig servletConfig) throws ServletException {
		this.servletConfig = servletConfig;
		try {
			facesContextFactory = (FacesContextFactory)FactoryFinder.getFactory("javax.faces.context.FacesContextFactory");
		}
		catch (FacesException e) {
			Throwable rootCause = e.getCause();
			if (rootCause == null) {
				throw e;
			} else {
				throw new ServletException(e.getMessage(), rootCause);
			}
		}
		try {
			LifecycleFactory lifecycleFactory = (LifecycleFactory)FactoryFinder.getFactory("javax.faces.lifecycle.LifecycleFactory");
			String lifecycleId = null;
			if (null == (lifecycleId = servletConfig.getInitParameter("javax.faces.LIFECYCLE_ID"))) {
				lifecycleId = servletConfig.getServletContext().getInitParameter("javax.faces.LIFECYCLE_ID");
			}
			if (lifecycleId == null) {
				lifecycleId = "DEFAULT";
			}
			lifecycle = lifecycleFactory.getLifecycle(lifecycleId);
		}
		catch (FacesException e) {
			Throwable rootCause = e.getCause();
			if (rootCause == null) {
				throw e;
			} else {
				throw new ServletException(e.getMessage(), rootCause);
			}
		}
	}

	public void service(ServletRequest request, ServletResponse response) throws IOException, ServletException {
		Exception exception;
		String pathInfo = ((HttpServletRequest)request).getPathInfo();
		if (pathInfo != null) {
			pathInfo = pathInfo.toUpperCase();
			if (pathInfo.startsWith("/WEB-INF/") || pathInfo.equals("/WEB-INF") || pathInfo.startsWith("/META-INF/") || pathInfo.equals("/META-INF")) {
				((HttpServletResponse)response).sendError(404);
				return;
			}
		}
		FacesContext context = facesContextFactory.getFacesContext(servletConfig.getServletContext(), request, response, lifecycle);
		try {
			lifecycle.execute(context);
			lifecycle.render(context);
		}
		catch (FacesException e) {
			Throwable t = e.getCause();
			if (t == null) {
				throw new ServletException(e.getMessage(), e);
			}
			if (t instanceof ServletException) {
				throw (ServletException)t;
			}
			if (t instanceof IOException) {
				throw (IOException)t;
			} else {
				throw new ServletException(t.getMessage(), t);
			}
		}
		finally {
			context.release();
		}
		context.release();
		break MISSING_BLOCK_LABEL_200;
		throw exception;
	}
}
