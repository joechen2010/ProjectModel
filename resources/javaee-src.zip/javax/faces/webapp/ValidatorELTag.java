// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ValidatorELTag.java

package javax.faces.webapp;

import javax.faces.component.EditableValueHolder;
import javax.faces.validator.Validator;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

// Referenced classes of package javax.faces.webapp:
//			UIComponentClassicTagBase, UIComponentELTag

public abstract class ValidatorELTag extends TagSupport {

	public ValidatorELTag() {
	}

	public int doStartTag() throws JspException {
		Validator validator = null;
		UIComponentClassicTagBase tag = UIComponentELTag.getParentUIComponentClassicTagBase(pageContext);
		if (tag == null) {
			throw new JspException((new StringBuilder()).append("Not nested in a UIComponentTag Error for tag with handler class:").append(getClass().getName()).toString());
		}
		if (!tag.getCreated()) {
			return 0;
		}
		javax.faces.component.UIComponent component = tag.getComponentInstance();
		if (component == null) {
			throw new JspException("Can't create Component from tag.");
		}
		if (!(component instanceof EditableValueHolder)) {
			throw new JspException((new StringBuilder()).append("Not nested in a tag of proper type. Error for tag with handler class:").append(getClass().getName()).toString());
		}
		validator = createValidator();
		if (validator == null) {
			throw new JspException("Can't create class of type: javax.faces.validator.Validator.  Validator is null");
		} else {
			((EditableValueHolder)component).addValidator(validator);
			return 0;
		}
	}

	protected abstract Validator createValidator() throws JspException;
}
