// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ConverterTag.java

package javax.faces.webapp;

import javax.el.ExpressionFactory;
import javax.el.ValueExpression;
import javax.faces.application.Application;
import javax.faces.component.UIComponent;
import javax.faces.component.ValueHolder;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

// Referenced classes of package javax.faces.webapp:
//			UIComponentClassicTagBase, UIComponentTag

/**
 * @deprecated Class ConverterTag is deprecated
 */

public class ConverterTag extends TagSupport {

	private static final long serialVersionUID = 0xadfc3304277ec6f8L;
	private String converterId;
	private String binding;

	public ConverterTag() {
		converterId = null;
		binding = null;
	}

	public void setConverterId(String converterId) {
		this.converterId = converterId;
	}

	public void setBinding(String binding) throws JspException {
		if (binding != null && !UIComponentTag.isValueReference(binding)) {
			throw new JspException((new StringBuilder()).append("Invalid Expression:").append(binding).toString());
		} else {
			this.binding = binding;
			return;
		}
	}

	public int doStartTag() throws JspException {
		Converter converter = null;
		UIComponentClassicTagBase tag = UIComponentClassicTagBase.getParentUIComponentClassicTagBase(pageContext);
		if (tag == null) {
			throw new JspException((new StringBuilder()).append("Not nested in a UIComponentTag Error for tag with handler class:").append(getClass().getName()).toString());
		}
		if (!tag.getCreated()) {
			return 0;
		}
		UIComponent component = tag.getComponentInstance();
		if (component == null) {
			throw new JspException("Can't create Component from tag.");
		}
		if (!(component instanceof ValueHolder)) {
			throw new JspException((new StringBuilder()).append("Not nested in a tag of proper type. Error for tag with handler class:").append(getClass().getName()).toString());
		}
		converter = createConverter();
		if (converter == null) {
			String converterError = null;
			if (binding != null) {
				converterError = binding;
			}
			if (converterId != null) {
				if (converterError != null) {
					converterError = (new StringBuilder()).append(converterError).append(" or ").append(converterId).toString();
				} else {
					converterError = converterId;
				}
			}
			throw new JspException((new StringBuilder()).append("Can't create class of type:javax.faces.convert.Converter for:").append(converterError).toString());
		}
		ValueHolder vh = (ValueHolder)component;
		FacesContext context = FacesContext.getCurrentInstance();
		vh.setConverter(converter);
		Object localValue = vh.getLocalValue();
		if (localValue instanceof String) {
			try {
				localValue = converter.getAsObject(context, (UIComponent)vh, (String)localValue);
				vh.setValue(localValue);
			}
			catch (ConverterException ce) { }
		}
		return 0;
	}

	public void release() {
		converterId = null;
	}

	protected Converter createConverter() throws JspException {
		FacesContext context;
		Converter converter;
		ValueExpression vb;
		context = FacesContext.getCurrentInstance();
		converter = null;
		vb = null;
		if (binding == null) {
			break MISSING_BLOCK_LABEL_74;
		}
		vb = context.getApplication().getExpressionFactory().createValueExpression(context.getELContext(), binding, java/lang/Object);
		if (vb == null) {
			break MISSING_BLOCK_LABEL_74;
		}
		converter = (Converter)vb.getValue(context.getELContext());
		if (converter != null) {
			return converter;
		}
		break MISSING_BLOCK_LABEL_74;
		Exception e;
		e;
		throw new JspException(e);
		if (converterId != null) {
			try {
				String converterIdVal = converterId;
				if (UIComponentTag.isValueReference(converterId)) {
					ValueExpression idBinding = context.getApplication().getExpressionFactory().createValueExpression(context.getELContext(), converterId, java/lang/Object);
					converterIdVal = (String)idBinding.getValue(context.getELContext());
				}
				converter = context.getApplication().createConverter(converterIdVal);
				if (converter != null && vb != null) {
					vb.setValue(context.getELContext(), converter);
				}
			}
			// Misplaced declaration of an exception variable
			catch (String converterIdVal) {
				throw new JspException(converterIdVal);
			}
		}
		return converter;
	}
}
