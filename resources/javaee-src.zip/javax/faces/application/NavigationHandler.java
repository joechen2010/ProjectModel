// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   NavigationHandler.java

package javax.faces.application;

import javax.faces.context.FacesContext;

public abstract class NavigationHandler {

	public NavigationHandler() {
	}

	public abstract void handleNavigation(FacesContext facescontext, String s, String s1);
}
