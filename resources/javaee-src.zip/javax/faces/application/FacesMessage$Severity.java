// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   FacesMessage.java

package javax.faces.application;


// Referenced classes of package javax.faces.application:
//			FacesMessage

public static class FacesMessage$Severity
	implements Comparable {

	private final int ordinal;
	String severityName;
	private static int nextOrdinal = 0;

	public int compareTo(Object other) {
		return ordinal - ((FacesMessage$Severity)other).ordinal;
	}

	public int getOrdinal() {
		return ordinal;
	}

	public String toString() {
		if (null == severityName) {
			return (new StringBuilder()).append("").append(ordinal).toString();
		} else {
			return (new StringBuilder()).append("").append(severityName).append(" ").append(ordinal).toString();
		}
	}


	private FacesMessage$Severity(String newSeverityName) {
		ordinal = nextOrdinal++;
		severityName = null;
		severityName = newSeverityName;
	}

	FacesMessage$Severity(String x0, FacesMessage$1 x1) {
		this(x0);
	}
}
