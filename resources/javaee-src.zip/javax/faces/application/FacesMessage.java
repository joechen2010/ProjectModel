// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   FacesMessage.java

package javax.faces.application;

import java.io.Serializable;
import java.util.*;

public class FacesMessage
	implements Serializable {
	public static class Severity
		implements Comparable {

		private final int ordinal;
		String severityName;
		private static int nextOrdinal = 0;

		public int compareTo(Object other) {
			return ordinal - ((Severity)other).ordinal;
		}

		public int getOrdinal() {
			return ordinal;
		}

		public String toString() {
			if (null == severityName) {
				return (new StringBuilder()).append("").append(ordinal).toString();
			} else {
				return (new StringBuilder()).append("").append(severityName).append(" ").append(ordinal).toString();
			}
		}


		private Severity(String newSeverityName) {
			ordinal = nextOrdinal++;
			severityName = null;
			severityName = newSeverityName;
		}

	}


	public static final String FACES_MESSAGES = "javax.faces.Messages";
	private static final String SEVERITY_INFO_NAME = "INFO";
	public static final Severity SEVERITY_INFO;
	private static final String SEVERITY_WARN_NAME = "WARN";
	public static final Severity SEVERITY_WARN;
	private static final String SEVERITY_ERROR_NAME = "ERROR";
	public static final Severity SEVERITY_ERROR;
	private static final String SEVERITY_FATAL_NAME = "FATAL";
	public static final Severity SEVERITY_FATAL;
	private static final Severity values[];
	public static final List VALUES;
	private static Map _MODIFIABLE_MAP;
	public static final Map VALUES_MAP;
	private static final long serialVersionUID = 0xef9d0c5e486654eaL;
	private Severity severity;
	private String summary;
	private String detail;

	public FacesMessage() {
		severity = SEVERITY_INFO;
		summary = null;
		detail = null;
	}

	public FacesMessage(String summary) {
		severity = SEVERITY_INFO;
		this.summary = null;
		detail = null;
		setSummary(summary);
	}

	public FacesMessage(String summary, String detail) {
		severity = SEVERITY_INFO;
		this.summary = null;
		this.detail = null;
		setSummary(summary);
		setDetail(detail);
	}

	public FacesMessage(Severity severity, String summary, String detail) {
		this.severity = SEVERITY_INFO;
		this.summary = null;
		this.detail = null;
		setSeverity(severity);
		setSummary(summary);
		setDetail(detail);
	}

	public String getDetail() {
		if (detail == null) {
			return summary;
		} else {
			return detail;
		}
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	public Severity getSeverity() {
		return severity;
	}

	public void setSeverity(Severity severity) {
		if (severity.getOrdinal() < SEVERITY_INFO.getOrdinal() || severity.getOrdinal() > SEVERITY_FATAL.getOrdinal()) {
			throw new IllegalArgumentException((new StringBuilder()).append("").append(severity).toString());
		} else {
			this.severity = severity;
			return;
		}
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	static  {
		SEVERITY_INFO = new Severity("INFO");
		SEVERITY_WARN = new Severity("WARN");
		SEVERITY_ERROR = new Severity("ERROR");
		SEVERITY_FATAL = new Severity("FATAL");
		values = (new Severity[] {
			SEVERITY_INFO, SEVERITY_WARN, SEVERITY_ERROR, SEVERITY_FATAL
		});
		VALUES = Collections.unmodifiableList(Arrays.asList(values));
		_MODIFIABLE_MAP = new HashMap();
		int i = 0;
		for (int len = values.length; i < len; i++) {
			_MODIFIABLE_MAP.put(values[i].severityName, values[i]);
		}

		VALUES_MAP = Collections.unmodifiableMap(_MODIFIABLE_MAP);
	}
}
