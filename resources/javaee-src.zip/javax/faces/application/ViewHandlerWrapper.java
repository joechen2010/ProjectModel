// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ViewHandlerWrapper.java

package javax.faces.application;

import java.io.IOException;
import java.util.Locale;
import javax.faces.FacesException;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.application:
//			ViewHandler

public abstract class ViewHandlerWrapper extends ViewHandler {

	public ViewHandlerWrapper() {
	}

	protected abstract ViewHandler getWrapped();

	public String calculateCharacterEncoding(FacesContext context) {
		return getWrapped().calculateCharacterEncoding(context);
	}

	public Locale calculateLocale(FacesContext context) {
		return getWrapped().calculateLocale(context);
	}

	public String calculateRenderKitId(FacesContext context) {
		return getWrapped().calculateRenderKitId(context);
	}

	public UIViewRoot createView(FacesContext context, String viewId) {
		return getWrapped().createView(context, viewId);
	}

	public String getActionURL(FacesContext context, String viewId) {
		return getWrapped().getActionURL(context, viewId);
	}

	public String getResourceURL(FacesContext context, String path) {
		return getWrapped().getResourceURL(context, path);
	}

	public void initView(FacesContext context) throws FacesException {
		getWrapped().initView(context);
	}

	public void renderView(FacesContext context, UIViewRoot viewToRender) throws IOException, FacesException {
		getWrapped().renderView(context, viewToRender);
	}

	public UIViewRoot restoreView(FacesContext context, String viewId) {
		return getWrapped().restoreView(context, viewId);
	}

	public void writeState(FacesContext context) throws IOException {
		getWrapped().writeState(context);
	}
}
