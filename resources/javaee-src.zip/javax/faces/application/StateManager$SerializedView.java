// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   StateManager.java

package javax.faces.application;


// Referenced classes of package javax.faces.application:
//			StateManager

/**
 * @deprecated Class StateManager$SerializedView is deprecated
 */

public class StateManager$SerializedView {

	private Object structure;
	private Object state;
	final StateManager this$0;

	public Object getStructure() {
		return structure;
	}

	public Object getState() {
		return state;
	}

	public StateManager$SerializedView(Object newStructure, Object newState) {
		this$0 = StateManager.this;
		super();
		structure = null;
		state = null;
		structure = newStructure;
		state = newState;
	}
}
