// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ViewHandler.java

package javax.faces.application;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.FacesException;
import javax.faces.component.UIViewRoot;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

public abstract class ViewHandler {

	private static Logger log = Logger.getLogger("javax.faces.application");
	public static final String CHARACTER_ENCODING_KEY = "javax.faces.request.charset";
	public static final String DEFAULT_SUFFIX_PARAM_NAME = "javax.faces.DEFAULT_SUFFIX";
	public static final String DEFAULT_SUFFIX = ".jsp";

	public ViewHandler() {
	}

	public abstract Locale calculateLocale(FacesContext facescontext);

	public String calculateCharacterEncoding(FacesContext context) {
		ExternalContext extContext = context.getExternalContext();
		Map headerMap = extContext.getRequestHeaderMap();
		String contentType = (String)headerMap.get("Content-Type");
		String charEnc = null;
		if (null != contentType) {
			String charsetStr = "charset=";
			int len = charsetStr.length();
			int idx = contentType.indexOf(charsetStr);
			if (idx != -1 && idx + len < contentType.length()) {
				charEnc = contentType.substring(idx + len);
			}
		}
		if (null == charEnc && null != extContext.getSession(false)) {
			charEnc = (String)extContext.getSessionMap().get("javax.faces.request.charset");
		}
		return charEnc;
	}

	public abstract String calculateRenderKitId(FacesContext facescontext);

	public abstract UIViewRoot createView(FacesContext facescontext, String s);

	public abstract String getActionURL(FacesContext facescontext, String s);

	public abstract String getResourceURL(FacesContext facescontext, String s);

	public void initView(FacesContext context) throws FacesException {
		String encoding = calculateCharacterEncoding(context);
		if (null != encoding) {
			try {
				context.getExternalContext().setRequestCharacterEncoding(encoding);
			}
			catch (UnsupportedEncodingException e) {
				String message = (new StringBuilder()).append("Can't set encoding to: ").append(encoding).append(" Exception:").append(e.getMessage()).toString();
				if (log.isLoggable(Level.WARNING)) {
					log.fine(message);
				}
				throw new FacesException(message, e);
			}
		}
	}

	public abstract void renderView(FacesContext facescontext, UIViewRoot uiviewroot) throws IOException, FacesException;

	public abstract UIViewRoot restoreView(FacesContext facescontext, String s);

	public abstract void writeState(FacesContext facescontext) throws IOException;

}
