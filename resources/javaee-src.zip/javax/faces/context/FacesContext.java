// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   FacesContext.java

package javax.faces.context;

import java.util.Iterator;
import java.util.Map;
import javax.el.ELContext;
import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIViewRoot;
import javax.faces.render.RenderKit;

// Referenced classes of package javax.faces.context:
//			ExternalContext, ResponseStream, ResponseWriter

public abstract class FacesContext {

	private static ThreadLocal instance = new ThreadLocal() {

		protected Object initialValue() {
			return null;
		}

	};

	public FacesContext() {
	}

	public abstract Application getApplication();

	public abstract Iterator getClientIdsWithMessages();

	public ELContext getELContext() {
		FacesContext impl = null;
		if (null != (impl = (FacesContext)getExternalContext().getRequestMap().get("com.sun.faces.FacesContextImpl"))) {
			return impl.getELContext();
		} else {
			throw new UnsupportedOperationException();
		}
	}

	public abstract ExternalContext getExternalContext();

	public abstract javax.faces.application.FacesMessage.Severity getMaximumSeverity();

	public abstract Iterator getMessages();

	public abstract Iterator getMessages(String s);

	public abstract RenderKit getRenderKit();

	public abstract boolean getRenderResponse();

	public abstract boolean getResponseComplete();

	public abstract ResponseStream getResponseStream();

	public abstract void setResponseStream(ResponseStream responsestream);

	public abstract ResponseWriter getResponseWriter();

	public abstract void setResponseWriter(ResponseWriter responsewriter);

	public abstract UIViewRoot getViewRoot();

	public abstract void setViewRoot(UIViewRoot uiviewroot);

	public abstract void addMessage(String s, FacesMessage facesmessage);

	public abstract void release();

	public abstract void renderResponse();

	public abstract void responseComplete();

	public static FacesContext getCurrentInstance() {
		return (FacesContext)instance.get();
	}

	protected static void setCurrentInstance(FacesContext context) {
		instance.set(context);
	}

}
