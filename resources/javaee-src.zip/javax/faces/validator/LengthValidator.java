// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   LengthValidator.java

package javax.faces.validator;

import javax.faces.application.Application;
import javax.faces.component.StateHolder;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

// Referenced classes of package javax.faces.validator:
//			MessageFactory, Validator, ValidatorException

public class LengthValidator
	implements Validator, StateHolder {

	public static final String VALIDATOR_ID = "javax.faces.Length";
	public static final String MAXIMUM_MESSAGE_ID = "javax.faces.validator.LengthValidator.MAXIMUM";
	public static final String MINIMUM_MESSAGE_ID = "javax.faces.validator.LengthValidator.MINIMUM";
	private int maximum;
	private boolean maximumSet;
	private int minimum;
	private boolean minimumSet;
	private boolean transientValue;

	public LengthValidator() {
		maximum = 0;
		maximumSet = false;
		minimum = 0;
		minimumSet = false;
		transientValue = false;
	}

	public LengthValidator(int maximum) {
		this.maximum = 0;
		maximumSet = false;
		minimum = 0;
		minimumSet = false;
		transientValue = false;
		setMaximum(maximum);
	}

	public LengthValidator(int maximum, int minimum) {
		this.maximum = 0;
		maximumSet = false;
		this.minimum = 0;
		minimumSet = false;
		transientValue = false;
		setMaximum(maximum);
		setMinimum(minimum);
	}

	public int getMaximum() {
		return maximum;
	}

	public void setMaximum(int maximum) {
		this.maximum = maximum;
		maximumSet = true;
	}

	public int getMinimum() {
		return minimum;
	}

	public void setMinimum(int minimum) {
		this.minimum = minimum;
		minimumSet = true;
	}

	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		if (context == null || component == null) {
			throw new NullPointerException();
		}
		if (value != null) {
			String converted = stringValue(value);
			if (maximumSet && converted.length() > maximum) {
				throw new ValidatorException(MessageFactory.getMessage(context, "javax.faces.validator.LengthValidator.MAXIMUM", new Object[] {
					integerToString(component, new Integer(maximum)), MessageFactory.getLabel(context, component)
				}));
			}
			if (minimumSet && converted.length() < minimum) {
				throw new ValidatorException(MessageFactory.getMessage(context, "javax.faces.validator.LengthValidator.MINIMUM", new Object[] {
					integerToString(component, new Integer(minimum)), MessageFactory.getLabel(context, component)
				}));
			}
		}
	}

	public boolean equals(Object otherObj) {
		if (!(otherObj instanceof LengthValidator)) {
			return false;
		} else {
			LengthValidator other = (LengthValidator)otherObj;
			return maximum == other.maximum && minimum == other.minimum && maximumSet == other.maximumSet && minimumSet == other.minimumSet;
		}
	}

	public int hashCode() {
		int hashCode = minimum + maximum + Boolean.valueOf(minimumSet).hashCode() + Boolean.valueOf(maximumSet).hashCode();
		return hashCode;
	}

	private String stringValue(Object attributeValue) {
		if (attributeValue == null) {
			return null;
		}
		if (attributeValue instanceof String) {
			return (String)attributeValue;
		} else {
			return attributeValue.toString();
		}
	}

	private String integerToString(UIComponent component, Integer toConvert) {
		String result = null;
		Converter converter = null;
		FacesContext context = FacesContext.getCurrentInstance();
		converter = context.getApplication().createConverter("javax.faces.Number");
		result = converter.getAsString(context, component, toConvert);
		return result;
	}

	public Object saveState(FacesContext context) {
		Object values[] = new Object[4];
		values[0] = new Integer(maximum);
		values[1] = maximumSet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[2] = new Integer(minimum);
		values[3] = minimumSet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		return ((Object) (values));
	}

	public void restoreState(FacesContext context, Object state) {
		Object values[] = (Object[])(Object[])state;
		maximum = ((Integer)values[0]).intValue();
		maximumSet = ((Boolean)values[1]).booleanValue();
		minimum = ((Integer)values[2]).intValue();
		minimumSet = ((Boolean)values[3]).booleanValue();
	}

	public boolean isTransient() {
		return transientValue;
	}

	public void setTransient(boolean transientValue) {
		this.transientValue = transientValue;
	}
}
