// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   FacesEvent.java

package javax.faces.event;

import java.util.EventObject;
import javax.faces.component.UIComponent;

// Referenced classes of package javax.faces.event:
//			PhaseId, FacesListener

public abstract class FacesEvent extends EventObject {

	private PhaseId phaseId;

	public FacesEvent(UIComponent component) {
		super(component);
		phaseId = PhaseId.ANY_PHASE;
	}

	public UIComponent getComponent() {
		return (UIComponent)getSource();
	}

	public PhaseId getPhaseId() {
		return phaseId;
	}

	public void setPhaseId(PhaseId phaseId) {
		if (null == phaseId) {
			throw new IllegalArgumentException();
		} else {
			this.phaseId = phaseId;
			return;
		}
	}

	public void queue() {
		getComponent().queueEvent(this);
	}

	public abstract boolean isAppropriateListener(FacesListener faceslistener);

	public abstract void processListener(FacesListener faceslistener);
}
