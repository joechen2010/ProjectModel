// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ValueChangeEvent.java

package javax.faces.event;

import javax.faces.component.UIComponent;

// Referenced classes of package javax.faces.event:
//			FacesEvent, ValueChangeListener, FacesListener

public class ValueChangeEvent extends FacesEvent {

	private Object oldValue;
	private Object newValue;

	public ValueChangeEvent(UIComponent component, Object oldValue, Object newValue) {
		super(component);
		this.oldValue = null;
		this.newValue = null;
		this.oldValue = oldValue;
		this.newValue = newValue;
	}

	public Object getOldValue() {
		return oldValue;
	}

	public Object getNewValue() {
		return newValue;
	}

	public boolean isAppropriateListener(FacesListener listener) {
		return listener instanceof ValueChangeListener;
	}

	public void processListener(FacesListener listener) {
		((ValueChangeListener)listener).processValueChange(this);
	}
}
