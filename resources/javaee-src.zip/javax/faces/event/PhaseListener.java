// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   PhaseListener.java

package javax.faces.event;

import java.io.Serializable;
import java.util.EventListener;

// Referenced classes of package javax.faces.event:
//			PhaseEvent, PhaseId

public interface PhaseListener
	extends EventListener, Serializable {

	public abstract void afterPhase(PhaseEvent phaseevent);

	public abstract void beforePhase(PhaseEvent phaseevent);

	public abstract PhaseId getPhaseId();
}
