// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ActionEvent.java

package javax.faces.event;

import javax.faces.component.UIComponent;

// Referenced classes of package javax.faces.event:
//			FacesEvent, ActionListener, FacesListener

public class ActionEvent extends FacesEvent {

	public ActionEvent(UIComponent component) {
		super(component);
	}

	public boolean isAppropriateListener(FacesListener listener) {
		return listener instanceof ActionListener;
	}

	public void processListener(FacesListener listener) {
		((ActionListener)listener).processAction(this);
	}
}
