// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   PhaseEvent.java

package javax.faces.event;

import java.util.EventObject;
import javax.faces.context.FacesContext;
import javax.faces.lifecycle.Lifecycle;

// Referenced classes of package javax.faces.event:
//			PhaseId

public class PhaseEvent extends EventObject {

	private FacesContext context;
	private PhaseId phaseId;

	public PhaseEvent(FacesContext context, PhaseId phaseId, Lifecycle lifecycle) {
		super(lifecycle);
		this.context = null;
		this.phaseId = null;
		if (phaseId == null || context == null || lifecycle == null) {
			throw new NullPointerException();
		} else {
			this.phaseId = phaseId;
			this.context = context;
			return;
		}
	}

	public FacesContext getFacesContext() {
		return context;
	}

	public PhaseId getPhaseId() {
		return phaseId;
	}
}
