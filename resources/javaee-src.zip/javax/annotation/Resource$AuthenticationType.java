// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   Resource.java

package javax.annotation;


// Referenced classes of package javax.annotation:
//			Resource

public static final class Resource$AuthenticationType extends Enum {

	public static final Resource$AuthenticationType CONTAINER;
	public static final Resource$AuthenticationType APPLICATION;
	private static final Resource$AuthenticationType $VALUES[];

	public static final Resource$AuthenticationType[] values() {
		return (Resource$AuthenticationType[])$VALUES.clone();
	}

	public static Resource$AuthenticationType valueOf(String name) {
		Resource$AuthenticationType arr$[] = $VALUES;
		int len$ = arr$.length;
		for (int i$ = 0; i$ < len$; i$++) {
			Resource$AuthenticationType resource$authenticationtype = arr$[i$];
			if (resource$authenticationtype.name().equals(name)) {
				return resource$authenticationtype;
			}
		}

		throw new IllegalArgumentException(name);
	}

	static  {
		CONTAINER = new Resource$AuthenticationType("CONTAINER", 0);
		APPLICATION = new Resource$AuthenticationType("APPLICATION", 1);
		$VALUES = (new Resource$AuthenticationType[] {
			CONTAINER, APPLICATION
		});
	}

	private Resource$AuthenticationType(String s, int i) {
		super(s, i);
	}
}
