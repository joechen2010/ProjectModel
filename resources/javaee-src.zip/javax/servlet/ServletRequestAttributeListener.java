// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ServletRequestAttributeListener.java

package javax.servlet;

import java.util.EventListener;

// Referenced classes of package javax.servlet:
//			ServletRequestAttributeEvent

public interface ServletRequestAttributeListener
	extends EventListener {

	public abstract void attributeAdded(ServletRequestAttributeEvent servletrequestattributeevent);

	public abstract void attributeRemoved(ServletRequestAttributeEvent servletrequestattributeevent);

	public abstract void attributeReplaced(ServletRequestAttributeEvent servletrequestattributeevent);
}
