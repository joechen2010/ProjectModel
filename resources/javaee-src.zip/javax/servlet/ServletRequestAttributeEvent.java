// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ServletRequestAttributeEvent.java

package javax.servlet;


// Referenced classes of package javax.servlet:
//			ServletRequestEvent, ServletContext, ServletRequest

public class ServletRequestAttributeEvent extends ServletRequestEvent {

	private String name;
	private Object value;

	public ServletRequestAttributeEvent(ServletContext sc, ServletRequest request, String name, Object value) {
		super(sc, request);
		this.name = name;
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public Object getValue() {
		return value;
	}
}
