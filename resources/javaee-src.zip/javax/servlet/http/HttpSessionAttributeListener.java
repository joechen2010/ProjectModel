// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   HttpSessionAttributeListener.java

package javax.servlet.http;

import java.util.EventListener;

// Referenced classes of package javax.servlet.http:
//			HttpSessionBindingEvent

public interface HttpSessionAttributeListener
	extends EventListener {

	public abstract void attributeAdded(HttpSessionBindingEvent httpsessionbindingevent);

	public abstract void attributeRemoved(HttpSessionBindingEvent httpsessionbindingevent);

	public abstract void attributeReplaced(HttpSessionBindingEvent httpsessionbindingevent);
}
