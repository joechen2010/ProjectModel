// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   JspFactory.java

package javax.servlet.jsp;

import javax.servlet.*;

// Referenced classes of package javax.servlet.jsp:
//			PageContext, JspEngineInfo, JspApplicationContext

public abstract class JspFactory {

	private static JspFactory deflt = null;

	public JspFactory() {
	}

	public static synchronized void setDefaultFactory(JspFactory deflt) {
		deflt = deflt;
	}

	public static synchronized JspFactory getDefaultFactory() {
		return deflt;
	}

	public abstract PageContext getPageContext(Servlet servlet, ServletRequest servletrequest, ServletResponse servletresponse, String s, boolean flag, int i, boolean flag1);

	public abstract void releasePageContext(PageContext pagecontext);

	public abstract JspEngineInfo getEngineInfo();

	public abstract JspApplicationContext getJspApplicationContext(ServletContext servletcontext);

}
