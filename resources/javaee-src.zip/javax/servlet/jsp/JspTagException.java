// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   JspTagException.java

package javax.servlet.jsp;


// Referenced classes of package javax.servlet.jsp:
//			JspException

public class JspTagException extends JspException {

	public JspTagException(String msg) {
		super(msg);
	}

	public JspTagException() {
	}

	public JspTagException(String message, Throwable rootCause) {
		super(message, rootCause);
	}

	public JspTagException(Throwable rootCause) {
		super(rootCause);
	}
}
