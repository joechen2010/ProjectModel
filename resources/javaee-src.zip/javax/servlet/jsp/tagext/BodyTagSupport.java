// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   BodyTagSupport.java

package javax.servlet.jsp.tagext;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;

// Referenced classes of package javax.servlet.jsp.tagext:
//			TagSupport, BodyContent, BodyTag

public class BodyTagSupport extends TagSupport
	implements BodyTag {

	protected BodyContent bodyContent;

	public BodyTagSupport() {
	}

	public int doStartTag() throws JspException {
		return 2;
	}

	public int doEndTag() throws JspException {
		return super.doEndTag();
	}

	public void setBodyContent(BodyContent b) {
		bodyContent = b;
	}

	public void doInitBody() throws JspException {
	}

	public int doAfterBody() throws JspException {
		return 0;
	}

	public void release() {
		bodyContent = null;
		super.release();
	}

	public BodyContent getBodyContent() {
		return bodyContent;
	}

	public JspWriter getPreviousOut() {
		return bodyContent.getEnclosingWriter();
	}
}
