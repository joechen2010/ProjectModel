// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   TagAdapter.java

package javax.servlet.jsp.tagext;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;

// Referenced classes of package javax.servlet.jsp.tagext:
//			SimpleTag, Tag, JspTag

public class TagAdapter
	implements Tag {

	private SimpleTag simpleTagAdaptee;
	private Tag parent;
	private boolean parentDetermined;

	public TagAdapter(SimpleTag adaptee) {
		if (adaptee == null) {
			throw new IllegalArgumentException();
		} else {
			simpleTagAdaptee = adaptee;
			return;
		}
	}

	public void setPageContext(PageContext pc) {
		throw new UnsupportedOperationException("Illegal to invoke setPageContext() on TagAdapter wrapper");
	}

	public void setParent(Tag parentTag) {
		throw new UnsupportedOperationException("Illegal to invoke setParent() on TagAdapter wrapper");
	}

	public Tag getParent() {
		if (!parentDetermined) {
			JspTag adapteeParent = simpleTagAdaptee.getParent();
			if (adapteeParent != null) {
				if (adapteeParent instanceof Tag) {
					parent = (Tag)adapteeParent;
				} else {
					parent = new TagAdapter((SimpleTag)adapteeParent);
				}
			}
			parentDetermined = true;
		}
		return parent;
	}

	public JspTag getAdaptee() {
		return simpleTagAdaptee;
	}

	public int doStartTag() throws JspException {
		throw new UnsupportedOperationException("Illegal to invoke doStartTag() on TagAdapter wrapper");
	}

	public int doEndTag() throws JspException {
		throw new UnsupportedOperationException("Illegal to invoke doEndTag() on TagAdapter wrapper");
	}

	public void release() {
		throw new UnsupportedOperationException("Illegal to invoke release() on TagAdapter wrapper");
	}
}
