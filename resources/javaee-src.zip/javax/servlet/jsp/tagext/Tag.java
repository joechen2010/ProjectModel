// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   Tag.java

package javax.servlet.jsp.tagext;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;

// Referenced classes of package javax.servlet.jsp.tagext:
//			JspTag

public interface Tag
	extends JspTag {

	public static final int SKIP_BODY = 0;
	public static final int EVAL_BODY_INCLUDE = 1;
	public static final int SKIP_PAGE = 5;
	public static final int EVAL_PAGE = 6;

	public abstract void setPageContext(PageContext pagecontext);

	public abstract void setParent(Tag tag);

	public abstract Tag getParent();

	public abstract int doStartTag() throws JspException;

	public abstract int doEndTag() throws JspException;

	public abstract void release();
}
