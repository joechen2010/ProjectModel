// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   BodyContent.java

package javax.servlet.jsp.tagext;

import java.io.*;
import javax.servlet.jsp.JspWriter;

public abstract class BodyContent extends JspWriter {

	private JspWriter enclosingWriter;

	protected BodyContent(JspWriter e) {
		super(-2, false);
		enclosingWriter = e;
	}

	public void flush() throws IOException {
		throw new IOException("Illegal to flush within a custom tag");
	}

	public void clearBody() {
		try {
			clear();
		}
		catch (IOException ex) {
			throw new Error("internal error!;");
		}
	}

	public abstract Reader getReader();

	public abstract String getString();

	public abstract void writeOut(Writer writer) throws IOException;

	public JspWriter getEnclosingWriter() {
		return enclosingWriter;
	}
}
