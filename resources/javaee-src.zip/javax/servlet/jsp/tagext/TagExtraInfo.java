// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   TagExtraInfo.java

package javax.servlet.jsp.tagext;


// Referenced classes of package javax.servlet.jsp.tagext:
//			TagData, ValidationMessage, VariableInfo, TagInfo

public abstract class TagExtraInfo {

	private TagInfo tagInfo;
	private static final VariableInfo ZERO_VARIABLE_INFO[] = new VariableInfo[0];

	public TagExtraInfo() {
	}

	public VariableInfo[] getVariableInfo(TagData data) {
		return ZERO_VARIABLE_INFO;
	}

	public boolean isValid(TagData data) {
		return true;
	}

	public ValidationMessage[] validate(TagData data) {
		ValidationMessage result[] = null;
		if (!isValid(data)) {
			result = (new ValidationMessage[] {
				new ValidationMessage(data.getId(), "isValid() == false")
			});
		}
		return result;
	}

	public final void setTagInfo(TagInfo tagInfo) {
		this.tagInfo = tagInfo;
	}

	public final TagInfo getTagInfo() {
		return tagInfo;
	}

}
