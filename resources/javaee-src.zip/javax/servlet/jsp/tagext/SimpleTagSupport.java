// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   SimpleTagSupport.java

package javax.servlet.jsp.tagext;

import java.io.IOException;
import javax.servlet.jsp.JspContext;
import javax.servlet.jsp.JspException;

// Referenced classes of package javax.servlet.jsp.tagext:
//			JspTag, SimpleTag, Tag, TagAdapter, 
//			JspFragment

public class SimpleTagSupport
	implements SimpleTag {

	private JspTag parentTag;
	private JspContext jspContext;
	private JspFragment jspBody;

	public SimpleTagSupport() {
	}

	public void doTag() throws JspException, IOException {
	}

	public void setParent(JspTag parent) {
		parentTag = parent;
	}

	public JspTag getParent() {
		return parentTag;
	}

	public void setJspContext(JspContext pc) {
		jspContext = pc;
	}

	protected JspContext getJspContext() {
		return jspContext;
	}

	public void setJspBody(JspFragment jspBody) {
		this.jspBody = jspBody;
	}

	protected JspFragment getJspBody() {
		return jspBody;
	}

	public static final JspTag findAncestorWithClass(JspTag from, Class klass) {
		boolean isInterface = false;
		if (from == null || klass == null || !javax/servlet/jsp/tagext/JspTag.isAssignableFrom(klass) && !(isInterface = klass.isInterface())) {
			return null;
		}
		do {
			JspTag parent = null;
			if (from instanceof SimpleTag) {
				parent = ((SimpleTag)from).getParent();
			} else
			if (from instanceof Tag) {
				parent = ((Tag)from).getParent();
			}
			if (parent == null) {
				return null;
			}
			if (parent instanceof TagAdapter) {
				parent = ((TagAdapter)parent).getAdaptee();
			}
			if (isInterface && klass.isInstance(parent) || klass.isAssignableFrom(parent.getClass())) {
				return parent;
			}
			from = parent;
		} while (true);
	}
}
