// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   VariableInfo.java

package javax.servlet.jsp.tagext;


public class VariableInfo {

	public static final int NESTED = 0;
	public static final int AT_BEGIN = 1;
	public static final int AT_END = 2;
	private String varName;
	private String className;
	private boolean declare;
	private int scope;

	public VariableInfo(String varName, String className, boolean declare, int scope) {
		this.varName = varName;
		this.className = className;
		this.declare = declare;
		this.scope = scope;
	}

	public String getVarName() {
		return varName;
	}

	public String getClassName() {
		return className;
	}

	public boolean getDeclare() {
		return declare;
	}

	public int getScope() {
		return scope;
	}
}
