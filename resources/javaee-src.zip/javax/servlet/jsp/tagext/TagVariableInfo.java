// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   TagVariableInfo.java

package javax.servlet.jsp.tagext;


public class TagVariableInfo {

	private String nameGiven;
	private String nameFromAttribute;
	private String className;
	private boolean declare;
	private int scope;

	public TagVariableInfo(String nameGiven, String nameFromAttribute, String className, boolean declare, int scope) {
		this.nameGiven = nameGiven;
		this.nameFromAttribute = nameFromAttribute;
		this.className = className;
		this.declare = declare;
		this.scope = scope;
	}

	public String getNameGiven() {
		return nameGiven;
	}

	public String getNameFromAttribute() {
		return nameFromAttribute;
	}

	public String getClassName() {
		return className;
	}

	public boolean getDeclare() {
		return declare;
	}

	public int getScope() {
		return scope;
	}
}
