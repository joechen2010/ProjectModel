// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   TagLibraryValidator.java

package javax.servlet.jsp.tagext;

import java.util.Map;

// Referenced classes of package javax.servlet.jsp.tagext:
//			PageData, ValidationMessage

public abstract class TagLibraryValidator {

	private Map initParameters;

	public TagLibraryValidator() {
	}

	public void setInitParameters(Map map) {
		initParameters = map;
	}

	public Map getInitParameters() {
		return initParameters;
	}

	public ValidationMessage[] validate(String prefix, String uri, PageData page) {
		return null;
	}

	public void release() {
		initParameters = null;
	}
}
