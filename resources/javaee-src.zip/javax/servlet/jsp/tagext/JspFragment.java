// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   JspFragment.java

package javax.servlet.jsp.tagext;

import java.io.IOException;
import java.io.Writer;
import javax.servlet.jsp.JspContext;
import javax.servlet.jsp.JspException;

public abstract class JspFragment {

	public JspFragment() {
	}

	public abstract void invoke(Writer writer) throws JspException, IOException;

	public abstract JspContext getJspContext();
}
