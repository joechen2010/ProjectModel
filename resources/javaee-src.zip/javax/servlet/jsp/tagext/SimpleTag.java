// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   SimpleTag.java

package javax.servlet.jsp.tagext;

import java.io.IOException;
import javax.servlet.jsp.JspContext;
import javax.servlet.jsp.JspException;

// Referenced classes of package javax.servlet.jsp.tagext:
//			JspTag, JspFragment

public interface SimpleTag
	extends JspTag {

	public abstract void doTag() throws JspException, IOException;

	public abstract void setParent(JspTag jsptag);

	public abstract JspTag getParent();

	public abstract void setJspContext(JspContext jspcontext);

	public abstract void setJspBody(JspFragment jspfragment);
}
