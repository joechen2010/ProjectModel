// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   TagInfo.java

package javax.servlet.jsp.tagext;


// Referenced classes of package javax.servlet.jsp.tagext:
//			TagExtraInfo, TagLibraryInfo, TagAttributeInfo, TagVariableInfo, 
//			TagData, VariableInfo, ValidationMessage

public class TagInfo {

	public static final String BODY_CONTENT_JSP = "JSP";
	public static final String BODY_CONTENT_TAG_DEPENDENT = "tagdependent";
	public static final String BODY_CONTENT_EMPTY = "empty";
	public static final String BODY_CONTENT_SCRIPTLESS = "scriptless";
	private String tagName;
	private String tagClassName;
	private String bodyContent;
	private String infoString;
	private TagLibraryInfo tagLibrary;
	private TagExtraInfo tagExtraInfo;
	private TagAttributeInfo attributeInfo[];
	private String displayName;
	private String smallIcon;
	private String largeIcon;
	private TagVariableInfo tagVariableInfo[];
	private boolean dynamicAttributes;

	public TagInfo(String tagName, String tagClassName, String bodycontent, String infoString, TagLibraryInfo taglib, TagExtraInfo tagExtraInfo, TagAttributeInfo attributeInfo[]) {
		this.tagName = tagName;
		this.tagClassName = tagClassName;
		bodyContent = bodycontent;
		this.infoString = infoString;
		tagLibrary = taglib;
		this.tagExtraInfo = tagExtraInfo;
		this.attributeInfo = attributeInfo;
		if (tagExtraInfo != null) {
			tagExtraInfo.setTagInfo(this);
		}
	}

	public TagInfo(String tagName, String tagClassName, String bodycontent, String infoString, TagLibraryInfo taglib, TagExtraInfo tagExtraInfo, TagAttributeInfo attributeInfo[], 
			String displayName, String smallIcon, String largeIcon, TagVariableInfo tvi[]) {
		this.tagName = tagName;
		this.tagClassName = tagClassName;
		bodyContent = bodycontent;
		this.infoString = infoString;
		tagLibrary = taglib;
		this.tagExtraInfo = tagExtraInfo;
		this.attributeInfo = attributeInfo;
		this.displayName = displayName;
		this.smallIcon = smallIcon;
		this.largeIcon = largeIcon;
		tagVariableInfo = tvi;
		if (tagExtraInfo != null) {
			tagExtraInfo.setTagInfo(this);
		}
	}

	public TagInfo(String tagName, String tagClassName, String bodycontent, String infoString, TagLibraryInfo taglib, TagExtraInfo tagExtraInfo, TagAttributeInfo attributeInfo[], 
			String displayName, String smallIcon, String largeIcon, TagVariableInfo tvi[], boolean dynamicAttributes) {
		this.tagName = tagName;
		this.tagClassName = tagClassName;
		bodyContent = bodycontent;
		this.infoString = infoString;
		tagLibrary = taglib;
		this.tagExtraInfo = tagExtraInfo;
		this.attributeInfo = attributeInfo;
		this.displayName = displayName;
		this.smallIcon = smallIcon;
		this.largeIcon = largeIcon;
		tagVariableInfo = tvi;
		this.dynamicAttributes = dynamicAttributes;
		if (tagExtraInfo != null) {
			tagExtraInfo.setTagInfo(this);
		}
	}

	public String getTagName() {
		return tagName;
	}

	public TagAttributeInfo[] getAttributes() {
		return attributeInfo;
	}

	public VariableInfo[] getVariableInfo(TagData data) {
		VariableInfo result[] = null;
		TagExtraInfo tei = getTagExtraInfo();
		if (tei != null) {
			result = tei.getVariableInfo(data);
		}
		return result;
	}

	public boolean isValid(TagData data) {
		TagExtraInfo tei = getTagExtraInfo();
		if (tei == null) {
			return true;
		} else {
			return tei.isValid(data);
		}
	}

	public ValidationMessage[] validate(TagData data) {
		TagExtraInfo tei = getTagExtraInfo();
		if (tei == null) {
			return null;
		} else {
			return tei.validate(data);
		}
	}

	public void setTagExtraInfo(TagExtraInfo tei) {
		tagExtraInfo = tei;
	}

	public TagExtraInfo getTagExtraInfo() {
		return tagExtraInfo;
	}

	public String getTagClassName() {
		return tagClassName;
	}

	public String getBodyContent() {
		return bodyContent;
	}

	public String getInfoString() {
		return infoString;
	}

	public void setTagLibrary(TagLibraryInfo tl) {
		tagLibrary = tl;
	}

	public TagLibraryInfo getTagLibrary() {
		return tagLibrary;
	}

	public String getDisplayName() {
		return displayName;
	}

	public String getSmallIcon() {
		return smallIcon;
	}

	public String getLargeIcon() {
		return largeIcon;
	}

	public TagVariableInfo[] getTagVariableInfos() {
		return tagVariableInfo;
	}

	public boolean hasDynamicAttributes() {
		return dynamicAttributes;
	}
}
