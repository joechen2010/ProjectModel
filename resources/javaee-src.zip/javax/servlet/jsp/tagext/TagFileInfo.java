// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   TagFileInfo.java

package javax.servlet.jsp.tagext;


// Referenced classes of package javax.servlet.jsp.tagext:
//			TagInfo

public class TagFileInfo {

	private String name;
	private String path;
	private TagInfo tagInfo;

	public TagFileInfo(String name, String path, TagInfo tagInfo) {
		this.name = name;
		this.path = path;
		this.tagInfo = tagInfo;
	}

	public String getName() {
		return name;
	}

	public String getPath() {
		return path;
	}

	public TagInfo getTagInfo() {
		return tagInfo;
	}
}
