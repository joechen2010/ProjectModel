// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   TagAttributeInfo.java

package javax.servlet.jsp.tagext;


public class TagAttributeInfo {

	public static final String ID = "id";
	private String name;
	private String type;
	private boolean reqTime;
	private boolean required;
	private boolean fragment;
	private boolean deferredValue;
	private boolean deferredMethod;
	private String expectedTypeName;
	private String methodSignature;
	private String description;

	public TagAttributeInfo(String name, boolean required, String type, boolean reqTime) {
		this.name = name;
		this.required = required;
		this.type = type;
		this.reqTime = reqTime;
	}

	public TagAttributeInfo(String name, boolean required, String type, boolean reqTime, boolean fragment) {
		this(name, required, type, reqTime);
		this.fragment = fragment;
	}

	public TagAttributeInfo(String name, boolean required, String type, boolean reqTime, boolean fragment, String description, boolean deferredValue, 
			boolean deferredMethod, String expectedTypeName, String methodSignature) {
		this(name, required, type, reqTime, fragment);
		this.description = description;
		this.deferredValue = deferredValue;
		this.deferredMethod = deferredMethod;
		this.expectedTypeName = expectedTypeName;
		this.methodSignature = methodSignature;
	}

	public String getName() {
		return name;
	}

	public String getTypeName() {
		return type;
	}

	public boolean canBeRequestTime() {
		return reqTime;
	}

	public boolean isRequired() {
		return required;
	}

	public static TagAttributeInfo getIdAttribute(TagAttributeInfo a[]) {
		for (int i = 0; i < a.length; i++) {
			if (a[i].getName().equals("id")) {
				return a[i];
			}
		}

		return null;
	}

	public boolean isFragment() {
		return fragment;
	}

	public String getDescription() {
		return description;
	}

	public boolean isDeferredValue() {
		return deferredValue;
	}

	public boolean isDeferredMethod() {
		return deferredMethod;
	}

	public String getExpectedTypeName() {
		return expectedTypeName;
	}

	public String getMethodSignature() {
		return methodSignature;
	}

	public String toString() {
		StringBuffer b = new StringBuffer();
		b.append((new StringBuilder()).append("name = ").append(name).append(" ").toString());
		b.append((new StringBuilder()).append("type = ").append(type).append(" ").toString());
		b.append((new StringBuilder()).append("reqTime = ").append(reqTime).append(" ").toString());
		b.append((new StringBuilder()).append("required = ").append(required).append(" ").toString());
		b.append((new StringBuilder()).append("fragment = ").append(fragment).append(" ").toString());
		b.append((new StringBuilder()).append("deferredValue = ").append(deferredValue).append(" ").toString());
		b.append((new StringBuilder()).append("deferredMethod = ").append(deferredMethod).append(" ").toString());
		b.append((new StringBuilder()).append("expectedTypeName = ").append(expectedTypeName).append(" ").toString());
		b.append((new StringBuilder()).append("methodSignature = ").append(methodSignature).append(" ").toString());
		return b.toString();
	}
}
