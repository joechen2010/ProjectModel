// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   TagData.java

package javax.servlet.jsp.tagext;

import java.util.Enumeration;
import java.util.Hashtable;

public class TagData
	implements Cloneable {

	public static final Object REQUEST_TIME_VALUE = new Object();
	private Hashtable attributes;

	public TagData(Object atts[][]) {
		if (atts == null) {
			attributes = new Hashtable();
		} else {
			attributes = new Hashtable(atts.length);
		}
		if (atts != null) {
			for (int i = 0; i < atts.length; i++) {
				attributes.put((String)atts[i][0], atts[i][1]);
			}

		}
	}

	public TagData(Hashtable attrs) {
		attributes = attrs;
	}

	public String getId() {
		return getAttributeString("id");
	}

	public Object getAttribute(String attName) {
		return attributes.get(attName);
	}

	public void setAttribute(String attName, Object value) {
		attributes.put(attName, value);
	}

	public String getAttributeString(String attName) {
		Object o = attributes.get(attName);
		if (o == null) {
			return null;
		} else {
			return (String)o;
		}
	}

	public Enumeration getAttributes() {
		return attributes.keys();
	}

}
