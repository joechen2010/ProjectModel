// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   TagSupport.java

package javax.servlet.jsp.tagext;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;

// Referenced classes of package javax.servlet.jsp.tagext:
//			IterationTag, Tag

public class TagSupport
	implements IterationTag, Serializable {

	private Tag parent;
	private Hashtable values;
	protected String id;
	protected PageContext pageContext;

	public static final Tag findAncestorWithClass(Tag from, Class klass) {
		boolean isInterface = false;
		if (from == null || klass == null || !javax/servlet/jsp/tagext/Tag.isAssignableFrom(klass) && !(isInterface = klass.isInterface())) {
			return null;
		}
		do {
			Tag tag = from.getParent();
			if (tag == null) {
				return null;
			}
			if (isInterface && klass.isInstance(tag) || klass.isAssignableFrom(tag.getClass())) {
				return tag;
			}
			from = tag;
		} while (true);
	}

	public TagSupport() {
	}

	public int doStartTag() throws JspException {
		return 0;
	}

	public int doEndTag() throws JspException {
		return 6;
	}

	public int doAfterBody() throws JspException {
		return 0;
	}

	public void release() {
		parent = null;
		id = null;
		if (values != null) {
			values.clear();
		}
		values = null;
	}

	public void setParent(Tag t) {
		parent = t;
	}

	public Tag getParent() {
		return parent;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}

	public void setPageContext(PageContext pageContext) {
		this.pageContext = pageContext;
	}

	public void setValue(String k, Object o) {
		if (values == null) {
			values = new Hashtable();
		}
		values.put(k, o);
	}

	public Object getValue(String k) {
		if (values == null) {
			return null;
		} else {
			return values.get(k);
		}
	}

	public void removeValue(String k) {
		if (values != null) {
			values.remove(k);
		}
	}

	public Enumeration getValues() {
		if (values == null) {
			return null;
		} else {
			return values.keys();
		}
	}
}
