// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   BodyTag.java

package javax.servlet.jsp.tagext;

import javax.servlet.jsp.JspException;

// Referenced classes of package javax.servlet.jsp.tagext:
//			IterationTag, BodyContent

public interface BodyTag
	extends IterationTag {

	/**
	 * @deprecated Field EVAL_BODY_TAG is deprecated
	 */
	public static final int EVAL_BODY_TAG = 2;
	public static final int EVAL_BODY_BUFFERED = 2;

	public abstract void setBodyContent(BodyContent bodycontent);

	public abstract void doInitBody() throws JspException;
}
