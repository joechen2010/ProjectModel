// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   JspException.java

package javax.servlet.jsp;


public class JspException extends Exception {

	public JspException() {
	}

	public JspException(String msg) {
		super(msg);
	}

	public JspException(String message, Throwable cause) {
		super(message, cause);
	}

	public JspException(Throwable cause) {
		super(cause);
	}

	/**
	 * @deprecated Method getRootCause is deprecated
	 */

	public Throwable getRootCause() {
		return getCause();
	}
}
