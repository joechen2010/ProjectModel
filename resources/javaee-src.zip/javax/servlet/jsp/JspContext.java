// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   JspContext.java

package javax.servlet.jsp;

import java.io.Writer;
import java.util.Enumeration;
import javax.el.ELContext;
import javax.servlet.jsp.el.ExpressionEvaluator;
import javax.servlet.jsp.el.VariableResolver;

// Referenced classes of package javax.servlet.jsp:
//			JspWriter

public abstract class JspContext {

	public JspContext() {
	}

	public abstract void setAttribute(String s, Object obj);

	public abstract void setAttribute(String s, Object obj, int i);

	public abstract Object getAttribute(String s);

	public abstract Object getAttribute(String s, int i);

	public abstract Object findAttribute(String s);

	public abstract void removeAttribute(String s);

	public abstract void removeAttribute(String s, int i);

	public abstract int getAttributesScope(String s);

	public abstract Enumeration getAttributeNamesInScope(int i);

	public abstract JspWriter getOut();

	/**
	 * @deprecated Method getExpressionEvaluator is deprecated
	 */

	public abstract ExpressionEvaluator getExpressionEvaluator();

	/**
	 * @deprecated Method getVariableResolver is deprecated
	 */

	public abstract VariableResolver getVariableResolver();

	public abstract ELContext getELContext();

	public JspWriter pushBody(Writer writer) {
		return null;
	}

	public JspWriter popBody() {
		return null;
	}
}
