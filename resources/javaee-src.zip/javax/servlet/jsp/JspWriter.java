// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   JspWriter.java

package javax.servlet.jsp;

import java.io.IOException;
import java.io.Writer;

public abstract class JspWriter extends Writer {

	public static final int NO_BUFFER = 0;
	public static final int DEFAULT_BUFFER = -1;
	public static final int UNBOUNDED_BUFFER = -2;
	protected int bufferSize;
	protected boolean autoFlush;

	protected JspWriter(int bufferSize, boolean autoFlush) {
		this.bufferSize = bufferSize;
		this.autoFlush = autoFlush;
	}

	public abstract void newLine() throws IOException;

	public abstract void print(boolean flag) throws IOException;

	public abstract void print(char c) throws IOException;

	public abstract void print(int i) throws IOException;

	public abstract void print(long l) throws IOException;

	public abstract void print(float f) throws IOException;

	public abstract void print(double d) throws IOException;

	public abstract void print(char ac[]) throws IOException;

	public abstract void print(String s) throws IOException;

	public abstract void print(Object obj) throws IOException;

	public abstract void println() throws IOException;

	public abstract void println(boolean flag) throws IOException;

	public abstract void println(char c) throws IOException;

	public abstract void println(int i) throws IOException;

	public abstract void println(long l) throws IOException;

	public abstract void println(float f) throws IOException;

	public abstract void println(double d) throws IOException;

	public abstract void println(char ac[]) throws IOException;

	public abstract void println(String s) throws IOException;

	public abstract void println(Object obj) throws IOException;

	public abstract void clear() throws IOException;

	public abstract void clearBuffer() throws IOException;

	public abstract void flush() throws IOException;

	public abstract void close() throws IOException;

	public int getBufferSize() {
		return bufferSize;
	}

	public abstract int getRemaining();

	public boolean isAutoFlush() {
		return autoFlush;
	}
}
