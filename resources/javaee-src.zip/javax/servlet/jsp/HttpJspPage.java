// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   HttpJspPage.java

package javax.servlet.jsp;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// Referenced classes of package javax.servlet.jsp:
//			JspPage

public interface HttpJspPage
	extends JspPage {

	public abstract void _jspService(HttpServletRequest httpservletrequest, HttpServletResponse httpservletresponse) throws ServletException, IOException;
}
