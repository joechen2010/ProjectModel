// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   JspPage.java

package javax.servlet.jsp;

import javax.servlet.Servlet;

public interface JspPage
	extends Servlet {

	public abstract void jspInit();

	public abstract void jspDestroy();
}
