// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ErrorData.java

package javax.servlet.jsp;


public final class ErrorData {

	private Throwable throwable;
	private int statusCode;
	private String uri;
	private String servletName;

	public ErrorData(Throwable throwable, int statusCode, String uri, String servletName) {
		this.throwable = throwable;
		this.statusCode = statusCode;
		this.uri = uri;
		this.servletName = servletName;
	}

	public Throwable getThrowable() {
		return throwable;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public String getRequestURI() {
		return uri;
	}

	public String getServletName() {
		return servletName;
	}
}
