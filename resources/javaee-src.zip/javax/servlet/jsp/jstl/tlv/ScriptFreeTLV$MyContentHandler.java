// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ScriptFreeTLV.java

package javax.servlet.jsp.jstl.tlv;

import javax.servlet.jsp.tagext.ValidationMessage;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

// Referenced classes of package javax.servlet.jsp.jstl.tlv:
//			ScriptFreeTLV

private class ScriptFreeTLV$MyContentHandler extends DefaultHandler {

	private int declarationCount;
	private int scriptletCount;
	private int expressionCount;
	private int rtExpressionCount;
	final ScriptFreeTLV this$0;

	public void startElement(String namespaceUri, String localName, String qualifiedName, Attributes atts) {
		if (!ScriptFreeTLV.access$100(ScriptFreeTLV.this) && qualifiedName.equals("jsp:declaration")) {
			declarationCount++;
		} else
		if (!ScriptFreeTLV.access$200(ScriptFreeTLV.this) && qualifiedName.equals("jsp:scriptlet")) {
			scriptletCount++;
		} else
		if (!ScriptFreeTLV.access$300(ScriptFreeTLV.this) && qualifiedName.equals("jsp:expression")) {
			expressionCount++;
		}
		if (!ScriptFreeTLV.access$400(ScriptFreeTLV.this)) {
			countRTExpressions(atts);
		}
	}

	private void countRTExpressions(Attributes atts) {
		int stop = atts.getLength();
		for (int i = 0; i < stop; i++) {
			String attval = atts.getValue(i);
			if (attval.startsWith("%=") && attval.endsWith("%")) {
				rtExpressionCount++;
			}
		}

	}

	public ValidationMessage[] reportResults() {
		if (declarationCount + scriptletCount + expressionCount + rtExpressionCount > 0) {
			StringBuffer results = new StringBuffer("JSP page contains ");
			boolean first = true;
			if (declarationCount > 0) {
				results.append(Integer.toString(declarationCount));
				results.append(" declaration");
				if (declarationCount > 1) {
					results.append('s');
				}
				first = false;
			}
			if (scriptletCount > 0) {
				if (!first) {
					results.append(", ");
				}
				results.append(Integer.toString(scriptletCount));
				results.append(" scriptlet");
				if (scriptletCount > 1) {
					results.append('s');
				}
				first = false;
			}
			if (expressionCount > 0) {
				if (!first) {
					results.append(", ");
				}
				results.append(Integer.toString(expressionCount));
				results.append(" expression");
				if (expressionCount > 1) {
					results.append('s');
				}
				first = false;
			}
			if (rtExpressionCount > 0) {
				if (!first) {
					results.append(", ");
				}
				results.append(Integer.toString(rtExpressionCount));
				results.append(" request-time attribute value");
				if (rtExpressionCount > 1) {
					results.append('s');
				}
				first = false;
			}
			results.append(".");
			return ScriptFreeTLV.access$500(results.toString());
		} else {
			return null;
		}
	}

	private ScriptFreeTLV$MyContentHandler() {
		this$0 = ScriptFreeTLV.this;
		super();
		declarationCount = 0;
		scriptletCount = 0;
		expressionCount = 0;
		rtExpressionCount = 0;
	}

	ScriptFreeTLV$MyContentHandler(ScriptFreeTLV$1 x1) {
		this();
	}
}
