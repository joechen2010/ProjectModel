// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   PermittedTaglibsTLV.java

package javax.servlet.jsp.jstl.tlv;

import java.io.IOException;
import java.util.*;
import javax.servlet.jsp.tagext.*;
import javax.xml.parsers.*;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class PermittedTaglibsTLV extends TagLibraryValidator {
	private class PermittedTaglibsHandler extends DefaultHandler {

		final PermittedTaglibsTLV this$0;

		public void startElement(String ns, String ln, String qn, Attributes a) {
			if (!qn.equals("jsp:root") && (!ns.equals("http://java.sun.com/JSP/Page") || !ln.equals("root"))) {
				return;
			}
			for (int i = 0; i < a.getLength(); i++) {
				String name = a.getQName(i);
				if (!name.startsWith("xmlns:") || name.equals("xmlns:jsp")) {
					continue;
				}
				String value = a.getValue(i);
				if (!value.equals(uri) && !permittedTaglibs.contains(value)) {
					failed = true;
				}
			}

		}

		private PermittedTaglibsHandler() {
			this$0 = PermittedTaglibsTLV.this;
			super();
		}

	}


	private final String PERMITTED_TAGLIBS_PARAM = "permittedTaglibs";
	private final String JSP_ROOT_URI = "http://java.sun.com/JSP/Page";
	private final String JSP_ROOT_NAME = "root";
	private final String JSP_ROOT_QN = "jsp:root";
	private Set permittedTaglibs;
	private boolean failed;
	private String uri;

	public PermittedTaglibsTLV() {
		init();
	}

	private void init() {
		permittedTaglibs = null;
		failed = false;
	}

	public void release() {
		super.release();
		init();
	}

	public synchronized ValidationMessage[] validate(String prefix, String uri, PageData page) {
		this.uri = uri;
		permittedTaglibs = readConfiguration();
		DefaultHandler h = new PermittedTaglibsHandler();
		SAXParserFactory f = SAXParserFactory.newInstance();
		f.setValidating(true);
		SAXParser p = f.newSAXParser();
		p.parse(page.getInputStream(), h);
		if (failed) {
			return vmFromString((new StringBuilder()).append("taglib ").append(prefix).append(" (").append(uri).append(") allows only the ").append("following taglibs to be imported: ").append(permittedTaglibs).toString());
		}
		return null;
		SAXException ex;
		ex;
		return vmFromString(ex.toString());
		ex;
		return vmFromString(ex.toString());
		ex;
		return vmFromString(ex.toString());
	}

	private Set readConfiguration() {
		Set s = new HashSet();
		String uris = (String)getInitParameters().get("permittedTaglibs");
		for (StringTokenizer st = new StringTokenizer(uris); st.hasMoreTokens(); s.add(st.nextToken())) { }
		return s;
	}

	private ValidationMessage[] vmFromString(String message) {
		return (new ValidationMessage[] {
			new ValidationMessage(null, message)
		});
	}



}
