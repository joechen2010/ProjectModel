// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   PermittedTaglibsTLV.java

package javax.servlet.jsp.jstl.tlv;

import java.util.Set;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

// Referenced classes of package javax.servlet.jsp.jstl.tlv:
//			PermittedTaglibsTLV

private class PermittedTaglibsTLV$PermittedTaglibsHandler extends DefaultHandler {

	final PermittedTaglibsTLV this$0;

	public void startElement(String ns, String ln, String qn, Attributes a) {
		if (!qn.equals("jsp:root") && (!ns.equals("http://java.sun.com/JSP/Page") || !ln.equals("root"))) {
			return;
		}
		for (int i = 0; i < a.getLength(); i++) {
			String name = a.getQName(i);
			if (!name.startsWith("xmlns:") || name.equals("xmlns:jsp")) {
				continue;
			}
			String value = a.getValue(i);
			if (!value.equals(PermittedTaglibsTLV.access$100(PermittedTaglibsTLV.this)) && !PermittedTaglibsTLV.access$200(PermittedTaglibsTLV.this).contains(value)) {
				PermittedTaglibsTLV.access$302(PermittedTaglibsTLV.this, true);
			}
		}

	}

	private PermittedTaglibsTLV$PermittedTaglibsHandler() {
		this$0 = PermittedTaglibsTLV.this;
		super();
	}

	PermittedTaglibsTLV$PermittedTaglibsHandler(PermittedTaglibsTLV$1 x1) {
		this();
	}
}
