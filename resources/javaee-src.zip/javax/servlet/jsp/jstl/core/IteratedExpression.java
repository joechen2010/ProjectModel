// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   IteratedExpression.java

package javax.servlet.jsp.jstl.core;

import java.util.*;
import javax.el.*;
import org.apache.taglibs.standard.resources.Resources;

public final class IteratedExpression {

	private static final long serialVersionUID = 1L;
	protected final ValueExpression orig;
	protected final String delims;
	private Object base;
	private int index;
	private Iterator iter;

	public IteratedExpression(ValueExpression orig, String delims) {
		this.orig = orig;
		this.delims = delims;
	}

	public Object getItem(ELContext context, int i) {
		if (base == null) {
			base = orig.getValue(context);
			if (base == null) {
				return null;
			}
			iter = toIterator(base);
			index = 0;
		}
		if (index > i) {
			iter = toIterator(base);
			index = 0;
		}
		while (iter.hasNext())  {
			Object item = iter.next();
			if (index++ == i) {
				return item;
			}
		}
		return null;
	}

	public ValueExpression getValueExpression() {
		return orig;
	}

	private Iterator toIterator(Object obj) {
		Iterator iter;
		if (obj instanceof String) {
			iter = toIterator(((Enumeration) (new StringTokenizer((String)obj, delims))));
		} else
		if (obj instanceof Iterator) {
			iter = (Iterator)obj;
		} else
		if (obj instanceof Collection) {
			iter = toIterator(((Collection)obj).iterator());
		} else
		if (obj instanceof Enumeration) {
			iter = toIterator((Enumeration)obj);
		} else
		if (obj instanceof Map) {
			iter = ((Map)obj).entrySet().iterator();
		} else {
			throw new ELException(Resources.getMessage("FOREACH_BAD_ITEMS"));
		}
		return iter;
	}

	private Iterator toIterator(final Enumeration obj) {
		return new Iterator() {

			final Enumeration val$obj;
			final IteratedExpression this$0;

			public boolean hasNext() {
				return obj.hasMoreElements();
			}

			public Object next() {
				return obj.nextElement();
			}

			public void remove() {
			}

			 {
				this$0 = IteratedExpression.this;
				obj = enumeration;
				super();
			}
		};
	}
}
