// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   LoopTagSupport.java

package javax.servlet.jsp.jstl.core;

import java.util.*;
import javax.el.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import org.apache.taglibs.standard.resources.Resources;

// Referenced classes of package javax.servlet.jsp.jstl.core:
//			IndexedValueExpression, IteratedExpression, IteratedValueExpression, LoopTag, 
//			LoopTagStatus

public abstract class LoopTagSupport extends TagSupport
	implements LoopTag, IterationTag, TryCatchFinally {

	protected int begin;
	protected int end;
	protected int step;
	protected boolean beginSpecified;
	protected boolean endSpecified;
	protected boolean stepSpecified;
	protected String itemId;
	protected String statusId;
	protected ValueExpression deferredExpression;
	private LoopTagStatus status;
	private Object item;
	private int index;
	private int count;
	private boolean last;
	private IteratedExpression iteratedExpression;

	public LoopTagSupport() {
		init();
	}

	protected abstract Object next() throws JspTagException;

	protected abstract boolean hasNext() throws JspTagException;

	protected abstract void prepare() throws JspTagException;

	public void release() {
		super.release();
		init();
	}

	public int doStartTag() throws JspException {
		if (end != -1 && begin > end) {
			return 0;
		}
		index = 0;
		count = 1;
		last = false;
		iteratedExpression = null;
		deferredExpression = null;
		prepare();
		discardIgnoreSubset(begin);
		if (hasNext()) {
			item = next();
		} else {
			return 0;
		}
		discard(step - 1);
		exposeVariables();
		calibrateLast();
		return 1;
	}

	public int doAfterBody() throws JspException {
		index += step - 1;
		count++;
		if (hasNext() && !atEnd()) {
			index++;
			item = next();
		} else {
			return 0;
		}
		discard(step - 1);
		exposeVariables();
		calibrateLast();
		return 2;
	}

	public void doFinally() {
		unExposeVariables();
	}

	public void doCatch(Throwable t) throws Throwable {
		throw t;
	}

	public Object getCurrent() {
		return item;
	}

	public LoopTagStatus getLoopStatus() {
		class _cls1Status
			implements LoopTagStatus {

			final LoopTagSupport this$0;

			public Object getCurrent() {
				return LoopTagSupport.this.getCurrent();
			}

			public int getIndex() {
				return index + begin;
			}

			public int getCount() {
				return count;
			}

			public boolean isFirst() {
				return index == 0;
			}

			public boolean isLast() {
				return last;
			}

			public Integer getBegin() {
				if (beginSpecified) {
					return new Integer(begin);
				} else {
					return null;
				}
			}

			public Integer getEnd() {
				if (endSpecified) {
					return new Integer(end);
				} else {
					return null;
				}
			}

			public Integer getStep() {
				if (stepSpecified) {
					return new Integer(step);
				} else {
					return null;
				}
			}

			_cls1Status() {
				this$0 = LoopTagSupport.this;
				super();
			}
		}

		if (status == null) {
			status = new _cls1Status();
		}
		return status;
	}

	protected String getDelims() {
		return ",";
	}

	public void setVar(String id) {
		itemId = id;
	}

	public void setVarStatus(String statusId) {
		this.statusId = statusId;
	}

	protected void validateBegin() throws JspTagException {
		if (begin < 0) {
			throw new JspTagException("'begin' < 0");
		} else {
			return;
		}
	}

	protected void validateEnd() throws JspTagException {
		if (end < 0) {
			throw new JspTagException("'end' < 0");
		} else {
			return;
		}
	}

	protected void validateStep() throws JspTagException {
		if (step < 1) {
			throw new JspTagException("'step' <= 0");
		} else {
			return;
		}
	}

	private void init() {
		index = 0;
		count = 1;
		status = null;
		item = null;
		last = false;
		beginSpecified = false;
		endSpecified = false;
		stepSpecified = false;
		begin = 0;
		end = -1;
		step = 1;
		itemId = null;
		statusId = null;
	}

	private void calibrateLast() throws JspTagException {
		last = !hasNext() || atEnd() || end != -1 && begin + index + step > end;
	}

	private void exposeVariables() throws JspTagException {
		if (itemId != null) {
			if (getCurrent() == null) {
				pageContext.removeAttribute(itemId, 1);
			} else
			if (deferredExpression != null) {
				VariableMapper vm = pageContext.getELContext().getVariableMapper();
				if (vm != null) {
					ValueExpression ve = getVarExpression(deferredExpression);
					vm.setVariable(itemId, ve);
				}
			} else {
				pageContext.setAttribute(itemId, getCurrent());
			}
		}
		if (statusId != null) {
			if (getLoopStatus() == null) {
				pageContext.removeAttribute(statusId, 1);
			} else {
				pageContext.setAttribute(statusId, getLoopStatus());
			}
		}
	}

	private void unExposeVariables() {
		if (itemId != null) {
			pageContext.removeAttribute(itemId, 1);
			VariableMapper vm = pageContext.getELContext().getVariableMapper();
			if (vm != null) {
				vm.setVariable(itemId, null);
			}
		}
		if (statusId != null) {
			pageContext.removeAttribute(statusId, 1);
		}
	}

	private void discard(int n) throws JspTagException {
		int oldIndex = index;
		for (; n-- > 0 && !atEnd() && hasNext(); next()) {
			index++;
		}

		index = oldIndex;
	}

	private void discardIgnoreSubset(int n) throws JspTagException {
		for (; n-- > 0 && hasNext(); next()) { }
	}

	private boolean atEnd() {
		return end != -1 && begin + index >= end;
	}

	private ValueExpression getVarExpression(ValueExpression expr) {
		Object o = expr.getValue(pageContext.getELContext());
		if (o.getClass().isArray() || (o instanceof List)) {
			return new IndexedValueExpression(deferredExpression, index);
		}
		if ((o instanceof Collection) || (o instanceof Iterator) || (o instanceof Enumeration) || (o instanceof Map) || (o instanceof String)) {
			if (iteratedExpression == null) {
				iteratedExpression = new IteratedExpression(deferredExpression, getDelims());
			}
			return new IteratedValueExpression(iteratedExpression, index);
		} else {
			throw new ELException(Resources.getMessage("FOREACH_BAD_ITEMS"));
		}
	}



}
