// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ConditionalTagSupport.java

package javax.servlet.jsp.jstl.core;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.TagSupport;

public abstract class ConditionalTagSupport extends TagSupport {

	private boolean result;
	private String var;
	private int scope;

	protected abstract boolean condition() throws JspTagException;

	public ConditionalTagSupport() {
		init();
	}

	public int doStartTag() throws JspException {
		result = condition();
		exposeVariables();
		return !result ? 0 : 1;
	}

	public void release() {
		super.release();
		init();
	}

	public void setVar(String var) {
		this.var = var;
	}

	public void setScope(String scope) {
		if (scope.equalsIgnoreCase("page")) {
			this.scope = 1;
		} else
		if (scope.equalsIgnoreCase("request")) {
			this.scope = 2;
		} else
		if (scope.equalsIgnoreCase("session")) {
			this.scope = 3;
		} else
		if (scope.equalsIgnoreCase("application")) {
			this.scope = 4;
		}
	}

	private void exposeVariables() {
		if (var != null) {
			pageContext.setAttribute(var, new Boolean(result), scope);
		}
	}

	private void init() {
		result = false;
		var = null;
		scope = 1;
	}
}
