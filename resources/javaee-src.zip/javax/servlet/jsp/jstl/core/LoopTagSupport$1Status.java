// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   LoopTagSupport.java

package javax.servlet.jsp.jstl.core;


// Referenced classes of package javax.servlet.jsp.jstl.core:
//			LoopTagStatus, LoopTagSupport

class LoopTagSupport$1Status
	implements LoopTagStatus {

	final LoopTagSupport this$0;

	public Object getCurrent() {
		return LoopTagSupport.this.getCurrent();
	}

	public int getIndex() {
		return LoopTagSupport.access$000(LoopTagSupport.this) + begin;
	}

	public int getCount() {
		return LoopTagSupport.access$100(LoopTagSupport.this);
	}

	public boolean isFirst() {
		return LoopTagSupport.access$000(LoopTagSupport.this) == 0;
	}

	public boolean isLast() {
		return LoopTagSupport.access$200(LoopTagSupport.this);
	}

	public Integer getBegin() {
		if (beginSpecified) {
			return new Integer(begin);
		} else {
			return null;
		}
	}

	public Integer getEnd() {
		if (endSpecified) {
			return new Integer(end);
		} else {
			return null;
		}
	}

	public Integer getStep() {
		if (stepSpecified) {
			return new Integer(step);
		} else {
			return null;
		}
	}

	LoopTagSupport$1Status() {
		this$0 = LoopTagSupport.this;
		super();
	}
}
