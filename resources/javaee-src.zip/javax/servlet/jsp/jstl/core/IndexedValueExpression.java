// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   IndexedValueExpression.java

package javax.servlet.jsp.jstl.core;

import javax.el.*;

public final class IndexedValueExpression extends ValueExpression {

	private static final long serialVersionUID = 1L;
	protected final Integer i;
	protected final ValueExpression orig;

	public IndexedValueExpression(ValueExpression orig, int i) {
		this.i = new Integer(i);
		this.orig = orig;
	}

	public Object getValue(ELContext context) {
		Object base = orig.getValue(context);
		if (base != null) {
			context.setPropertyResolved(false);
			return context.getELResolver().getValue(context, base, i);
		} else {
			return null;
		}
	}

	public void setValue(ELContext context, Object value) {
		Object base = orig.getValue(context);
		if (base != null) {
			context.setPropertyResolved(false);
			context.getELResolver().setValue(context, base, i, value);
		}
	}

	public boolean isReadOnly(ELContext context) {
		Object base = orig.getValue(context);
		if (base != null) {
			context.setPropertyResolved(false);
			return context.getELResolver().isReadOnly(context, base, i);
		} else {
			return true;
		}
	}

	public Class getType(ELContext context) {
		Object base = orig.getValue(context);
		if (base != null) {
			context.setPropertyResolved(false);
			return context.getELResolver().getType(context, base, i);
		} else {
			return null;
		}
	}

	public Class getExpectedType() {
		return java/lang/Object;
	}

	public String getExpressionString() {
		return orig.getExpressionString();
	}

	public boolean equals(Object obj) {
		return orig.equals(obj);
	}

	public int hashCode() {
		return orig.hashCode();
	}

	public boolean isLiteralText() {
		return false;
	}
}
