// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   IteratedExpression.java

package javax.servlet.jsp.jstl.core;

import java.util.Enumeration;
import java.util.Iterator;

// Referenced classes of package javax.servlet.jsp.jstl.core:
//			IteratedExpression

class IteratedExpression$1
	implements Iterator {

	final Enumeration val$obj;
	final IteratedExpression this$0;

	public boolean hasNext() {
		return val$obj.hasMoreElements();
	}

	public Object next() {
		return val$obj.nextElement();
	}

	public void remove() {
	}

	IteratedExpression$1() {
		this$0 = final_iteratedexpression;
		val$obj = Enumeration.this;
		super();
	}
}
