// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   Config.java

package javax.servlet.jsp.jstl.core;

import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.PageContext;

public class Config {

	public static final String FMT_LOCALE = "javax.servlet.jsp.jstl.fmt.locale";
	public static final String FMT_FALLBACK_LOCALE = "javax.servlet.jsp.jstl.fmt.fallbackLocale";
	public static final String FMT_LOCALIZATION_CONTEXT = "javax.servlet.jsp.jstl.fmt.localizationContext";
	public static final String FMT_TIME_ZONE = "javax.servlet.jsp.jstl.fmt.timeZone";
	public static final String SQL_DATA_SOURCE = "javax.servlet.jsp.jstl.sql.dataSource";
	public static final String SQL_MAX_ROWS = "javax.servlet.jsp.jstl.sql.maxRows";
	private static final String PAGE_SCOPE_SUFFIX = ".page";
	private static final String REQUEST_SCOPE_SUFFIX = ".request";
	private static final String SESSION_SCOPE_SUFFIX = ".session";
	private static final String APPLICATION_SCOPE_SUFFIX = ".application";

	public Config() {
	}

	public static Object get(PageContext pc, String name, int scope) {
		switch (scope) {
		case 1: // '\001'
			return pc.getAttribute((new StringBuilder()).append(name).append(".page").toString(), scope);

		case 2: // '\002'
			return pc.getAttribute((new StringBuilder()).append(name).append(".request").toString(), scope);

		case 3: // '\003'
			return get(pc.getSession(), name);

		case 4: // '\004'
			return pc.getAttribute((new StringBuilder()).append(name).append(".application").toString(), scope);
		}
		throw new IllegalArgumentException("unknown scope");
	}

	public static Object get(ServletRequest request, String name) {
		return request.getAttribute((new StringBuilder()).append(name).append(".request").toString());
	}

	public static Object get(HttpSession session, String name) {
		Object ret = null;
		if (session != null) {
			try {
				ret = session.getAttribute((new StringBuilder()).append(name).append(".session").toString());
			}
			catch (IllegalStateException ex) { }
		}
		return ret;
	}

	public static Object get(ServletContext context, String name) {
		return context.getAttribute((new StringBuilder()).append(name).append(".application").toString());
	}

	public static void set(PageContext pc, String name, Object value, int scope) {
		switch (scope) {
		case 1: // '\001'
			pc.setAttribute((new StringBuilder()).append(name).append(".page").toString(), value, scope);
			break;

		case 2: // '\002'
			pc.setAttribute((new StringBuilder()).append(name).append(".request").toString(), value, scope);
			break;

		case 3: // '\003'
			pc.setAttribute((new StringBuilder()).append(name).append(".session").toString(), value, scope);
			break;

		case 4: // '\004'
			pc.setAttribute((new StringBuilder()).append(name).append(".application").toString(), value, scope);
			break;

		default:
			throw new IllegalArgumentException("unknown scope");
		}
	}

	public static void set(ServletRequest request, String name, Object value) {
		request.setAttribute((new StringBuilder()).append(name).append(".request").toString(), value);
	}

	public static void set(HttpSession session, String name, Object value) {
		session.setAttribute((new StringBuilder()).append(name).append(".session").toString(), value);
	}

	public static void set(ServletContext context, String name, Object value) {
		context.setAttribute((new StringBuilder()).append(name).append(".application").toString(), value);
	}

	public static void remove(PageContext pc, String name, int scope) {
		switch (scope) {
		case 1: // '\001'
			pc.removeAttribute((new StringBuilder()).append(name).append(".page").toString(), scope);
			break;

		case 2: // '\002'
			pc.removeAttribute((new StringBuilder()).append(name).append(".request").toString(), scope);
			break;

		case 3: // '\003'
			pc.removeAttribute((new StringBuilder()).append(name).append(".session").toString(), scope);
			break;

		case 4: // '\004'
			pc.removeAttribute((new StringBuilder()).append(name).append(".application").toString(), scope);
			break;

		default:
			throw new IllegalArgumentException("unknown scope");
		}
	}

	public static void remove(ServletRequest request, String name) {
		request.removeAttribute((new StringBuilder()).append(name).append(".request").toString());
	}

	public static void remove(HttpSession session, String name) {
		session.removeAttribute((new StringBuilder()).append(name).append(".session").toString());
	}

	public static void remove(ServletContext context, String name) {
		context.removeAttribute((new StringBuilder()).append(name).append(".application").toString());
	}

	public static Object find(PageContext pc, String name) {
		Object ret = get(pc, name, 1);
		if (ret == null) {
			ret = get(pc, name, 2);
			if (ret == null) {
				if (pc.getSession() != null) {
					ret = get(pc, name, 3);
				}
				if (ret == null) {
					ret = get(pc, name, 4);
					if (ret == null) {
						ret = pc.getServletContext().getInitParameter(name);
					}
				}
			}
		}
		return ret;
	}
}
