// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   IteratedValueExpression.java

package javax.servlet.jsp.jstl.core;

import javax.el.ELContext;
import javax.el.ValueExpression;

// Referenced classes of package javax.servlet.jsp.jstl.core:
//			IteratedExpression

public final class IteratedValueExpression extends ValueExpression {

	private static final long serialVersionUID = 1L;
	protected final int i;
	protected final IteratedExpression iteratedExpression;

	public IteratedValueExpression(IteratedExpression iteratedExpr, int i) {
		this.i = i;
		iteratedExpression = iteratedExpr;
	}

	public Object getValue(ELContext context) {
		return iteratedExpression.getItem(context, i);
	}

	public void setValue(ELContext elcontext, Object obj) {
	}

	public boolean isReadOnly(ELContext context) {
		return true;
	}

	public Class getType(ELContext context) {
		return null;
	}

	public Class getExpectedType() {
		return java/lang/Object;
	}

	public String getExpressionString() {
		return iteratedExpression.getValueExpression().getExpressionString();
	}

	public boolean equals(Object obj) {
		return iteratedExpression.getValueExpression().equals(obj);
	}

	public int hashCode() {
		return iteratedExpression.getValueExpression().hashCode();
	}

	public boolean isLiteralText() {
		return false;
	}
}
