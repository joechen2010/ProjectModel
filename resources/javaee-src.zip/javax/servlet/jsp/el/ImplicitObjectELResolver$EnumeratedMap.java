// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ImplicitObjectELResolver.java

package javax.servlet.jsp.el;

import java.util.*;

// Referenced classes of package javax.servlet.jsp.el:
//			ImplicitObjectELResolver

private static abstract class ImplicitObjectELResolver$EnumeratedMap
	implements Map {

	Map mMap;

	public void clear() {
		throw new UnsupportedOperationException();
	}

	public boolean containsKey(Object pKey) {
		return getValue(pKey) != null;
	}

	public boolean containsValue(Object pValue) {
		return getAsMap().containsValue(pValue);
	}

	public Set entrySet() {
		return getAsMap().entrySet();
	}

	public Object get(Object pKey) {
		return getValue(pKey);
	}

	public boolean isEmpty() {
		return !enumerateKeys().hasMoreElements();
	}

	public Set keySet() {
		return getAsMap().keySet();
	}

	public Object put(Object pKey, Object pValue) {
		throw new UnsupportedOperationException();
	}

	public void putAll(Map pMap) {
		throw new UnsupportedOperationException();
	}

	public Object remove(Object pKey) {
		throw new UnsupportedOperationException();
	}

	public int size() {
		return getAsMap().size();
	}

	public Collection values() {
		return getAsMap().values();
	}

	public abstract Enumeration enumerateKeys();

	public abstract boolean isMutable();

	public abstract Object getValue(Object obj);

	public Map getAsMap() {
		if (mMap != null) {
			return mMap;
		}
		Map m = convertToMap();
		if (!isMutable()) {
			mMap = m;
		}
		return m;
	}

	Map convertToMap() {
		Map ret = new HashMap();
		Object key;
		Object value;
		for (Enumeration e = enumerateKeys(); e.hasMoreElements(); ret.put(key, value)) {
			key = e.nextElement();
			value = getValue(key);
		}

		return ret;
	}

	private ImplicitObjectELResolver$EnumeratedMap() {
	}

	ImplicitObjectELResolver$EnumeratedMap(ImplicitObjectELResolver$1 x0) {
		this();
	}
}
