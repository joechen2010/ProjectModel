// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ScopedAttributeELResolver.java

package javax.servlet.jsp.el;

import java.beans.FeatureDescriptor;
import java.util.*;
import javax.el.ELContext;
import javax.el.ELResolver;
import javax.servlet.jsp.JspContext;
import javax.servlet.jsp.PageContext;

public class ScopedAttributeELResolver extends ELResolver {

	public ScopedAttributeELResolver() {
	}

	public Object getValue(ELContext context, Object base, Object property) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base == null) {
			context.setPropertyResolved(true);
			if (property instanceof String) {
				String attribute = (String)property;
				PageContext ctxt = (PageContext)context.getContext(javax/servlet/jsp/JspContext);
				return ctxt.findAttribute(attribute);
			}
		}
		return null;
	}

	public Class getType(ELContext context, Object base, Object property) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base == null) {
			context.setPropertyResolved(true);
			return java/lang/Object;
		} else {
			return null;
		}
	}

	public void setValue(ELContext context, Object base, Object property, Object val) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base == null) {
			context.setPropertyResolved(true);
			if (property instanceof String) {
				PageContext ctxt = (PageContext)context.getContext(javax/servlet/jsp/JspContext);
				String attr = (String)property;
				if (ctxt.getAttribute(attr, 2) != null) {
					ctxt.setAttribute(attr, val, 2);
				} else
				if (ctxt.getAttribute(attr, 3) != null) {
					ctxt.setAttribute(attr, val, 3);
				} else
				if (ctxt.getAttribute(attr, 4) != null) {
					ctxt.setAttribute(attr, val, 4);
				} else {
					ctxt.setAttribute(attr, val, 1);
				}
			}
		}
	}

	public boolean isReadOnly(ELContext context, Object base, Object property) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base == null) {
			context.setPropertyResolved(true);
		}
		return false;
	}

	public Iterator getFeatureDescriptors(ELContext context, Object base) {
		ArrayList list = new ArrayList();
		PageContext ctxt = (PageContext)context.getContext(javax/servlet/jsp/JspContext);
		FeatureDescriptor descriptor;
		for (Enumeration attrs = ctxt.getAttributeNamesInScope(1); attrs.hasMoreElements(); list.add(descriptor)) {
			String name = (String)attrs.nextElement();
			Object value = ctxt.getAttribute(name, 1);
			descriptor = new FeatureDescriptor();
			descriptor.setName(name);
			descriptor.setDisplayName(name);
			descriptor.setShortDescription("page scope attribute");
			descriptor.setExpert(false);
			descriptor.setHidden(false);
			descriptor.setPreferred(true);
			descriptor.setValue("type", value.getClass());
			descriptor.setValue("resolvableAtDesignTime", Boolean.TRUE);
		}

		FeatureDescriptor descriptor;
		for (Enumeration attrs = ctxt.getAttributeNamesInScope(2); attrs.hasMoreElements(); list.add(descriptor)) {
			String name = (String)attrs.nextElement();
			Object value = ctxt.getAttribute(name, 2);
			descriptor = new FeatureDescriptor();
			descriptor.setName(name);
			descriptor.setDisplayName(name);
			descriptor.setShortDescription("request scope attribute");
			descriptor.setExpert(false);
			descriptor.setHidden(false);
			descriptor.setPreferred(true);
			descriptor.setValue("type", value.getClass());
			descriptor.setValue("resolvableAtDesignTime", Boolean.TRUE);
		}

		FeatureDescriptor descriptor;
		for (Enumeration attrs = ctxt.getAttributeNamesInScope(3); attrs.hasMoreElements(); list.add(descriptor)) {
			String name = (String)attrs.nextElement();
			Object value = ctxt.getAttribute(name, 3);
			descriptor = new FeatureDescriptor();
			descriptor.setName(name);
			descriptor.setDisplayName(name);
			descriptor.setShortDescription("session scope attribute");
			descriptor.setExpert(false);
			descriptor.setHidden(false);
			descriptor.setPreferred(true);
			descriptor.setValue("type", value.getClass());
			descriptor.setValue("resolvableAtDesignTime", Boolean.TRUE);
		}

		FeatureDescriptor descriptor;
		for (Enumeration attrs = ctxt.getAttributeNamesInScope(4); attrs.hasMoreElements(); list.add(descriptor)) {
			String name = (String)attrs.nextElement();
			Object value = ctxt.getAttribute(name, 4);
			descriptor = new FeatureDescriptor();
			descriptor.setName(name);
			descriptor.setDisplayName(name);
			descriptor.setShortDescription("application scope attribute");
			descriptor.setExpert(false);
			descriptor.setHidden(false);
			descriptor.setPreferred(true);
			descriptor.setValue("type", value.getClass());
			descriptor.setValue("resolvableAtDesignTime", Boolean.TRUE);
		}

		return list.iterator();
	}

	public Class getCommonPropertyType(ELContext context, Object base) {
		if (base == null) {
			return java/lang/String;
		} else {
			return null;
		}
	}
}
