// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ImplicitObjectELResolver.java

package javax.servlet.jsp.el;

import java.util.Enumeration;
import javax.servlet.ServletContext;

// Referenced classes of package javax.servlet.jsp.el:
//			ImplicitObjectELResolver

static class ImplicitObjectELResolver$ImplicitObjects$9 extends ImplicitObjectELResolver$EnumeratedMap {

	final ServletContext val$context;

	public Enumeration enumerateKeys() {
		return val$context.getInitParameterNames();
	}

	public Object getValue(Object pKey) {
		if (pKey instanceof String) {
			return val$context.getInitParameter((String)pKey);
		} else {
			return null;
		}
	}

	public boolean isMutable() {
		return false;
	}

	ImplicitObjectELResolver$ImplicitObjects$9(ServletContext servletcontext) {
		val$context = servletcontext;
		super(null);
	}
}
