// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ImplicitObjectELResolver.java

package javax.servlet.jsp.el;

import java.util.Enumeration;
import javax.servlet.jsp.PageContext;

// Referenced classes of package javax.servlet.jsp.el:
//			ImplicitObjectELResolver

static class ImplicitObjectELResolver$ImplicitObjects$2 extends ImplicitObjectELResolver$EnumeratedMap {

	final PageContext val$context;

	public Enumeration enumerateKeys() {
		return val$context.getAttributeNamesInScope(2);
	}

	public Object getValue(Object pKey) {
		if (pKey instanceof String) {
			return val$context.getAttribute((String)pKey, 2);
		} else {
			return null;
		}
	}

	public boolean isMutable() {
		return true;
	}

	ImplicitObjectELResolver$ImplicitObjects$2(PageContext pagecontext) {
		val$context = pagecontext;
		super(null);
	}
}
