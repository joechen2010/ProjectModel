// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   Expression.java

package javax.servlet.jsp.el;


// Referenced classes of package javax.servlet.jsp.el:
//			ELException, VariableResolver

/**
 * @deprecated Class Expression is deprecated
 */

public abstract class Expression {

	public Expression() {
	}

	public abstract Object evaluate(VariableResolver variableresolver) throws ELException;
}
