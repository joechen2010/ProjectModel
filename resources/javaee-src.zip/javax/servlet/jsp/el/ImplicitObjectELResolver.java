// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ImplicitObjectELResolver.java

package javax.servlet.jsp.el;

import java.beans.FeatureDescriptor;
import java.util.*;
import javax.el.*;
import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspContext;
import javax.servlet.jsp.PageContext;

public class ImplicitObjectELResolver extends ELResolver {
	private static abstract class EnumeratedMap
		implements Map {

		Map mMap;

		public void clear() {
			throw new UnsupportedOperationException();
		}

		public boolean containsKey(Object pKey) {
			return getValue(pKey) != null;
		}

		public boolean containsValue(Object pValue) {
			return getAsMap().containsValue(pValue);
		}

		public Set entrySet() {
			return getAsMap().entrySet();
		}

		public Object get(Object pKey) {
			return getValue(pKey);
		}

		public boolean isEmpty() {
			return !enumerateKeys().hasMoreElements();
		}

		public Set keySet() {
			return getAsMap().keySet();
		}

		public Object put(Object pKey, Object pValue) {
			throw new UnsupportedOperationException();
		}

		public void putAll(Map pMap) {
			throw new UnsupportedOperationException();
		}

		public Object remove(Object pKey) {
			throw new UnsupportedOperationException();
		}

		public int size() {
			return getAsMap().size();
		}

		public Collection values() {
			return getAsMap().values();
		}

		public abstract Enumeration enumerateKeys();

		public abstract boolean isMutable();

		public abstract Object getValue(Object obj);

		public Map getAsMap() {
			if (mMap != null) {
				return mMap;
			}
			Map m = convertToMap();
			if (!isMutable()) {
				mMap = m;
			}
			return m;
		}

		Map convertToMap() {
			Map ret = new HashMap();
			Object key;
			Object value;
			for (Enumeration e = enumerateKeys(); e.hasMoreElements(); ret.put(key, value)) {
				key = e.nextElement();
				value = getValue(key);
			}

			return ret;
		}

		private EnumeratedMap() {
		}

	}

	private static class ImplicitObjects {

		static final String sAttributeName = "org.apache.taglibs.standard.ImplicitObjects";
		PageContext mContext;
		Map mPage;
		Map mRequest;
		Map mSession;
		Map mApplication;
		Map mParam;
		Map mParams;
		Map mHeader;
		Map mHeaders;
		Map mInitParam;
		Map mCookie;

		public static ImplicitObjects getImplicitObjects(PageContext pContext) {
			ImplicitObjects objs = (ImplicitObjects)pContext.getAttribute("org.apache.taglibs.standard.ImplicitObjects", 1);
			if (objs == null) {
				objs = new ImplicitObjects(pContext);
				pContext.setAttribute("org.apache.taglibs.standard.ImplicitObjects", objs, 1);
			}
			return objs;
		}

		public Map getPageScopeMap() {
			if (mPage == null) {
				mPage = createPageScopeMap(mContext);
			}
			return mPage;
		}

		public Map getRequestScopeMap() {
			if (mRequest == null) {
				mRequest = createRequestScopeMap(mContext);
			}
			return mRequest;
		}

		public Map getSessionScopeMap() {
			if (mSession == null) {
				mSession = createSessionScopeMap(mContext);
			}
			return mSession;
		}

		public Map getApplicationScopeMap() {
			if (mApplication == null) {
				mApplication = createApplicationScopeMap(mContext);
			}
			return mApplication;
		}

		public Map getParamMap() {
			if (mParam == null) {
				mParam = createParamMap(mContext);
			}
			return mParam;
		}

		public Map getParamsMap() {
			if (mParams == null) {
				mParams = createParamsMap(mContext);
			}
			return mParams;
		}

		public Map getHeaderMap() {
			if (mHeader == null) {
				mHeader = createHeaderMap(mContext);
			}
			return mHeader;
		}

		public Map getHeadersMap() {
			if (mHeaders == null) {
				mHeaders = createHeadersMap(mContext);
			}
			return mHeaders;
		}

		public Map getInitParamMap() {
			if (mInitParam == null) {
				mInitParam = createInitParamMap(mContext);
			}
			return mInitParam;
		}

		public Map getCookieMap() {
			if (mCookie == null) {
				mCookie = createCookieMap(mContext);
			}
			return mCookie;
		}

		public static Map createPageScopeMap(PageContext pContext) {
			PageContext context = pContext;
			return new EnumeratedMap(context) {

				final PageContext val$context;

				public Enumeration enumerateKeys() {
					return context.getAttributeNamesInScope(1);
				}

				public Object getValue(Object pKey) {
					if (pKey instanceof String) {
						return context.getAttribute((String)pKey, 1);
					} else {
						return null;
					}
				}

				public boolean isMutable() {
					return true;
				}

				 {
					context = pagecontext;
					super();
				}
			};
		}

		public static Map createRequestScopeMap(PageContext pContext) {
			PageContext context = pContext;
			return new EnumeratedMap(context) {

				final PageContext val$context;

				public Enumeration enumerateKeys() {
					return context.getAttributeNamesInScope(2);
				}

				public Object getValue(Object pKey) {
					if (pKey instanceof String) {
						return context.getAttribute((String)pKey, 2);
					} else {
						return null;
					}
				}

				public boolean isMutable() {
					return true;
				}

				 {
					context = pagecontext;
					super();
				}
			};
		}

		public static Map createSessionScopeMap(PageContext pContext) {
			PageContext context = pContext;
			return new EnumeratedMap(context) {

				final PageContext val$context;

				public Enumeration enumerateKeys() {
					return context.getAttributeNamesInScope(3);
				}

				public Object getValue(Object pKey) {
					if (pKey instanceof String) {
						return context.getAttribute((String)pKey, 3);
					} else {
						return null;
					}
				}

				public boolean isMutable() {
					return true;
				}

				 {
					context = pagecontext;
					super();
				}
			};
		}

		public static Map createApplicationScopeMap(PageContext pContext) {
			PageContext context = pContext;
			return new EnumeratedMap(context) {

				final PageContext val$context;

				public Enumeration enumerateKeys() {
					return context.getAttributeNamesInScope(4);
				}

				public Object getValue(Object pKey) {
					if (pKey instanceof String) {
						return context.getAttribute((String)pKey, 4);
					} else {
						return null;
					}
				}

				public boolean isMutable() {
					return true;
				}

				 {
					context = pagecontext;
					super();
				}
			};
		}

		public static Map createParamMap(PageContext pContext) {
			HttpServletRequest request = (HttpServletRequest)pContext.getRequest();
			return new EnumeratedMap(request) {

				final HttpServletRequest val$request;

				public Enumeration enumerateKeys() {
					return request.getParameterNames();
				}

				public Object getValue(Object pKey) {
					if (pKey instanceof String) {
						return request.getParameter((String)pKey);
					} else {
						return null;
					}
				}

				public boolean isMutable() {
					return false;
				}

				 {
					request = httpservletrequest;
					super();
				}
			};
		}

		public static Map createParamsMap(PageContext pContext) {
			HttpServletRequest request = (HttpServletRequest)pContext.getRequest();
			return new EnumeratedMap(request) {

				final HttpServletRequest val$request;

				public Enumeration enumerateKeys() {
					return request.getParameterNames();
				}

				public Object getValue(Object pKey) {
					if (pKey instanceof String) {
						return request.getParameterValues((String)pKey);
					} else {
						return null;
					}
				}

				public boolean isMutable() {
					return false;
				}

				 {
					request = httpservletrequest;
					super();
				}
			};
		}

		public static Map createHeaderMap(PageContext pContext) {
			HttpServletRequest request = (HttpServletRequest)pContext.getRequest();
			return new EnumeratedMap(request) {

				final HttpServletRequest val$request;

				public Enumeration enumerateKeys() {
					return request.getHeaderNames();
				}

				public Object getValue(Object pKey) {
					if (pKey instanceof String) {
						return request.getHeader((String)pKey);
					} else {
						return null;
					}
				}

				public boolean isMutable() {
					return false;
				}

				 {
					request = httpservletrequest;
					super();
				}
			};
		}

		public static Map createHeadersMap(PageContext pContext) {
			HttpServletRequest request = (HttpServletRequest)pContext.getRequest();
			return new EnumeratedMap(request) {

				final HttpServletRequest val$request;

				public Enumeration enumerateKeys() {
					return request.getHeaderNames();
				}

				public Object getValue(Object pKey) {
					if (pKey instanceof String) {
						List l = new ArrayList();
						Enumeration e = request.getHeaders((String)pKey);
						if (e != null) {
							for (; e.hasMoreElements(); l.add(e.nextElement())) { }
						}
						String ret[] = (String[])(String[])l.toArray(new String[l.size()]);
						return ret;
					} else {
						return null;
					}
				}

				public boolean isMutable() {
					return false;
				}

				 {
					request = httpservletrequest;
					super();
				}
			};
		}

		public static Map createInitParamMap(PageContext pContext) {
			ServletContext context = pContext.getServletContext();
			return new EnumeratedMap(context) {

				final ServletContext val$context;

				public Enumeration enumerateKeys() {
					return context.getInitParameterNames();
				}

				public Object getValue(Object pKey) {
					if (pKey instanceof String) {
						return context.getInitParameter((String)pKey);
					} else {
						return null;
					}
				}

				public boolean isMutable() {
					return false;
				}

				 {
					context = servletcontext;
					super();
				}
			};
		}

		public static Map createCookieMap(PageContext pContext) {
			HttpServletRequest request = (HttpServletRequest)pContext.getRequest();
			Cookie cookies[] = request.getCookies();
			Map ret = new HashMap();
			for (int i = 0; cookies != null && i < cookies.length; i++) {
				Cookie cookie = cookies[i];
				if (cookie == null) {
					continue;
				}
				String name = cookie.getName();
				if (!ret.containsKey(name)) {
					ret.put(name, cookie);
				}
			}

			return ret;
		}

		public ImplicitObjects(PageContext pContext) {
			mContext = pContext;
		}
	}


	public ImplicitObjectELResolver() {
	}

	public Object getValue(ELContext context, Object base, Object property) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base != null) {
			return null;
		}
		PageContext ctxt = (PageContext)context.getContext(javax/servlet/jsp/JspContext);
		if ("pageContext".equals(property)) {
			context.setPropertyResolved(true);
			return ctxt;
		}
		ImplicitObjects implicitObjects = ImplicitObjects.getImplicitObjects(ctxt);
		if ("pageScope".equals(property)) {
			context.setPropertyResolved(true);
			return implicitObjects.getPageScopeMap();
		}
		if ("requestScope".equals(property)) {
			context.setPropertyResolved(true);
			return implicitObjects.getRequestScopeMap();
		}
		if ("sessionScope".equals(property)) {
			context.setPropertyResolved(true);
			return implicitObjects.getSessionScopeMap();
		}
		if ("applicationScope".equals(property)) {
			context.setPropertyResolved(true);
			return implicitObjects.getApplicationScopeMap();
		}
		if ("param".equals(property)) {
			context.setPropertyResolved(true);
			return implicitObjects.getParamMap();
		}
		if ("paramValues".equals(property)) {
			context.setPropertyResolved(true);
			return implicitObjects.getParamsMap();
		}
		if ("header".equals(property)) {
			context.setPropertyResolved(true);
			return implicitObjects.getHeaderMap();
		}
		if ("headerValues".equals(property)) {
			context.setPropertyResolved(true);
			return implicitObjects.getHeadersMap();
		}
		if ("initParam".equals(property)) {
			context.setPropertyResolved(true);
			return implicitObjects.getInitParamMap();
		}
		if ("cookie".equals(property)) {
			context.setPropertyResolved(true);
			return implicitObjects.getCookieMap();
		} else {
			return null;
		}
	}

	public Class getType(ELContext context, Object base, Object property) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base == null && ("pageContext".equals(property) || "pageScope".equals(property)) || "requestScope".equals(property) || "sessionScope".equals(property) || "applicationScope".equals(property) || "param".equals(property) || "paramValues".equals(property) || "header".equals(property) || "headerValues".equals(property) || "initParam".equals(property) || "cookie".equals(property)) {
			context.setPropertyResolved(true);
		}
		return null;
	}

	public void setValue(ELContext context, Object base, Object property, Object val) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base == null && ("pageContext".equals(property) || "pageScope".equals(property)) || "requestScope".equals(property) || "sessionScope".equals(property) || "applicationScope".equals(property) || "param".equals(property) || "paramValues".equals(property) || "header".equals(property) || "headerValues".equals(property) || "initParam".equals(property) || "cookie".equals(property)) {
			throw new PropertyNotWritableException();
		} else {
			return;
		}
	}

	public boolean isReadOnly(ELContext context, Object base, Object property) {
		if (context == null) {
			throw new NullPointerException();
		}
		if (base == null && ("pageContext".equals(property) || "pageScope".equals(property)) || "requestScope".equals(property) || "sessionScope".equals(property) || "applicationScope".equals(property) || "param".equals(property) || "paramValues".equals(property) || "header".equals(property) || "headerValues".equals(property) || "initParam".equals(property) || "cookie".equals(property)) {
			context.setPropertyResolved(true);
			return true;
		} else {
			return false;
		}
	}

	public Iterator getFeatureDescriptors(ELContext context, Object base) {
		ArrayList list = new ArrayList(11);
		FeatureDescriptor descriptor = new FeatureDescriptor();
		descriptor.setName("pageContext");
		descriptor.setDisplayName("pageContext");
		descriptor.setExpert(false);
		descriptor.setHidden(false);
		descriptor.setPreferred(true);
		descriptor.setValue("type", javax/servlet/jsp/PageContext);
		descriptor.setValue("resolvableAtDesignTime", Boolean.TRUE);
		list.add(descriptor);
		descriptor = new FeatureDescriptor();
		descriptor.setName("pageScope");
		descriptor.setDisplayName("pageScope");
		descriptor.setExpert(false);
		descriptor.setHidden(false);
		descriptor.setPreferred(true);
		descriptor.setValue("type", java/util/Map);
		descriptor.setValue("resolvableAtDesignTime", Boolean.TRUE);
		list.add(descriptor);
		descriptor = new FeatureDescriptor();
		descriptor.setName("requestScope");
		descriptor.setDisplayName("requestScope");
		descriptor.setExpert(false);
		descriptor.setHidden(false);
		descriptor.setPreferred(true);
		descriptor.setValue("type", java/util/Map);
		descriptor.setValue("resolvableAtDesignTime", Boolean.TRUE);
		list.add(descriptor);
		descriptor = new FeatureDescriptor();
		descriptor.setName("sessionScope");
		descriptor.setDisplayName("sessionScope");
		descriptor.setExpert(false);
		descriptor.setHidden(false);
		descriptor.setPreferred(true);
		descriptor.setValue("type", java/util/Map);
		descriptor.setValue("resolvableAtDesignTime", Boolean.TRUE);
		list.add(descriptor);
		descriptor = new FeatureDescriptor();
		descriptor.setName("applicationScope");
		descriptor.setDisplayName("applicationScope");
		descriptor.setExpert(false);
		descriptor.setHidden(false);
		descriptor.setPreferred(true);
		descriptor.setValue("type", java/util/Map);
		descriptor.setValue("resolvableAtDesignTime", Boolean.TRUE);
		list.add(descriptor);
		descriptor = new FeatureDescriptor();
		descriptor.setName("param");
		descriptor.setDisplayName("param");
		descriptor.setExpert(false);
		descriptor.setHidden(false);
		descriptor.setPreferred(true);
		descriptor.setValue("type", java/util/Map);
		descriptor.setValue("resolvableAtDesignTime", Boolean.TRUE);
		list.add(descriptor);
		descriptor = new FeatureDescriptor();
		descriptor.setName("paramValues");
		descriptor.setDisplayName("paramValues");
		descriptor.setExpert(false);
		descriptor.setHidden(false);
		descriptor.setPreferred(true);
		descriptor.setValue("type", java/util/Map);
		descriptor.setValue("resolvableAtDesignTime", Boolean.TRUE);
		list.add(descriptor);
		descriptor = new FeatureDescriptor();
		descriptor.setName("header");
		descriptor.setDisplayName("header");
		descriptor.setExpert(false);
		descriptor.setHidden(false);
		descriptor.setPreferred(true);
		descriptor.setValue("type", java/util/Map);
		descriptor.setValue("resolvableAtDesignTime", Boolean.TRUE);
		list.add(descriptor);
		descriptor = new FeatureDescriptor();
		descriptor.setName("headerValues");
		descriptor.setDisplayName("headerValues");
		descriptor.setExpert(false);
		descriptor.setHidden(false);
		descriptor.setPreferred(true);
		descriptor.setValue("type", java/util/Map);
		descriptor.setValue("resolvableAtDesignTime", Boolean.TRUE);
		list.add(descriptor);
		descriptor = new FeatureDescriptor();
		descriptor.setName("cookie");
		descriptor.setDisplayName("cookie");
		descriptor.setExpert(false);
		descriptor.setHidden(false);
		descriptor.setPreferred(true);
		descriptor.setValue("type", java/util/Map);
		descriptor.setValue("resolvableAtDesignTime", Boolean.TRUE);
		list.add(descriptor);
		descriptor = new FeatureDescriptor();
		descriptor.setName("initParam");
		descriptor.setDisplayName("initParam");
		descriptor.setExpert(false);
		descriptor.setHidden(false);
		descriptor.setPreferred(true);
		descriptor.setValue("type", java/util/Map);
		descriptor.setValue("resolvableAtDesignTime", Boolean.TRUE);
		list.add(descriptor);
		return list.iterator();
	}

	public Class getCommonPropertyType(ELContext context, Object base) {
		if (base == null) {
			return java/lang/String;
		} else {
			return null;
		}
	}
}
