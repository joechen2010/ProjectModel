// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ExpressionEvaluator.java

package javax.servlet.jsp.el;


// Referenced classes of package javax.servlet.jsp.el:
//			ELException, FunctionMapper, Expression, VariableResolver

/**
 * @deprecated Class ExpressionEvaluator is deprecated
 */

public abstract class ExpressionEvaluator {

	public ExpressionEvaluator() {
	}

	public abstract Expression parseExpression(String s, Class class1, FunctionMapper functionmapper) throws ELException;

	public abstract Object evaluate(String s, Class class1, VariableResolver variableresolver, FunctionMapper functionmapper) throws ELException;
}
