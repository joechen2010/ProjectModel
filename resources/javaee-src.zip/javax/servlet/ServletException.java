// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ServletException.java

package javax.servlet;


public class ServletException extends Exception {

	private Throwable rootCause;

	public ServletException() {
	}

	public ServletException(String message) {
		super(message);
	}

	public ServletException(String message, Throwable rootCause) {
		super(message, rootCause);
		this.rootCause = rootCause;
	}

	public ServletException(Throwable rootCause) {
		super(rootCause);
		this.rootCause = rootCause;
	}

	public Throwable getRootCause() {
		return rootCause;
	}
}
