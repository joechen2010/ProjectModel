// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ServletInputStream.java

package javax.servlet;

import java.io.IOException;
import java.io.InputStream;

public abstract class ServletInputStream extends InputStream {

	protected ServletInputStream() {
	}

	public int readLine(byte b[], int off, int len) throws IOException {
		if (len <= 0) {
			return 0;
		}
		int count = 0;
		int c;
		do {
			if ((c = read()) == -1) {
				break;
			}
			b[off++] = (byte)c;
			count++;
		} while (c != 10 && count != len);
		return count <= 0 ? -1 : count;
	}
}
