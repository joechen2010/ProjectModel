// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   EJBContext.java

package javax.ejb;

import java.security.Identity;
import java.security.Principal;
import java.util.Properties;
import javax.transaction.UserTransaction;

// Referenced classes of package javax.ejb:
//			EJBHome, EJBLocalHome, TimerService

public interface EJBContext {

	public abstract EJBHome getEJBHome();

	public abstract EJBLocalHome getEJBLocalHome();

	/**
	 * @deprecated Method getEnvironment is deprecated
	 */

	public abstract Properties getEnvironment();

	/**
	 * @deprecated Method getCallerIdentity is deprecated
	 */

	public abstract Identity getCallerIdentity();

	public abstract Principal getCallerPrincipal();

	/**
	 * @deprecated Method isCallerInRole is deprecated
	 */

	public abstract boolean isCallerInRole(Identity identity);

	public abstract boolean isCallerInRole(String s);

	public abstract UserTransaction getUserTransaction() throws IllegalStateException;

	public abstract void setRollbackOnly() throws IllegalStateException;

	public abstract boolean getRollbackOnly() throws IllegalStateException;

	public abstract TimerService getTimerService() throws IllegalStateException;

	public abstract Object lookup(String s);
}
