// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   EJBMetaData.java

package javax.ejb;


// Referenced classes of package javax.ejb:
//			EJBHome

public interface EJBMetaData {

	public abstract EJBHome getEJBHome();

	public abstract Class getHomeInterfaceClass();

	public abstract Class getRemoteInterfaceClass();

	public abstract Class getPrimaryKeyClass();

	public abstract boolean isSession();

	public abstract boolean isStatelessSession();
}
