// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   EJBLocalObject.java

package javax.ejb;


// Referenced classes of package javax.ejb:
//			EJBException, RemoveException, EJBLocalHome

public interface EJBLocalObject {

	public abstract EJBLocalHome getEJBLocalHome() throws EJBException;

	public abstract Object getPrimaryKey() throws EJBException;

	public abstract void remove() throws RemoveException, EJBException;

	public abstract boolean isIdentical(EJBLocalObject ejblocalobject) throws EJBException;
}
