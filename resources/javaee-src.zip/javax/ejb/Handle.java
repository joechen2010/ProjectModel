// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   Handle.java

package javax.ejb;

import java.io.Serializable;
import java.rmi.RemoteException;

// Referenced classes of package javax.ejb:
//			EJBObject

public interface Handle
	extends Serializable {

	public abstract EJBObject getEJBObject() throws RemoteException;
}
