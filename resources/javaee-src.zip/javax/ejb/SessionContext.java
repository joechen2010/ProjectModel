// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   SessionContext.java

package javax.ejb;

import javax.xml.rpc.handler.MessageContext;

// Referenced classes of package javax.ejb:
//			EJBContext, EJBLocalObject, EJBObject

public interface SessionContext
	extends EJBContext {

	public abstract EJBLocalObject getEJBLocalObject() throws IllegalStateException;

	public abstract EJBObject getEJBObject() throws IllegalStateException;

	public abstract MessageContext getMessageContext() throws IllegalStateException;

	public abstract Object getBusinessObject(Class class1) throws IllegalStateException;

	public abstract Class getInvokedBusinessInterface() throws IllegalStateException;
}
