// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   Timer.java

package javax.ejb;

import java.io.Serializable;
import java.util.Date;

// Referenced classes of package javax.ejb:
//			EJBException, NoSuchObjectLocalException, TimerHandle

public interface Timer {

	public abstract void cancel() throws IllegalStateException, NoSuchObjectLocalException, EJBException;

	public abstract long getTimeRemaining() throws IllegalStateException, NoSuchObjectLocalException, EJBException;

	public abstract Date getNextTimeout() throws IllegalStateException, NoSuchObjectLocalException, EJBException;

	public abstract Serializable getInfo() throws IllegalStateException, NoSuchObjectLocalException, EJBException;

	public abstract TimerHandle getHandle() throws IllegalStateException, NoSuchObjectLocalException, EJBException;
}
