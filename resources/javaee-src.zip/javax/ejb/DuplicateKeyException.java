// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   DuplicateKeyException.java

package javax.ejb;


// Referenced classes of package javax.ejb:
//			CreateException

public class DuplicateKeyException extends CreateException {

	public DuplicateKeyException() {
	}

	public DuplicateKeyException(String message) {
		super(message);
	}
}
