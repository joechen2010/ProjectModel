// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   NoSuchEJBException.java

package javax.ejb;


// Referenced classes of package javax.ejb:
//			EJBException

public class NoSuchEJBException extends EJBException {

	public NoSuchEJBException() {
	}

	public NoSuchEJBException(String message) {
		super(message);
	}

	public NoSuchEJBException(String message, Exception ex) {
		super(message, ex);
	}
}
