// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   EJBHome.java

package javax.ejb;

import java.rmi.Remote;
import java.rmi.RemoteException;

// Referenced classes of package javax.ejb:
//			RemoveException, Handle, EJBMetaData, HomeHandle

public interface EJBHome
	extends Remote {

	public abstract void remove(Handle handle) throws RemoteException, RemoveException;

	public abstract void remove(Object obj) throws RemoteException, RemoveException;

	public abstract EJBMetaData getEJBMetaData() throws RemoteException;

	public abstract HomeHandle getHomeHandle() throws RemoteException;
}
