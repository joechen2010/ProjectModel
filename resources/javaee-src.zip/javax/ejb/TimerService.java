// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   TimerService.java

package javax.ejb;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

// Referenced classes of package javax.ejb:
//			EJBException, Timer

public interface TimerService {

	public abstract Timer createTimer(long l, Serializable serializable) throws IllegalArgumentException, IllegalStateException, EJBException;

	public abstract Timer createTimer(long l, long l1, Serializable serializable) throws IllegalArgumentException, IllegalStateException, EJBException;

	public abstract Timer createTimer(Date date, Serializable serializable) throws IllegalArgumentException, IllegalStateException, EJBException;

	public abstract Timer createTimer(Date date, long l, Serializable serializable) throws IllegalArgumentException, IllegalStateException, EJBException;

	public abstract Collection getTimers() throws IllegalStateException, EJBException;
}
