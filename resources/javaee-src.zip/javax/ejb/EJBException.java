// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   EJBException.java

package javax.ejb;

import java.io.PrintStream;
import java.io.PrintWriter;

public class EJBException extends RuntimeException {

	private Exception causeException;

	public EJBException() {
		causeException = null;
	}

	public EJBException(String message) {
		super(message);
		causeException = null;
	}

	public EJBException(Exception ex) {
		causeException = null;
		causeException = ex;
	}

	public EJBException(String message, Exception ex) {
		super(message);
		causeException = null;
		causeException = ex;
	}

	public Exception getCausedByException() {
		return causeException;
	}

	public String getMessage() {
		String msg = super.getMessage();
		if (causeException == null) {
			return msg;
		}
		if (msg == null) {
			return (new StringBuilder()).append("nested exception is: ").append(causeException.toString()).toString();
		} else {
			return (new StringBuilder()).append(msg).append("; nested exception is: ").append(causeException.toString()).toString();
		}
	}

	public void printStackTrace(PrintStream ps) {
		if (causeException == null) {
			super.printStackTrace(ps);
		} else {
			synchronized (ps) {
				ps.println(this);
				causeException.printStackTrace(ps);
				super.printStackTrace(ps);
			}
		}
	}

	public void printStackTrace() {
		printStackTrace(System.err);
	}

	public void printStackTrace(PrintWriter pw) {
		if (causeException == null) {
			super.printStackTrace(pw);
		} else {
			synchronized (pw) {
				pw.println(this);
				causeException.printStackTrace(pw);
				super.printStackTrace(pw);
			}
		}
	}
}
