// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   EntityBean.java

package javax.ejb;

import java.rmi.RemoteException;

// Referenced classes of package javax.ejb:
//			EJBException, EnterpriseBean, RemoveException, EntityContext

public interface EntityBean
	extends EnterpriseBean {

	public abstract void setEntityContext(EntityContext entitycontext) throws EJBException, RemoteException;

	public abstract void unsetEntityContext() throws EJBException, RemoteException;

	public abstract void ejbRemove() throws RemoveException, EJBException, RemoteException;

	public abstract void ejbActivate() throws EJBException, RemoteException;

	public abstract void ejbPassivate() throws EJBException, RemoteException;

	public abstract void ejbLoad() throws EJBException, RemoteException;

	public abstract void ejbStore() throws EJBException, RemoteException;
}
