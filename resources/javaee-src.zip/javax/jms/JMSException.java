// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   JMSException.java

package javax.jms;


public class JMSException extends Exception {

	private String errorCode;
	private Exception linkedException;

	public JMSException(String reason, String errorCode) {
		super(reason);
		this.errorCode = errorCode;
		linkedException = null;
	}

	public JMSException(String reason) {
		super(reason);
		errorCode = null;
		linkedException = null;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public Exception getLinkedException() {
		return linkedException;
	}

	public synchronized void setLinkedException(Exception ex) {
		linkedException = ex;
	}
}
