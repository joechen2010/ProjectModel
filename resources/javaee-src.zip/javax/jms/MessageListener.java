// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   MessageListener.java

package javax.jms;


// Referenced classes of package javax.jms:
//			Message

public interface MessageListener {

	public abstract void onMessage(Message message);
}
