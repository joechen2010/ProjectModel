// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   Queue.java

package javax.jms;


// Referenced classes of package javax.jms:
//			Destination, JMSException

public interface Queue
	extends Destination {

	public abstract String getQueueName() throws JMSException;

	public abstract String toString();
}
