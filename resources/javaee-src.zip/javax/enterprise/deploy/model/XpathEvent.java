// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   XpathEvent.java

package javax.enterprise.deploy.model;

import java.beans.PropertyChangeEvent;

// Referenced classes of package javax.enterprise.deploy.model:
//			DDBean

public final class XpathEvent {

	private final DDBean bean;
	private final Object typ;
	private PropertyChangeEvent changeEvent;
	public static final Object BEAN_ADDED = new Object();
	public static final Object BEAN_REMOVED = new Object();
	public static final Object BEAN_CHANGED = new Object();

	public XpathEvent(DDBean bean, Object typ) {
		this.bean = bean;
		this.typ = typ;
	}

	public PropertyChangeEvent getChangeEvent() {
		if (typ == BEAN_CHANGED) {
			return changeEvent;
		} else {
			return null;
		}
	}

	public void setChangeEvent(PropertyChangeEvent pce) {
		changeEvent = pce;
	}

	public DDBean getBean() {
		return bean;
	}

	public boolean isAddEvent() {
		return typ == BEAN_ADDED;
	}

	public boolean isRemoveEvent() {
		return typ == BEAN_REMOVED;
	}

	public boolean isChangeEvent() {
		return typ == BEAN_CHANGED;
	}

}
