// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   DDBeanRoot.java

package javax.enterprise.deploy.model;

import javax.enterprise.deploy.shared.ModuleType;

// Referenced classes of package javax.enterprise.deploy.model:
//			DDBean, DeployableObject

public interface DDBeanRoot
	extends DDBean {

	public abstract ModuleType getType();

	public abstract DeployableObject getDeployableObject();

	/**
	 * @deprecated Method getModuleDTDVersion is deprecated
	 */

	public abstract String getModuleDTDVersion();

	public abstract String getDDBeanRootVersion();

	public abstract String getXpath();

	public abstract String getFilename();
}
