// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   DDBean.java

package javax.enterprise.deploy.model;


// Referenced classes of package javax.enterprise.deploy.model:
//			DDBeanRoot, XpathListener

public interface DDBean {

	public abstract String getXpath();

	public abstract String getText();

	public abstract String getId();

	public abstract DDBeanRoot getRoot();

	public abstract DDBean[] getChildBean(String s);

	public abstract String[] getText(String s);

	public abstract void addXpathListener(String s, XpathListener xpathlistener);

	public abstract void removeXpathListener(String s, XpathListener xpathlistener);

	public abstract String[] getAttributeNames();

	public abstract String getAttributeValue(String s);
}
