// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ActionType.java

package javax.enterprise.deploy.shared;


public class ActionType {

	private int value;
	public static final ActionType EXECUTE;
	public static final ActionType CANCEL;
	public static final ActionType STOP;
	private static final String stringTable[] = {
		"execute", "cancel", "stop"
	};
	private static final ActionType enumValueTable[];

	protected ActionType(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}

	protected String[] getStringTable() {
		return stringTable;
	}

	protected ActionType[] getEnumValueTable() {
		return enumValueTable;
	}

	public static ActionType getActionType(int value) {
		return enumValueTable[value];
	}

	public String toString() {
		String strTable[] = getStringTable();
		int index = value - getOffset();
		if (strTable != null && index >= 0 && index < strTable.length) {
			return strTable[index];
		} else {
			return Integer.toString(value);
		}
	}

	protected int getOffset() {
		return 0;
	}

	static  {
		EXECUTE = new ActionType(0);
		CANCEL = new ActionType(1);
		STOP = new ActionType(2);
		enumValueTable = (new ActionType[] {
			EXECUTE, CANCEL, STOP
		});
	}
}
