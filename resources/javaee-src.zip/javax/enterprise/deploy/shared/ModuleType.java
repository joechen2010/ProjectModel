// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ModuleType.java

package javax.enterprise.deploy.shared;


public class ModuleType {

	private int value;
	public static final ModuleType EAR;
	public static final ModuleType EJB;
	public static final ModuleType CAR;
	public static final ModuleType RAR;
	public static final ModuleType WAR;
	private static final String stringTable[] = {
		"ear", "ejb", "car", "rar", "war"
	};
	private static final ModuleType enumValueTable[];
	private static final String moduleExtension[] = {
		".ear", ".jar", ".jar", ".rar", ".war"
	};

	protected ModuleType(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}

	protected String[] getStringTable() {
		return stringTable;
	}

	protected ModuleType[] getEnumValueTable() {
		return enumValueTable;
	}

	public String getModuleExtension() {
		return moduleExtension[getValue()];
	}

	public static ModuleType getModuleType(int value) {
		return enumValueTable[value];
	}

	public String toString() {
		String strTable[] = getStringTable();
		int index = value - getOffset();
		if (strTable != null && index >= 0 && index < strTable.length) {
			return strTable[index];
		} else {
			return Integer.toString(value);
		}
	}

	protected int getOffset() {
		return 0;
	}

	static  {
		EAR = new ModuleType(0);
		EJB = new ModuleType(1);
		CAR = new ModuleType(2);
		RAR = new ModuleType(3);
		WAR = new ModuleType(4);
		enumValueTable = (new ModuleType[] {
			EAR, EJB, CAR, RAR, WAR
		});
	}
}
