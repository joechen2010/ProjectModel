// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ProgressObject.java

package javax.enterprise.deploy.spi.status;

import javax.enterprise.deploy.spi.TargetModuleID;
import javax.enterprise.deploy.spi.exceptions.OperationUnsupportedException;

// Referenced classes of package javax.enterprise.deploy.spi.status:
//			DeploymentStatus, ClientConfiguration, ProgressListener

public interface ProgressObject {

	public abstract DeploymentStatus getDeploymentStatus();

	public abstract TargetModuleID[] getResultTargetModuleIDs();

	public abstract ClientConfiguration getClientConfiguration(TargetModuleID targetmoduleid);

	public abstract boolean isCancelSupported();

	public abstract void cancel() throws OperationUnsupportedException;

	public abstract boolean isStopSupported();

	public abstract void stop() throws OperationUnsupportedException;

	public abstract void addProgressListener(ProgressListener progresslistener);

	public abstract void removeProgressListener(ProgressListener progresslistener);
}
