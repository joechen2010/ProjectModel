// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   DeploymentFactory.java

package javax.enterprise.deploy.spi.factories;

import javax.enterprise.deploy.spi.DeploymentManager;
import javax.enterprise.deploy.spi.exceptions.DeploymentManagerCreationException;

public interface DeploymentFactory {

	public abstract boolean handlesURI(String s);

	public abstract DeploymentManager getDeploymentManager(String s, String s1, String s2) throws DeploymentManagerCreationException;

	public abstract DeploymentManager getDisconnectedDeploymentManager(String s) throws DeploymentManagerCreationException;

	public abstract String getDisplayName();

	public abstract String getProductVersion();
}
