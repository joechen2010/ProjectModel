// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   DConfigBean.java

package javax.enterprise.deploy.spi;

import java.beans.PropertyChangeListener;
import javax.enterprise.deploy.model.DDBean;
import javax.enterprise.deploy.model.XpathEvent;
import javax.enterprise.deploy.spi.exceptions.BeanNotFoundException;
import javax.enterprise.deploy.spi.exceptions.ConfigurationException;

public interface DConfigBean {

	public abstract DDBean getDDBean();

	public abstract String[] getXpaths();

	public abstract DConfigBean getDConfigBean(DDBean ddbean) throws ConfigurationException;

	public abstract void removeDConfigBean(DConfigBean dconfigbean) throws BeanNotFoundException;

	public abstract void notifyDDChange(XpathEvent xpathevent);

	public abstract void addPropertyChangeListener(PropertyChangeListener propertychangelistener);

	public abstract void removePropertyChangeListener(PropertyChangeListener propertychangelistener);
}
