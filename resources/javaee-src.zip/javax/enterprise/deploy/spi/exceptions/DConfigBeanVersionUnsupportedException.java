// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   DConfigBeanVersionUnsupportedException.java

package javax.enterprise.deploy.spi.exceptions;


public class DConfigBeanVersionUnsupportedException extends Exception {

	public DConfigBeanVersionUnsupportedException(String s) {
		super(s);
	}
}
