// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   DConfigBeanRoot.java

package javax.enterprise.deploy.spi;

import javax.enterprise.deploy.model.DDBeanRoot;

// Referenced classes of package javax.enterprise.deploy.spi:
//			DConfigBean

public interface DConfigBeanRoot
	extends DConfigBean {

	public abstract DConfigBean getDConfigBean(DDBeanRoot ddbeanroot);
}
