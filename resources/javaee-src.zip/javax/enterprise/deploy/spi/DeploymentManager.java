// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   DeploymentManager.java

package javax.enterprise.deploy.spi;

import java.io.File;
import java.io.InputStream;
import java.util.Locale;
import javax.enterprise.deploy.model.DeployableObject;
import javax.enterprise.deploy.shared.DConfigBeanVersionType;
import javax.enterprise.deploy.shared.ModuleType;
import javax.enterprise.deploy.spi.exceptions.DConfigBeanVersionUnsupportedException;
import javax.enterprise.deploy.spi.exceptions.InvalidModuleException;
import javax.enterprise.deploy.spi.exceptions.TargetException;
import javax.enterprise.deploy.spi.status.ProgressObject;

// Referenced classes of package javax.enterprise.deploy.spi:
//			Target, TargetModuleID, DeploymentConfiguration

public interface DeploymentManager {

	public abstract Target[] getTargets() throws IllegalStateException;

	public abstract TargetModuleID[] getRunningModules(ModuleType moduletype, Target atarget[]) throws TargetException, IllegalStateException;

	public abstract TargetModuleID[] getNonRunningModules(ModuleType moduletype, Target atarget[]) throws TargetException, IllegalStateException;

	public abstract TargetModuleID[] getAvailableModules(ModuleType moduletype, Target atarget[]) throws TargetException, IllegalStateException;

	public abstract DeploymentConfiguration createConfiguration(DeployableObject deployableobject) throws InvalidModuleException;

	public abstract ProgressObject distribute(Target atarget[], File file, File file1) throws IllegalStateException;

	/**
	 * @deprecated Method distribute is deprecated
	 */

	public abstract ProgressObject distribute(Target atarget[], InputStream inputstream, InputStream inputstream1) throws IllegalStateException;

	public abstract ProgressObject distribute(Target atarget[], ModuleType moduletype, InputStream inputstream, InputStream inputstream1) throws IllegalStateException;

	public abstract ProgressObject start(TargetModuleID atargetmoduleid[]) throws IllegalStateException;

	public abstract ProgressObject stop(TargetModuleID atargetmoduleid[]) throws IllegalStateException;

	public abstract ProgressObject undeploy(TargetModuleID atargetmoduleid[]) throws IllegalStateException;

	public abstract boolean isRedeploySupported();

	public abstract ProgressObject redeploy(TargetModuleID atargetmoduleid[], File file, File file1) throws UnsupportedOperationException, IllegalStateException;

	public abstract ProgressObject redeploy(TargetModuleID atargetmoduleid[], InputStream inputstream, InputStream inputstream1) throws UnsupportedOperationException, IllegalStateException;

	public abstract void release();

	public abstract Locale getDefaultLocale();

	public abstract Locale getCurrentLocale();

	public abstract void setLocale(Locale locale) throws UnsupportedOperationException;

	public abstract Locale[] getSupportedLocales();

	public abstract boolean isLocaleSupported(Locale locale);

	public abstract DConfigBeanVersionType getDConfigBeanVersion();

	public abstract boolean isDConfigBeanVersionSupported(DConfigBeanVersionType dconfigbeanversiontype);

	public abstract void setDConfigBeanVersion(DConfigBeanVersionType dconfigbeanversiontype) throws DConfigBeanVersionUnsupportedException;
}
